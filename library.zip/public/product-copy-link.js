/* Copy the bound product URL directly from any product view. */
(function () {
  const previousRender = render;
  render = function () {
    previousRender();
    if (view !== 'products') return;
    document.querySelectorAll('#results [data-product]').forEach(openButton => {
      const row = openButton.closest('.card,.productListRow,tr');
      if (!row || row.querySelector('[data-copy-product-link]')) return;
      const product = productMap[openButton.dataset.product];
      const url = product?.product_url?.trim();
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'btn';
      button.dataset.copyProductLink = openButton.dataset.product;
      button.textContent = '复制链接';
      button.disabled = !url;
      button.title = url ? '复制此商品已关联的链接' : '此商品尚未关联链接';
      openButton.before(button);
    });
  };

  document.addEventListener('click', async event => {
    const button = event.target.closest('[data-copy-product-link]');
    if (!button || button.disabled) return;
    event.preventDefault();
    const url = productMap[button.dataset.copyProductLink]?.product_url?.trim();
    if (!url) return toast('此商品尚未关联链接');
    try {
      await navigator.clipboard.writeText(url);
      toast('商品链接已复制');
    } catch {
      // Legacy browsers and local previews may lack the Clipboard API.
      const field = document.createElement('textarea');
      field.value = url;
      field.style.cssText = 'position:fixed;left:-9999px;top:0';
      document.body.append(field);
      field.select();
      let copied = false;
      try { copied = document.execCommand('copy'); } catch {}
      field.remove();
      button.focus();
      if (copied) toast('商品链接已复制');
      else window.prompt('请复制商品链接', url);
    }
  });
  render();
})();
