(function(){
 const style=document.createElement('style');style.textContent='.productLinkState{display:inline-flex;align-items:center;gap:6px;padding:5px 10px;border-radius:999px;font-size:13px;font-weight:650;line-height:1.4;vertical-align:middle;white-space:nowrap;border:1px solid currentColor;margin:5px 0}.productLinkState svg{width:17px;height:17px;flex:none}.productLinkState.is-valid{color:#257342;background:#edf8ef}.productLinkState.is-invalid{color:#b93636;background:#fff0ed}.productLinkState.is-unknown{color:#8a6b36;background:#fff8e8}.productLinkStateNote{font-size:13px;color:#84745e;margin:5px 0}.listInfo>.productLinkState{margin-top:6px}';document.head.append(style);
 function state(p){
  const a=p.link_audit;if(!p.product_url)return ['unknown','未绑定','尚未绑定商品链接'];
  if(!a)return ['unknown','待核实','没有近期推广链接核查记录'];
  const replaced=a.replacement&&p.product_url!==a.old_url;
  if(replaced||a.promotion_status==='推广核实正常')return ['valid','链接有效','推广状态已核实 · '+a.checked_at+(a.page_status==='页面已抢光'&&!replaced?'；商品页显示已抢光，库存另核':'；库存及具体规格另核')];
  if(a.promotion_status==='推广链接失效')return ['invalid','链接失效','推广状态失效 · '+a.checked_at+'；详情页能打开也不代表可推广'];
  return ['unknown','待核实','推广核实未成功 · '+a.checked_at+'；不判定失效'];
 }
 function badge(p){const [kind,label,note]=state(p);const span=document.createElement('span');span.className='productLinkState is-'+kind;span.title=note;span.setAttribute('role','status');span.setAttribute('aria-label',label+'，'+note);span.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3" aria-hidden="true"><circle cx="12" cy="12" r="9"/>'+(kind==='valid'?'<path d="m7.5 12 3 3 6-6"/>':kind==='invalid'?'<path d="m8.5 8.5 7 7m0-7-7 7"/>':'<path d="M12 7v6m0 3v1"/>')+'</svg><span>'+label+'</span>';return span;}
 const previousRender=render;render=function(){previousRender();if(view!=='products')return;document.querySelectorAll('#results [data-product]').forEach(button=>{const p=productMap[button.dataset.product];const row=button.closest('article,tr');if(!p||!row||row.querySelector('.productLinkState'))return;const b=badge(p);if(row.tagName==='TR'){row.cells[4].replaceChildren(b);}else{const heading=row.querySelector('h3');if(heading)heading.after(b);}});};
 const previousShow=showProduct;showProduct=function(id){previousShow(id);const p=productMap[id];if(!p)return;const section=document.createElement('section');section.className='appearance';section.append(badge(p));const note=document.createElement('p');note.className='productLinkStateNote';note.textContent=state(p)[2];section.append(note);document.querySelector('#dbody').prepend(section);};
 render();
})();
