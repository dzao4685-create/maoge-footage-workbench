window.BASE_INDEX = {
  "products": [
    {
      "id": "PF-d43b70e1",
      "name": "娱小电 BK005 折叠支架磁吸外接电池（多色外观核查）",
      "category": "充电与手机配件",
      "aliases": [
        "娱小电磁吸充电宝",
        "YUXIAODIAN",
        "BK005",
        "BK005L",
        "q12",
        "折叠支架磁吸充电宝"
      ],
      "description": "YUXIAODIAN标识款，9月起已核查3场：9月11日、10月7日、10月8日。MOXIAOMIAO款已分到另一条商品，不再作为本款素材。",
      "cautions": [
        "仅对应YUXIAODIAN标识实物；不同颜色和容量需逐件核对，不能自动视为同一SKU。",
        "日期下的时间为核查定位，非精确剪辑切点。9月22日大矩形显示窗款不计入。"
      ],
      "appearances": [
        {
          "recording_id": "M-f1b53e17b0fdd984",
          "basis": "2026-10-16按多色外观复核；灰色YUXIAODIAN标识款；1800秒同框展示多色，橙色/浅色MOXIAOMIAO不作为该链接同款",
          "windows": [
            [
              1400,
              2007
            ]
          ],
          "visual_anchors_seconds": [
            1800
          ],
          "review_date": "2026-09-11",
          "timing_label": "00:23:20—00:33:27",
          "timing_status": "回查时间段",
          "talk_segments": [
            {
              "start": 1430.04,
              "end": 1479.64,
              "title": "双电量显示和设置界面",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-16_2026-09-14/content-v2/reviewed/2026-09-11_2026.9.11/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 1830.16,
              "end": 1921.16,
              "title": "无线要求、有线方法和容量限制",
              "aspect": "使用边界",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-16_2026-09-14/content-v2/reviewed/2026-09-11_2026.9.11/segments.json",
              "clock": "已有审校回查时间"
            }
          ],
          "talk_status": "已有审校内容分段"
        },
        {
          "recording_id": "M-aa5b92644f8170bb",
          "basis": "2026-10-21原片复核：01:46:40手持紫色支架电池，01:48:20正面YUXIAODIAN标识清楚。原01:45:40锚点未正面显示标识，已改为01:48:20。同场灰色MOXIAOMIAO须排除。",
          "windows": [
            [
              5607,
              6698
            ]
          ],
          "visual_anchors_seconds": [
            6400,
            6500
          ],
          "review_date": "2026-10-07",
          "timing_label": "01:33:27—01:51:38",
          "timing_status": "回查时间段",
          "talk_segments": [
            {
              "start": 5607.0,
              "end": 6698.0,
              "title": "YUXIAODIAN标识磁吸外接电池",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-07/2026-10-07-original-7c0c62f57224/Codex-content-analysis-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）"
            }
          ],
          "talk_status": "已有审校内容分段"
        },
        {
          "recording_id": "M-86812a16b84ea2cb",
          "basis": "2026-10-16按多色外观复核；紫色及同场多色展示；2790.04秒铭牌BK005L/10000mAh、2795.04秒YUXIAODIAN及支架电量屏近景",
          "windows": [
            [
              2353,
              3570.64
            ]
          ],
          "visual_anchors_seconds": [
            2790.04,
            2795.04
          ],
          "review_date": "2026-10-08",
          "timing_label": "00:39:13—00:59:30",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        }
      ],
      "evidence": "2026-10-16本次原录像与商品页外观核对",
      "image_source": "商品链接原图",
      "footage_image": "product-images/PF-d43b70e1.jpg",
      "link_override": true,
      "product_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3844283467328258512&origin_type=604&channel_id=3380051563131941&channel_type=4",
      "link_name": "【猫哥专属】娱小电【3C认证】超薄折叠支架磁吸q12外接电池PD充电宝金属无线充",
      "link_source": "用户提供商品页，2026-10-16实物外观核对",
      "link_status": "推广核实正常（2026-10-26核对）；库存另核",
      "image": "https://p3-item.ecombdimg.com/img/ecom-shop-material/png_m_7250cb123c5e4a5d82b2f13e173ec5ef_sx_2162650_www1279-1279~tplv-5mmsx3fupr-resize_q:1080:1080:q90.webp",
      "verification": {
        "checked_at": "2026-10-21",
        "basis": "实时商品页品牌娱小电/型号BK005；重新抽取9月11日1800秒、10月7日6400/6500秒、10月8日2795.04秒原帧，确认YUXIAODIAN标识与支架圆屏结构；最新分析目录v75截至10月20日未见新增对应场次。",
        "evidence_folder": "/Users/szx/Movies/gpt/娱小电商品复核_20261021/证据",
        "latest_catalog_checked": "catalog-20261021-oct20-seven-products-v75",
        "excluded_candidates": [
          {
            "date": "2026-09-22",
            "recording": "2026.9.22-1.mp4",
            "anchor_seconds": 3900,
            "reason": "橙色大矩形显示窗款，与本组圆形电量屏结构不同，不关联为同款"
          }
        ],
        "recheck_result": "保留6场：3场同标识、3场异标识外观参考；本次未新增日期。最新分析目录中未找到10月8日之后新增的该标识记录，未逐帧穷尽全部录像。",
        "identity": "YUXIAODIAN标识款，9月起已核查3场：9月11日、10月7日、10月8日。MOXIAOMIAO款已分到另一条商品，不再作为本款素材。",
        "visual_scope": "2026年9月1日起；仅YUXIAODIAN标识，MOXIAOMIAO独立归档",
        "status": "3场标识与外观对应；10月7日近景定位已纠正",
        "reference_recordings": [],
        "name": "娱小电 BK005 折叠支架磁吸外接电池（多色外观核查）"
      },
      "candidate_links": [],
      "link_audit": {
        "id": "PF-d43b70e1",
        "name": "【猫哥专属】娱小电【3C认证】超薄折叠支架磁吸q12外接电池PD充电宝金属无线充",
        "old_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3844283467328258512&origin_type=604&channel_id=3380051563131941&channel_type=4",
        "promotion_status": "推广核实正常",
        "page_status": "库存未于本轮重新核查",
        "source_rows": [
          {
            "name": "娱小店／娱小电磁吸支架充电宝（猫哥专属）",
            "row_id": "192",
            "text": "\t\n娱小店／娱小电磁吸支架充电宝（猫哥专属）\n外接电池 · ID 3844283467328258512\n\t99\t32%\t\n32%\n\t正常\n10/26 07:01\n\t2026/9/23\t\n复制"
          }
        ],
        "checked_at": "2026-10-26",
        "source": "原商品工作台当日07:00—07:09只读结果"
      }
    },
    {
      "id": "PF-link-3841919966068736228",
      "name": "MOXIAOMIAO 折叠支架磁吸充电宝（多色）",
      "category": "充电与手机配件",
      "aliases": [
        "MOXIAOMIAO",
        "芯电速能",
        "3841919966068736228"
      ],
      "description": "独立于娱小电YUXIAODIAN款。商品主图可见MOXIAOMIAO、折叠支架及圆形电量屏；9月起素材已核查9月11日、12日、14日、17日及10月7日，共5场。9月11日及10月7日两种标识同场展示，按具体实物区分。",
      "cautions": [
        "按可见MOXIAOMIAO印字及机身、磁环、支架、电量屏结构关联，不自动确认所有颜色容量为相同SKU。",
        "同场包含另一款YUXIAODIAN，使用素材需按标识选择；1秒窗口仅为同框证据定位。",
        "页面中的3C、快充与登机等宣传未独立核验。"
      ],
      "appearances": [
        {
          "recording_id": "M-aedd8cfb4cc4e65a",
          "basis": "【MOXIAOMIAO独立商品】9月12日银灰/橙色MOXIAOMIAO；2240/2500/2550秒核对同结构；标识及结构与第二链接主图对应，具体容量SKU待逐件核对",
          "windows": [
            [
              2180,
              2900
            ]
          ],
          "visual_anchors_seconds": [
            2240,
            2500,
            2550
          ],
          "timing_label": "00:36:20—00:48:20",
          "timing_status": "回查时间段",
          "talk_segments": [
            {
              "start": 2183.0,
              "end": 2215.0,
              "title": "磁吸与容量描述",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-16_2026-09-14/content-v2/reviewed/2026-09-12_2026.9.12/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 2234.0,
              "end": 2279.0,
              "title": "有线无线功率和赠品口述",
              "aspect": "参数与性能说明",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-16_2026-09-14/content-v2/reviewed/2026-09-12_2026.9.12/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 2430.08,
              "end": 2494.08,
              "title": "99/129两档容量报价及补电限制",
              "aspect": "价格与套餐",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-16_2026-09-14/content-v2/reviewed/2026-09-12_2026.9.12/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 2598.08,
              "end": 2639.08,
              "title": "无无线能力时用有线及磁吸环",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-16_2026-09-14/content-v2/reviewed/2026-09-12_2026.9.12/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 2872.08,
              "end": 2881.08,
              "title": "5000mAh不能完整充满的限制",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-16_2026-09-14/content-v2/reviewed/2026-09-12_2026.9.12/segments.json",
              "clock": "已有审校回查时间"
            }
          ],
          "talk_status": "已有审校内容分段"
        },
        {
          "recording_id": "M-e0f2c319fea3cfe5",
          "basis": "【MOXIAOMIAO独立商品】9月14日灰色/橙色MOXIAOMIAO；5824.64/6315.86秒同结构，标识及结构与第二链接主图对应，具体容量SKU待逐件核对",
          "windows": [
            [
              5266.66,
              6341.76
            ]
          ],
          "visual_anchors_seconds": [
            5824.64,
            6315.86
          ],
          "timing_label": "01:27:46—01:45:41",
          "timing_status": "回查时间段",
          "talk_segments": [
            {
              "start": 5266.66,
              "end": 5272.5,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "我們上個蘋果手機必備原裝配件 蘋果手機必備原裝配件來",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 5279.86,
              "end": 5292.86,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "外接电池听说过没有 外接电池啊 就是你担心电池有审浩的就买外接电池吧",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 5311.06,
              "end": 5315.06,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "因为换个电池挺贵的 你要不出现在买个外机电池",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 5327.06,
              "end": 5329.86,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "外机电池 目前应该是最牛逼的外机电池",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 5369.46,
              "end": 5370.46,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "用外积电池之后",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 5372.46,
              "end": 5374.46,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "直接显示MIG XI的外积电池",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 5411.7,
              "end": 5439.3,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "因為外籍電池它是通過蘋果原裝U2芯片來轉換 你手机在工作的时候里面的电池停止工作了 就是对里面电池没有任何审耗了 那他为什么一个充电来 他是先供主板 主板多于是供内在供给电池 所以他跟充电宝不一样 充电宝就是给手机电池充电 外积电池直接给主板供电 冷保护手机的电池就这样子",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 5440.38,
              "end": 5444.38,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "原来电池一个700块钱 对不对 对 外积电池多少钱 官方还是卖700块钱",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 5444.38,
              "end": 5446.94,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "所以你看外积电池给里面电池是一样的 是吧",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 5535.94,
              "end": 5537.94,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "只要支持无线充电的",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 5554.94,
              "end": 5573.24,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "兆兆兆可以充电 这些外地电池 它可以保护电池 所以外接电池",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 5573.24,
              "end": 5576.34,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "好 官方卖多少钱 700块钱 第三方安克贝尔金都卖600块钱",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 5587.64,
              "end": 5591.48,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "iPhone Air 专用MIDICSF 多少钱 800块钱 太贵了是不是",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 5605.32,
              "end": 5608.32,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "关键是他西带手机 给你苹果然章配件一样来",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 5620.84,
              "end": 5622.24,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "这是5000毫安时的",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 5623.24,
              "end": 5624.24,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "我看你能不能甩掉",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 5639.64,
              "end": 5642.04,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "这个外接电池材料跟苹果手机的外壳",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 5651.98,
              "end": 5654.28,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "可以做一个手机支架 是不是挺好的",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 5673.24,
              "end": 5675.02,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "你的手机没有无线充电",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 5685.02,
              "end": 5687.02,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "先不受价格价格肯定是更强的",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 5698.02,
              "end": 5716.06,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "五千毫安时的看效 外积电池保一点 五千毫安时可以给你的PoreMex 就是这种PoreMex 一万毫安时的可以给你的PoreMex充14半左右",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 5723.48,
              "end": 5726.04,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "我先叫怎么写 先不说价格 价格保证最强的",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 5761.68,
              "end": 5768.28,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "然后三种颜色看下 那个三种颜色 白色 银色的",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 5788.64,
              "end": 5789.92,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "我们这些多少钱",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 5796.32,
              "end": 5799.64,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "不要再买充电宝了 特别是苹果手机的啊 直接因为电池",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 5799.9,
              "end": 5800.68,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "换个电池要700块钱",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 5800.94,
              "end": 5810.14,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "你换了第三方 访电池都保佑了 发现了没有 为什么不在电池 多用外机电池 电池电量高度了 卖不少钱啊",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 5811.42,
              "end": 5821.12,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "然后今天这个他多少钱 我们直接赶到99块钱长车",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 5826.24,
              "end": 5829.04,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "艱固的手機的旅遊金支架",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 5849.72,
              "end": 5853.82,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "好了就是你忘了賣一百二十九點金你要的一個容量點金費就夠買",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 5936.42,
              "end": 5937.92,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "然後送兩個磁吸環",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 6011.28,
              "end": 6015.0,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "然后一万毫安的很多人说 它的细力紧不紧一万毫安知道",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 6040.34,
              "end": 6041.34,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "现在人家要颜色",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 6195.8,
              "end": 6198.84,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "很多人说,现在有什么班固态电池,班固态电池",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 6225.6,
              "end": 6230.6,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "所以有时候你要便宜一点 质量品牌 价格都要看一小",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 6236.6,
              "end": 6239.6,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "然后是它是相着一个苹果的原装配件",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 6242.6,
              "end": 6245.6,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "充电宝是直接到电池 电池再到主板",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 6248.6,
              "end": 6251.6,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "一个手表的充电线 卖多少钱 卖两三百块钱",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 6251.6,
              "end": 6254.6,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "它这相当替代了手表的无线充电",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 6289.6,
              "end": 6295.96,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "下月再给10块钱 下月再给10块 5000号完的你可以先试下月给8块钱",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 6302.52,
              "end": 6303.8,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "除了不能充笔记本",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 6321.6,
              "end": 6323.6,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "它这个材质跟苹果手机可是一样的",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            }
          ],
          "talk_status": "转写内容初标，需回听核查"
        },
        {
          "recording_id": "M-2d78fe26965cda89",
          "basis": "【MOXIAOMIAO独立商品】9月17日紫色MOXIAOMIAO；6757/6803秒可见相同支架、圆形电量屏及磁环结构，标识及结构与第二链接主图对应，具体容量SKU待逐件核对",
          "windows": [
            [
              6353.26,
              7347.1
            ]
          ],
          "visual_anchors_seconds": [
            6757,
            6803
          ],
          "review_date": "2026-09-17",
          "timing_label": "01:45:53—02:02:27",
          "timing_status": "回查时间段",
          "talk_segments": [
            {
              "start": 6369.5,
              "end": 6379.54,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "还有一个颜色在那里 就四个颜色",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 6389.54,
              "end": 6393.9,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "这个真的价格很便宜啊 那个 也是我目前接的价格便宜",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 6395.78,
              "end": 6402.06,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "外接电池听说过没有 就是苹果手机电池越来越不精英",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 6418.74,
              "end": 6421.8,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "基本上用两年以上的屏幕手机人还比较多的 对不对",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 6434.58,
              "end": 6454.26,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "然后来屏幕手机其实他最最最让大家可能 没有几个人会感觉屏幕手机卡 然后来如果你的屏幕手机续航不难用 没必要换电池 你可以买一个外接电池",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 6454.26,
              "end": 6456.26,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "换个苹果原则电池要700块钱",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 6456.26,
              "end": 6458.26,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "外接电池它为什么叫外接",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 6458.26,
              "end": 6461.26,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "它类似于官方的苹果手机的原则配件",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 6469.26,
              "end": 6475.26,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "下面是外接电池的电量 为什么它是属于苹果手机的原则电池",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 6480.26,
              "end": 6482.26,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "通用里面直接显示",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 6482.26,
              "end": 6483.26,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "没几个赛外机电池 看来没有",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 6483.26,
              "end": 6485.26,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "这显示没几个赛外机电池",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 6499.26,
              "end": 6501.26,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "外机电池 外机电池什么含义",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 6529.78,
              "end": 6533.34,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "你會注意到這一點 注意到电池健康",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 6535.34,
              "end": 6547.34,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "像我的用一年电池效率就是94% 如果你用外接电池的情况下 基本上你的电池喜欢这种不怎么增加 这就是外接电池比充电宝的女朋友",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 6552.34,
              "end": 6557.34,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "特别是这个颜色负地 这是给iPhone 18专配的颜色",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 6563.82,
              "end": 6567.54,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "比你买充电宝华算你买充电宝金 没他好用",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 6605.34,
              "end": 6611.34,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "是不要有问题吧这个 不能呢",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 6625.84,
              "end": 6630.44,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "它只有苹果手表的专用线 现在卖多少钱 卖300多块钱",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 6630.44,
              "end": 6634.44,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "就很多人苹果手表带出去 你发现有些人带苹果手表 你要去看一下",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 6738.24,
              "end": 6743.12,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "这就是外积电池 比你买个充电宝屌吧 然后今天这个外积电池给你看一下",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 6765.6,
              "end": 6775.1,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "航天機的一個支架 來可以做一個手機支架 可以做手機支架 然後可以素品支架 可以那個支撐的支架",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 6894.7,
              "end": 6897.1,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "這官方畢竟賣700元",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 6925.34,
              "end": 6928.86,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "然后来今天我们直接特架多少钱 多少钱",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 6928.86,
              "end": 6933.3,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "如果这些颜色没有把今天新出的颜色 今天新出的颜色就是爱给iPhone是吧",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 6941.06,
              "end": 6966.14,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "多少钱 官方的卖799块钱 是吧 第三方安克贝尔金的卖多少钱 599块钱 然后我们多少钱 我们直接干到29 官方的没几个赛红卖多少钱",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 6966.94,
              "end": 6970.74,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "这个真的省你省得你去换个苹果电池",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 6970.74,
              "end": 6978.74,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "让我们多少钱 99块钱",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 6981.58,
              "end": 6988.58,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "外接电池99 2号的电池",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 6988.58,
              "end": 6992.46,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "看一下四种颜色 今天有最新款的颜色",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 7096.58,
              "end": 7098.74,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "對,因為容量也差一半",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 7112.78,
              "end": 7114.78,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "选择人家的容量点击购买",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 7114.78,
              "end": 7117.78,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "如果究竟颜色就选出了这个新负品",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 7120.78,
              "end": 7124.78,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "今天不花钱下月给10块 下月再给10块钱",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 7135.78,
              "end": 7137.3,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "对 这个颜色是吧",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 7150.18,
              "end": 7152.18,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "那个 平时还给当手机支架",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 7163.78,
              "end": 7165.74,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "今天价格其实比买个充电宝还便宜",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 7174.14,
              "end": 7175.42,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "下个月付八块钱",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 7175.42,
              "end": 7176.9,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "一万毫安的你可以选择分析",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 7185.18,
              "end": 7187.5,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "一样的就是一万毫安 外界电池这个叫外界电池",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 7194.38,
              "end": 7195.66,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "上了一样的电池面",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 7289.24,
              "end": 7290.6,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "颜色再给你看一下",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 7300.96,
              "end": 7306.24,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "还有一个颜色 就用这个颜色就可以了",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 7310.72,
              "end": 7312.32,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "不能用当年的iPhone 4",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            }
          ],
          "talk_status": "转写内容初标，需回听核查"
        },
        {
          "recording_id": "M-f1b53e17b0fdd984",
          "basis": "9月11日橙色机身MOXIAOMIAO清楚，与灰色YUXIAODIAN同框，分别归档",
          "windows": [],
          "visual_anchors_seconds": [
            1800
          ],
          "timing_label": "00:30:00（橙色MOXIAOMIAO；完整起止待核）",
          "timing_status": "已确认画面时刻",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-aa5b92644f8170bb",
          "basis": "2026-10-21复核10月7日6300秒原帧，桌面灰色MOXIAOMIAO清楚；手持紫色为另一款娱小电，不能混用。",
          "windows": [],
          "visual_anchors_seconds": [
            6300
          ],
          "timing_label": "01:45:00（桌面灰色MOXIAOMIAO；完整起止待核）",
          "timing_status": "已确认画面时刻",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        }
      ],
      "product_url": "https://alliance.jinritemai.com/merchants/alliance-general-share?promotion_id=3841919966068736228",
      "link_name": "MOXIAOMIAO 磁吸无线快充充电宝（芯电速能）",
      "link_source": "用户提供，2026-10-19要求独立建档",
      "link_status": "推广链接失效（2026-10-26核对）；库存另核；暂无有效同款替换",
      "candidate_links": [],
      "link_override": true,
      "verification": {
        "status": "实时商品主图与录像印字、结构对应，5场",
        "basis": "重新核对9月11日1800秒、9月12日2500秒、9月14日5824.64秒、9月17日6757秒、10月7日6300秒的机身MOXIAOMIAO印字；本次联盟页未完整加载，商品主图身份沿用2026-10-19已查看页面。",
        "identity": "独立于娱小电YUXIAODIAN款。商品主图可见MOXIAOMIAO、折叠支架及圆形电量屏；9月起素材已核查9月11日、12日、14日、17日及10月7日，共5场。9月11日及10月7日两种标识同场展示，按具体实物区分。",
        "product_url": "https://alliance.jinritemai.com/merchants/alliance-general-share?promotion_id=3841919966068736228",
        "visual_scope": "2026-09-01起，MOXIAOMIAO独立归档，不与YUXIAODIAN合并",
        "name": "MOXIAOMIAO 折叠支架磁吸充电宝（多色）",
        "checked_at": "2026-10-21"
      },
      "image": "https://p9-aio.ecombdimg.com/obj/ecom-shop-material/jpeg_m_1f7b45011f6ca6991bc8f5881bf29f6a_sx_195144_www2200-2200",
      "image_source": "2026-10-19实时联盟商品页主图",
      "link_audit": {
        "id": "PF-link-3841919966068736228",
        "name": "MOXIAOMIAO 磁吸无线快充充电宝（芯电速能）",
        "old_url": "https://alliance.jinritemai.com/merchants/alliance-general-share?promotion_id=3841919966068736228",
        "promotion_status": "推广链接失效",
        "page_status": "库存未于本轮重新核查",
        "source_rows": [
          {
            "name": "膜小喵外接电池",
            "row_id": "181",
            "text": "\t\n膜小喵外接电池\n未分类\n\t99\t35.00%\t\n35%\n上次成功 10/19 07:01\n\t链接失效\n10/26 07:01\n\t2026/9/15\t\n复制"
          }
        ],
        "checked_at": "2026-10-26",
        "source": "原商品工作台当日07:00—07:09只读结果"
      }
    },
    {
      "id": "PF-03d5649d",
      "name": "山水 W165／夹耳耳机（逐场核型）",
      "category": "耳机",
      "aliases": [
        "山水SANSUI W165夹耳式蓝牙耳机（App显示）",
        "山水SANSUI W165夹耳耳机（App标识；商品页型号冲突）",
        "山水SANSUI W165耳夹式蓝牙耳机（三色）",
        "山水SANSUI夹耳式耳机（App完整型号未清）",
        "山水SANSUI夹耳式耳机（本款型号未核）",
        "山水W165耳夹式蓝牙耳机（三色）",
        "SANSUI W165耳夹式耳机（App型号）",
        "夹耳式蓝牙耳机（口述品牌疑似山水，型号待核）",
        "SANSUI山水 W165夹耳式蓝牙耳机",
        "SANSUI山水夹耳式蓝牙耳机（本日具体型号待核）"
      ],
      "description": "扁椭圆翻盖充电仓、金属光泽夹耳组件，包装白底黄边；黑、粉、白分别核对，不以仓色推断型号。 三场外观已复核，保留原有细分时间段；W165具体型号及各颜色仍需逐场读包装。",
      "cautions": [
        "双麦“通话降噪”不等于已验证主动降噪ANC；没有双方通话录音或音质对比。",
        "品牌创立年份口述/ASR出现1940／1944／1914，不据此定年；型号仍待核。",
        "三场外观已复核，保留原有细分时间段；W165具体型号及各颜色仍需逐场读包装。",
        "外观复核仅确认画面对应关系，不代替型号、配置或商品链接SKU核对。"
      ],
      "appearances": [
        {
          "recording_id": "M-279e35aebe55abba",
          "recording_name": "2026.7.2_原版.mp4",
          "date": "2026-07-02",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              700.46,
              729.94
            ],
            [
              736.14,
              965.66
            ],
            [
              967.66,
              1026.3
            ],
            [
              1028.8,
              1074.28
            ],
            [
              1076.28,
              1160.72
            ],
            [
              1165.36,
              1181.32
            ]
          ],
          "visual_identity": "扁椭圆翻盖充电仓、金属光泽夹耳组件，包装白底黄边；黑、粉、白分别核对，不以仓色推断型号。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "原有分析时间段，结合抽帧复核；正式剪辑仍需逐段回看。",
          "evidence": "2026.7.2_原版",
          "visual_anchors_seconds": [],
          "timing_label": "00:11:40—00:12:09、00:12:16—00:16:05、00:16:07—00:17:06、00:17:08—00:17:54、00:17:56—00:19:20、00:19:25—00:19:41",
          "timing_status": "回查时间段",
          "talk_segments": [
            {
              "start": 700.46,
              "end": 729.94,
              "title": "山水耳机引入，清库存尾货/大品牌主张。",
              "aspect": "讲解内容",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-02_2026.7.2_原版/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 736.14,
              "end": 825.52,
              "title": "山水品牌/1944年历史及授权归属争论，均未独立查证。",
              "aspect": "讲解内容",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-02_2026.7.2_原版/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 825.52,
              "end": 887.88,
              "title": "黑白紫三色开盒、耳夹/挂耳形态与399参考价，不把70万销量当已核。",
              "aspect": "外观与配件",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-02_2026.7.2_原版/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 887.88,
              "end": 932.96,
              "title": "发声孔/双麦通话降噪/佩戴，不能据此认定主动降噪或机场通话已测试。",
              "aspect": "使用边界",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-02_2026.7.2_原版/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 933.48,
              "end": 965.66,
              "title": "App电量/按键/均衡/查找/翻译/睡眠菜单，仅看界面。",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-02_2026.7.2_原版/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 967.66,
              "end": 1026.3,
              "title": "99总价，1020页8.25×12期，月付不是总价。",
              "aspect": "价格与套餐",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-02_2026.7.2_原版/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 1028.8,
              "end": 1074.28,
              "title": "续航7小时/音质/使用两三年和价差比较为口述，未长测。",
              "aspect": "参数与性能说明",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-02_2026.7.2_原版/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 1076.28,
              "end": 1121.76,
              "title": "苹果华为适配与再次分期，品牌历史比价口述。",
              "aspect": "价格与套餐",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-02_2026.7.2_原版/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 1121.76,
              "end": 1160.72,
              "title": "生活防水/不可以戴着游泳，氛围灯和外观；限制不能删。",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-02_2026.7.2_原版/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 1165.36,
              "end": 1181.32,
              "title": "定向传音外观展示收尾，未独立声学测试。",
              "aspect": "外观与配件",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-02_2026.7.2_原版/segments.json",
              "clock": "已有审校回查时间"
            }
          ],
          "talk_status": "已有审校内容分段"
        },
        {
          "recording_id": "M-f82d16669b7a7d7c",
          "recording_name": "2026.7.9_原版.mp4",
          "date": "2026-07-09",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              906.0,
              957.08
            ],
            [
              958.28,
              1054.62
            ],
            [
              1066.42,
              1155.72
            ],
            [
              1156.82,
              1347.2
            ],
            [
              1359.76,
              1435.08
            ]
          ],
          "visual_identity": "扁椭圆翻盖充电仓、金属光泽夹耳组件，包装白底黄边；黑、粉、白分别核对，不以仓色推断型号。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "原有分析时间段，结合抽帧复核；正式剪辑仍需逐段回看。",
          "evidence": "2026.7.9_原版",
          "visual_anchors_seconds": [],
          "timing_label": "00:15:06—00:15:57、00:15:58—00:17:34、00:17:46—00:19:15、00:19:16—00:22:27、00:22:39—00:23:55",
          "timing_status": "回查时间段",
          "talk_segments": [
            {
              "start": 906.0,
              "end": 957.08,
              "title": "山水耳机库存尾货/原价/销量介绍，品牌合作与销量未核。",
              "aspect": "讲解内容",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-09_2026.7.9_原版/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 958.28,
              "end": 1042.54,
              "title": "黑紫白三色、充电仓和耳夹佩戴、7—8小时及双麦通话降噪。",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-09_2026.7.9_原版/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 1042.54,
              "end": 1054.62,
              "title": "手机兼容及参考销量价格。",
              "aspect": "价格与套餐",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-09_2026.7.9_原版/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 1066.42,
              "end": 1107.86,
              "title": "App电量/查找/游戏音乐/翻译AI/睡眠菜单；没有实际翻译通话效果验证。",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-09_2026.7.9_原版/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 1107.86,
              "end": 1155.72,
              "title": "三色库存与最终99元；先前399等为参考价。",
              "aspect": "价格与套餐",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-09_2026.7.9_原版/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 1156.82,
              "end": 1209.0,
              "title": "12期分期和库存变化；8元不是总价，1200秒附近ASR重叠0.06秒。",
              "aspect": "价格与套餐",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-09_2026.7.9_原版/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 1209.0,
              "end": 1291.16,
              "title": "双麦和续航/跑步不掉主张、黑白颜色与佩戴柔软；无运动实测。",
              "aspect": "外观与配件",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-09_2026.7.9_原版/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 1291.96,
              "end": 1315.8,
              "title": "转手机前继续耳机分期与一周中度续航口述。",
              "aspect": "价格与套餐",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-09_2026.7.9_原版/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 1315.8,
              "end": 1347.2,
              "title": "双麦孔/模具/兼容性答疑，未同条件横评。",
              "aspect": "讲解内容",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-09_2026.7.9_原版/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 1359.76,
              "end": 1429.04,
              "title": "99与12期再次操作，适用年龄/材质仅主观口述。",
              "aspect": "外观与配件",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-09_2026.7.9_原版/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 1429.04,
              "end": 1435.08,
              "title": "不同日期耳机不同，禁止套用前日型号。",
              "aspect": "讲解内容",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-09_2026.7.9_原版/segments.json",
              "clock": "已有审校回查时间"
            }
          ],
          "talk_status": "已有审校内容分段"
        },
        {
          "recording_id": "M-961593fedd8eadd5",
          "recording_name": "2026.7.20.mp4",
          "date": "2026-07-20",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              5262.32,
              5554.6
            ],
            [
              5569.8,
              5585.84
            ],
            [
              5587.16,
              5658.64
            ],
            [
              5680.76,
              5698.08
            ]
          ],
          "visual_identity": "扁椭圆翻盖充电仓、金属光泽夹耳组件，包装白底黄边；黑、粉、白分别核对，不以仓色推断型号。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "原有分析时间段，结合抽帧复核；正式剪辑仍需逐段回看。",
          "evidence": "2026.7.20",
          "visual_anchors_seconds": [],
          "timing_label": "01:27:42—01:32:34、01:32:49—01:33:05、01:33:07—01:34:18、01:34:40—01:34:58",
          "timing_status": "回查时间段",
          "talk_segments": [
            {
              "start": 5262.32,
              "end": 5554.6,
              "title": "山水夹耳耳机黑白紫、佩戴、双麦口述、99/12期8.25；无通话降噪或音质对测。",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-20_2026.7.20/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 5587.16,
              "end": 5658.64,
              "title": "黑白紫外观与佩戴、一年保修口述。",
              "aspect": "外观与配件",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-20_2026.7.20/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 5680.76,
              "end": 5698.08,
              "title": "山水耳机稳定性和使用者反馈邀请，没有实际样本数据。",
              "aspect": "讲解内容",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-20_2026.7.20/segments.json",
              "clock": "已有审校回查时间"
            }
          ],
          "talk_status": "已有审校内容分段"
        }
      ],
      "evidence": "payload.json",
      "image_source": "2026-10-24新链接主图",
      "visual_candidates": [],
      "visual_reviewed_at": "2026-10-12",
      "product_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3849141369469796551&origin_type=604",
      "link_name": "山水W165耳夹式长续航蓝牙耳机智能翻译高清通话商务办公通用耳机",
      "link_source": "原商品工作台2026-10-24核实正常；实时商品页品牌型号和主图复核",
      "link_status": "推广核实正常（2026-10-26核对）；库存另核",
      "binding_scope": "仅按以下已核对实物画面使用；其他日期、容量、颜色及具体配置不能自动套用：已查看素材目录实物缩略图；2026.7.20.mp4源5350.000秒为补充仓体观察",
      "appearance_match": "圆润充电仓、正面圆形设计和耳夹轮廓对应；商品页型号为W165，素材多场次仍按日期核型",
      "appearance_checked_at": "2026-10-12T09:30:04.695093+08:00",
      "image": "https://p26-item.ecombdimg.com/img/ecom-shop-material/png_m_9c368a62d9df10efb09a1afe5118735e_sx_1446129_www1440-1440~tplv-5mmsx3fupr-resize_q:1080:1080:q90.webp",
      "link_audit": {
        "id": "PF-03d5649d",
        "name": "山水W165耳夹式长续航蓝牙耳机智能翻译高清通话商务办公通用耳机",
        "old_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3849141369469796551&origin_type=604",
        "promotion_status": "推广核实正常",
        "page_status": "库存未于本轮重新核查",
        "source_rows": [
          {
            "name": "山水W165耳机（默认新链接）",
            "row_id": "208",
            "text": "\t\n山水W165耳机（默认新链接）\n未分类 · ID 3849141369469796551\n\t99\t40%\t\n40%\n\t正常\n10/26 07:00\n\t2026/10/20\t\n复制"
          }
        ],
        "checked_at": "2026-10-26",
        "source": "原商品工作台当日07:00—07:09只读结果"
      },
      "link_history": [
        {
          "url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3843382870584459604&origin_type=604",
          "name": "山水耳机",
          "replaced_at": "2026-10-24",
          "reason": "原站推广失效，替换同型号正常新链接"
        }
      ],
      "link_override": true
    },
    {
      "id": "PF-1eabc888",
      "name": "华硕a豆 Watch Fit S1Max",
      "category": "手表",
      "aliases": [
        "华硕a豆 Watch Fit S1Max 智能手表套装"
      ],
      "description": "圆角方形薄表体、侧面按键、黑色表带，与a豆薄款手表原有画面对应。 7月23日外观已复核，保留原时间段。本轮未确认新增同款日期。",
      "cautions": [
        "Apple Watch硬件/传感器一样和最准确均未独立证明；不是苹果产品或官方平替认证。",
        "手机对讲机软件当时未公开上架，未来手表版仅计划。",
        "7月23日外观已复核，保留原时间段。本轮未确认新增同款日期。",
        "外观复核仅确认画面对应关系，不代替型号、配置或商品链接SKU核对。"
      ],
      "appearances": [
        {
          "recording_id": "M-eb3a69ed345be4c5",
          "recording_name": "2026.7.23.mp4",
          "date": "2026-07-23",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              1206.0,
              1848.86
            ]
          ],
          "visual_identity": "圆角方形薄表体、侧面按键、黑色表带，与a豆薄款手表原有画面对应。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "原有分析时间段，结合抽帧复核；正式剪辑仍需逐段回看。",
          "evidence": "2026.7.23",
          "visual_anchors_seconds": [],
          "timing_label": "00:20:06—00:30:48",
          "timing_status": "回查时间段",
          "talk_segments": [
            {
              "start": 1206.0,
              "end": 1848.86,
              "title": "华硕a豆Watch Fit S1Max及Apple Watch类比、薄轻、菜单、水箱展示、299与耳机赠品；页面12期每期24.92，最后录音答疑；开头夹Mate手机直屏答疑。",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-23_2026.7.23/segments.json",
              "clock": "已有审校回查时间"
            }
          ],
          "talk_status": "已有审校内容分段"
        }
      ],
      "evidence": "payload.json",
      "image_source": "商品链接原图",
      "visual_candidates": [],
      "visual_reviewed_at": "2026-10-12",
      "product_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3832464685567967613&origin_type=604&channel_id=3700024435352834&channel_type=4",
      "link_name": "华硕手表",
      "link_source": "原商品库只读查询，同型号按本次列表最新顺序优先",
      "link_status": "推广链接失效（2026-10-26核对）；库存另核；暂无有效同款替换",
      "image": "https://p26-item.ecombdimg.com/img/ecom-shop-material/png_m_a14b521b3c2544c817470b8588ba21bb_sx_303211_www800-800~tplv-5mmsx3fupr-resize_q:1080:1080:q90.webp",
      "link_audit": {
        "id": "PF-1eabc888",
        "name": "华硕手表",
        "old_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3832464685567967613&origin_type=604&channel_id=3700024435352834&channel_type=4",
        "promotion_status": "推广链接失效",
        "page_status": "库存未于本轮重新核查",
        "source_rows": [
          {
            "name": "华硕手表",
            "row_id": "157",
            "text": "\t\n华硕手表\n未分类 · ID 3832464685567967613\n\t299\t43.00%\t\n43%\n上次成功 10/24 07:02\n\t链接失效\n10/26 07:02\n\t2026/9/15\t\n复制"
          }
        ],
        "checked_at": "2026-10-26",
        "source": "原商品工作台当日07:00—07:09只读结果"
      }
    },
    {
      "id": "PF-24538be1",
      "name": "华为 Pura 80 Pro（12GB＋512GB／1TB需分款）",
      "category": "手机",
      "aliases": [
        "华为Pura 80 Pro（12GB+512GB口述）",
        "华为Pura 80 Pro 12GB+512GB（待核）",
        "华为HUAWEI Pura 80 Pro 12GB＋512GB LMR-AL00（官方资源机口径）",
        "华为Pura 80 Pro 12GB＋512GB（资源机）",
        "华为Pura 80 Pro 12GB＋1TB／512GB（资源机）"
      ],
      "description": "圆角三角相机岛、三圆镜头不等大，配合HUAWEI Pura系列白盒核对；同场基础款/Pro/Pro+与容量不能只看背面确定。 补充9月20、22、23日相同Pura机身外观组；9月16日回查末段111—121分钟。新增场次型号/容量/颜色需读包装或设置页，不据外观直接套用现有链接配置。",
      "cautions": [
        "9月26日第二段画面清楚显示 Pura80 Pro 包装；包装不证明每台已展示手机的容量、真伪、未拆封或机况。 不同日期、不同容量与颜色不能直接视为同一销售 SKU。 主播关于官方保修、货源、价格、分期及拍照性能的说法尚未独立核实。 容量、机况与具体报价以对应录屏和逐台证据为准；现有分析用于选品，精确剪辑时码尚未验收。 10月4日原帧可读HUAWEI Pura80 Pro，未显示Pro+；本场12+512与白色为主播说明，不与其他日期的1TB款合并SKU。 10月4日全新、未激活、官方联保、4199及12期口述均未独立核购买页或逐台机况，不作为购机承诺。 10月4日本项实物出现已核实；原音疑点与精确音画时码继续审核，属于产品级部分上线，不计整場交付。",
        "10月3日第一段包装明确HUAWEI Pura80 Pro，Pro+是比较对象；12+512与具体芯片、材质、性能均为当日口述，不能套其他场容量。 拆封演示机缺电并非逐台新原封证明。4199与349月付为不同语境，免息需账号及平台资格；官方货源、保修和13点发票均未独立核。 10月3日第一段本项仅作经核实的产品或版本讲解出现记录；原音与精确音画时码继续审校，属于部分上线，不计整场交付。",
        "10月8日可读HUAWEI Pura80 Pro包装与白色手机外观，Pro与Pro+分开。展机已拆封；原封未激活、新机、官方联保及发票为销售口述，未逐台验证。板书和口述12+512不保证所有库存配置一致；最终整机报价误识尚待原音，349为月付，免息资格与费用需实际订单核对。 本项仅产品级部分审核，不计本场整场交付。",
        "补充9月20、22、23日相同Pura机身外观组；9月16日回查末段111—121分钟。新增场次型号/容量/颜色需读包装或设置页，不据外观直接套用现有链接配置。",
        "外观复核仅确认画面对应关系，不代替型号、配置或商品链接SKU核对。"
      ],
      "appearances": [
        {
          "recording_id": "M-e0f2c319fea3cfe5",
          "recording_name": "2026.9.14.mp4",
          "date": "2026-09-14",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              3150,
              3930
            ]
          ],
          "visual_identity": "圆角三角相机岛、三圆镜头不等大，配合HUAWEI Pura系列白盒核对；同场基础款/Pro/Pro+与容量不能只看背面确定。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "抽帧定位的回查范围，可能包含转场或其他产品，不是精确剪辑边界。",
          "evidence": "2026.9.14",
          "visual_anchors_seconds": [],
          "timing_label": "00:52:30—01:05:30",
          "timing_status": "回查时间段",
          "talk_segments": [
            {
              "start": 3173.16,
              "end": 3182.56,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "它有我们机中颜色 三个颜色 我就拆一个颜色 这个什么颜色",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 3206.76,
              "end": 3207.76,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "这个药的不要骗",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 3223.76,
              "end": 3226.76,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "原划原划原配件 原配件",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 3356.6,
              "end": 3358.88,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "这个屏幕是6.8英产的709.20",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 3359.76,
              "end": 3366.12,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "拍照应该是目前 属于目前的影像拍照期间",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 3391.72,
              "end": 3393.64,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "九零二零六點八英寸的屏幕",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 3429.36,
              "end": 3432.28,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "北斗卫星双向通讯6.8英寸的屏幕",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 3542.04,
              "end": 3551.54,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "好像六十瓦的五天快中了 一百瓦的有限充 一百瓦有限充 六點八因子的屏幕曲面屏",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 3555.24,
              "end": 3559.54,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "所以這台機器無論是影像還是遊戲還是拍照",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 3613.0,
              "end": 3615.0,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "往上方等於負十二級分期",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 3711.4,
              "end": 3713.72,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "但是它两个的拍照 拍照下午差不多",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 3740.24,
              "end": 3744.74,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "华为机器我真的 我最近显示它挺多的",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 3796.54,
              "end": 3798.54,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "你可以对比一下官方价格 卖多少钱",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 3861.34,
              "end": 3863.34,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "但是做不到9块9包油",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 3874.34,
              "end": 3875.34,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "6.9英声的屏幕",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 3920.0,
              "end": 3922.3,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "你現在還是買一個頂級旗艦拍照機器",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            }
          ],
          "talk_status": "转写内容初标，需回听核查"
        },
        {
          "recording_id": "M-371394ef849bd952",
          "recording_name": "2026.9.16.mp4",
          "date": "2026-09-16",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              6660,
              7290
            ]
          ],
          "visual_identity": "圆角三角相机岛、三圆镜头不等大，配合HUAWEI Pura系列白盒核对；同场基础款/Pro/Pro+与容量不能只看背面确定。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "抽帧定位的回查范围，可能包含转场或其他产品，不是精确剪辑边界。",
          "evidence": "2026.9.16",
          "visual_anchors_seconds": [],
          "timing_label": "01:51:00—02:01:30",
          "timing_status": "回查时间段",
          "talk_segments": [
            {
              "start": 6667.42,
              "end": 6669.42,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "要不要上个最便宜的",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-16_2026.9.16.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 6722.22,
              "end": 6723.86,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "我给它上最便宜价格",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-16_2026.9.16.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 6829.98,
              "end": 6834.58,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "後面的拍照是跟Mate 80 Pro Max 基本上一樣的",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-16_2026.9.16.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 6838.58,
              "end": 6840.68,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "裡面全套原裝全新的配件",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-16_2026.9.16.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 6849.18,
              "end": 6852.18,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "看一下原充100瓦的原裝充電頭",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-16_2026.9.16.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 6859.18,
              "end": 6863.78,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "他畢竟是華為的X-Magic 影像拍照旗艦",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-16_2026.9.16.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 6896.82,
              "end": 6905.82,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "6.5元這個 這個是6.5元 不是6.9元 這個 6.8元生的屏幕 困能玻璃取面屏",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-16_2026.9.16.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 6991.7,
              "end": 6993.58,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "这台机器外观没话说吧",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-16_2026.9.16.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 7054.7,
              "end": 7056.9,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "没有人把这个外观当成荣耀了 卖吧",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-16_2026.9.16.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 7060.34,
              "end": 7069.54,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "准备好啊 无线充电 有线是100瓦 无线充电是60瓦 60瓦 新闪通讯 双卡双带5.5G的网络",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-16_2026.9.16.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 7089.02,
              "end": 7091.02,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "9不要我們直接多少錢",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-16_2026.9.16.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 7116.52,
              "end": 7117.92,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "先生 你喜欢颜色",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-16_2026.9.16.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            }
          ],
          "talk_status": "转写内容初标，需回听核查"
        },
        {
          "recording_id": "M-49a94fdd1a30bb84",
          "recording_name": "2026.9.18.mp4",
          "date": "2026-09-18",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              1530,
              2670
            ]
          ],
          "visual_identity": "圆角三角相机岛、三圆镜头不等大，配合HUAWEI Pura系列白盒核对；同场基础款/Pro/Pro+与容量不能只看背面确定。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "抽帧定位的回查范围，可能包含转场或其他产品，不是精确剪辑边界。",
          "evidence": "2026.9.18",
          "visual_anchors_seconds": [],
          "timing_label": "00:25:30—00:44:30",
          "timing_status": "回查时间段",
          "talk_segments": [
            {
              "start": 1533.78,
              "end": 1537.98,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "这样说电池不够 内神不够用电池续航不行",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1572.82,
              "end": 1574.46,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "不心意价格不满 好不好",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1595.18,
              "end": 1599.9,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "有三种颜色 我看一下 一个是白色 你们拆哪个颜色",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1605.58,
              "end": 1607.62,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "别的都不要 要猜的",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1616.7,
              "end": 1621.62,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "猜哪个颜色 我猜一种颜色 好吧 这都是白色",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1631.38,
              "end": 1641.18,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "酒算這個iPhone,只有白色嗎,我們? 我就拆個白色給你看,這兩個顏色",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 1661.38,
              "end": 1662.98,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "不要心里有负担",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1668.98,
              "end": 1670.62,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "插着我要卖多少钱这个",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1698.18,
              "end": 1702.18,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "我没有白色的 还有一种什么颜色",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1719.94,
              "end": 1723.78,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "12.5百事兒 而且旗艦芯片902的",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1751.62,
              "end": 1754.44,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "到手自己击活 今天不能击活 击活就真的变二手机了",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1754.7,
              "end": 1755.98,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "这个我继续不能击活",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1757.26,
              "end": 1761.1,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "这个屏幕是那个6.6英寸的 6.6英寸就跟那个",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1806.12,
              "end": 1809.12,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "这多少瓦重点头上没写 66瓦的快冲头",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1826.08,
              "end": 1829.2,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "今天你不要去对比二手价格 但是你可以拿二手价格来看看",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1841.04,
              "end": 1842.8,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "不要卖七八千 三八千呢",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1887.28,
              "end": 1889.58,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "白色的還有一個金色的",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1915.58,
              "end": 1922.62,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "所以你自己挑 一个白色 一个金色 其实手机的颜色并不决定是吗",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 1971.06,
              "end": 1973.06,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "还想只想花一个二手价格",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1976.34,
              "end": 1994.06,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "两种颜色带自己调把金色的和白色 但是金色我拿着金色的给它看外观 但是它大致外观差不多 大致外观是差不多 这两个颜色不一样的而已 全新的配件都给它看了",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 2006.06,
              "end": 2019.78,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "这台机其实我就赚20块钱 赚20块一百七十台 镜吧 这台机 我们这台机算了一下就20块钱 就20块钱 没多少利人",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 2021.98,
              "end": 2025.34,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "我们什么数据线了 什么充电器",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 2038.54,
              "end": 2046.74,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "这个机器多少钱全新的 少了2000块钱对不对",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 2059.14,
              "end": 2069.3,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "不想花钱的 今天你可以先到手感受一下 我们多少钱 什么五千九百九九直接干到",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 2071.58,
              "end": 2074.46,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "这不要 再给大家破架了",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 2074.46,
              "end": 2083.9,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "三百块钱 到手这个三千六百九九 你先用下个月才负多少钱",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 2092.18,
              "end": 2095.18,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "内神CPU以及整个铁岗拍照的购物的",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 2100.78,
              "end": 2103.58,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "价格就是你全往对比看进入充电",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 2204.54,
              "end": 2207.24,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "就是屏幕不一樣 Polo屏幕不一樣",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 2265.62,
              "end": 2271.34,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "在降就是濃瓦西雷 在低就是濃瓦西雷",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 2329.98,
              "end": 2331.98,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "就是大家千萬不要說",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 2374.7,
              "end": 2375.9,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "反正什么车都不适合",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 2431.2,
              "end": 2432.4,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "它是唯一屏幕不一样",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 2515.4,
              "end": 2520.16,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "123号连接都是这种官方员风员盒的全新机",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 2561.88,
              "end": 2564.28,
              "aspect": "外观与配件",
              "title": "参数、续航与性能口述",
              "quote": "它的外观值屏幕不一样",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            }
          ],
          "talk_status": "转写内容初标，需回听核查"
        },
        {
          "recording_id": "M-77f975c5c38e5ee4",
          "recording_name": "2026.9.20.MP4",
          "date": "2026-09-20",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              870,
              1770
            ]
          ],
          "visual_identity": "圆角三角相机岛、三圆镜头不等大，配合HUAWEI Pura系列白盒核对；同场基础款/Pro/Pro+与容量不能只看背面确定。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "抽帧定位的回查范围，可能包含转场或其他产品，不是精确剪辑边界。",
          "evidence": "2026.9.20",
          "visual_anchors_seconds": [],
          "timing_label": "00:14:30—00:29:30",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-6cd07e09b524f6e0",
          "recording_name": "2026.9.22.mp4",
          "date": "2026-09-22",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              1350,
              1830
            ]
          ],
          "visual_identity": "圆角三角相机岛、三圆镜头不等大，配合HUAWEI Pura系列白盒核对；同场基础款/Pro/Pro+与容量不能只看背面确定。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "抽帧定位的回查范围，可能包含转场或其他产品，不是精确剪辑边界。",
          "evidence": "2026.9.22",
          "visual_anchors_seconds": [],
          "timing_label": "00:22:30—00:30:30",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-6b992df647c3735f",
          "recording_name": "2026.9.23.mp4",
          "date": "2026-09-23",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              2070,
              2550
            ]
          ],
          "visual_identity": "圆角三角相机岛、三圆镜头不等大，配合HUAWEI Pura系列白盒核对；同场基础款/Pro/Pro+与容量不能只看背面确定。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "抽帧定位的回查范围，可能包含转场或其他产品，不是精确剪辑边界。",
          "evidence": "2026.9.23",
          "visual_anchors_seconds": [],
          "timing_label": "00:34:30—00:42:30",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-b7e88e085124523e",
          "recording_name": "2026.9.26-2.mp4",
          "date": "2026-09-26",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              1350,
              2310
            ]
          ],
          "visual_identity": "圆角三角相机岛、三圆镜头不等大，配合HUAWEI Pura系列白盒核对；同场基础款/Pro/Pro+与容量不能只看背面确定。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "抽帧定位的回查范围，可能包含转场或其他产品，不是精确剪辑边界。",
          "evidence": "2026.9.26-2",
          "visual_anchors_seconds": [],
          "timing_label": "00:22:30—00:38:30",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-0a936d777127e3ec",
          "recording_name": "2026.10.3.mp4",
          "date": "2026-10-03",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              1350,
              2310
            ]
          ],
          "visual_identity": "圆角三角相机岛、三圆镜头不等大，配合HUAWEI Pura系列白盒核对；同场基础款/Pro/Pro+与容量不能只看背面确定。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "抽帧定位的回查范围，可能包含转场或其他产品，不是精确剪辑边界。",
          "evidence": "2026.10.3",
          "visual_anchors_seconds": [],
          "timing_label": "00:22:30—00:38:30",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-1c674f0464fcde0a",
          "recording_name": "2026.10.4.mp4",
          "date": "2026-10-04",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              3150,
              4050
            ]
          ],
          "visual_identity": "圆角三角相机岛、三圆镜头不等大，配合HUAWEI Pura系列白盒核对；同场基础款/Pro/Pro+与容量不能只看背面确定。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "抽帧定位的回查范围，可能包含转场或其他产品，不是精确剪辑边界。",
          "evidence": "2026.10.4",
          "visual_anchors_seconds": [],
          "timing_label": "00:52:30—01:07:30",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-86812a16b84ea2cb",
          "recording_name": "2026-10-08_2101_猫哥评测_7694281328392522539_20261009-035500.mp4",
          "date": "2026-10-08",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              6290.0,
              6648.0
            ]
          ],
          "visual_identity": "圆角三角相机岛、三圆镜头不等大，配合HUAWEI Pura系列白盒核对；同场基础款/Pro/Pro+与容量不能只看背面确定。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "原有分析时间段，结合抽帧复核；正式剪辑仍需逐段回看。",
          "evidence": "2026-10-08_2101_猫哥评测_7694281328392522539_20261009-035500",
          "visual_anchors_seconds": [],
          "timing_label": "01:44:50—01:50:48",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        }
      ],
      "evidence": "payload.json",
      "image_source": "商品链接原图",
      "visual_candidates": [],
      "visual_reviewed_at": "2026-10-12",
      "product_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3774003635424460910&origin_type=604",
      "link_name": "华为Pura 80Pro",
      "link_source": "原商品库只读查询，同型号按本次列表最新顺序优先",
      "link_status": "推广核实正常（2026-10-26核对）；库存另核",
      "image": "https://p26-item.ecombdimg.com/img/ecom-shop-material/jpeg_m_7d947675a12e75763e905b0df54f67dc_sx_380823_www800-800~tplv-5mmsx3fupr-resize_q:1080:1080:q90.webp",
      "link_audit": {
        "id": "PF-24538be1",
        "name": "华为Pura 80Pro",
        "old_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3774003635424460910&origin_type=604",
        "promotion_status": "推广核实正常",
        "page_status": "库存未于本轮重新核查",
        "source_rows": [
          {
            "name": "华为Pura 80Pro",
            "row_id": "111",
            "text": "\t\n华为Pura 80Pro\n未分类 · ID 3774003635424460910\n\t—\t1.00%\t\n1%\n\t正常\n10/26 07:04\n\t2026/9/15\t\n复制"
          }
        ],
        "checked_at": "2026-10-26",
        "source": "原商品工作台当日07:00—07:09只读结果"
      }
    },
    {
      "id": "PF-40f6e104",
      "name": "航嘉桌面插座（M20与未明款）",
      "category": "电脑周边与存储",
      "aliases": [
        "Huntkey航嘉 M20桌面插座",
        "Huntkey航嘉六插位、四USB口桌面插座"
      ],
      "description": "深灰低矮方形桌面插座，交流孔在顶面、多个USB口在侧面；7月29日可见航嘉M20包装。 7月29、30日机身和接口布局已复核。本轮未确认新增同款日期。",
      "cautions": [
        "不能把USB20W与交流2500W混为一谈，未核各端口单用/合用分配。",
        "包装型号字样不够清楚，不定具体型号；保护触发、安全等级和合作资质未独立核实。",
        "7月29、30日机身和接口布局已复核。本轮未确认新增同款日期。",
        "外观复核仅确认画面对应关系，不代替型号、配置或商品链接SKU核对。"
      ],
      "appearances": [
        {
          "recording_id": "M-3351cde4751e7974",
          "recording_name": "2026.7.29.mp4",
          "date": "2026-07-29",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              241.46,
              567.02
            ],
            [
              570.66,
              605.66
            ],
            [
              612.16,
              694.26
            ]
          ],
          "visual_identity": "深灰低矮方形桌面插座，交流孔在顶面、多个USB口在侧面；7月29日可见航嘉M20包装。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "原有分析时间段，结合抽帧复核；正式剪辑仍需逐段回看。",
          "evidence": "2026.7.29",
          "visual_anchors_seconds": [],
          "timing_label": "00:04:01—00:09:27、00:09:30—00:10:05、00:10:12—00:11:34",
          "timing_status": "回查时间段",
          "talk_segments": [
            {
              "start": 241.46,
              "end": 567.02,
              "title": "航嘉桌面插座品牌、六交流插位、四USB口、过载保护和29元报价。",
              "aspect": "价格与套餐",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-29_2026.7.29/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 570.66,
              "end": 605.66,
              "title": "插座不适用空调插头的答疑，口述电流数字存疑。",
              "aspect": "讲解内容",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-29_2026.7.29/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 612.16,
              "end": 694.26,
              "title": "插座安全门、使用场景和功率问题，转向平板。",
              "aspect": "参数与性能说明",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-29_2026.7.29/segments.json",
              "clock": "已有审校回查时间"
            }
          ],
          "talk_status": "已有审校内容分段"
        },
        {
          "recording_id": "M-4c1779a30fd9f580",
          "recording_name": "2026.7.30.mp4",
          "date": "2026-07-30",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              424.02,
              858.06
            ]
          ],
          "visual_identity": "深灰低矮方形桌面插座，交流孔在顶面、多个USB口在侧面；7月29日可见航嘉M20包装。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "原有分析时间段，结合抽帧复核；正式剪辑仍需逐段回看。",
          "evidence": "2026.7.30",
          "visual_anchors_seconds": [],
          "timing_label": "00:07:04—00:14:18",
          "timing_status": "回查时间段",
          "talk_segments": [
            {
              "start": 424.02,
              "end": 858.06,
              "title": "航嘉多口插座：品牌口述、插孔、USB接口、功率、开关和售后，最终报价29元。",
              "aspect": "价格与套餐",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-30_2026.7.30/segments.json",
              "clock": "已有审校回查时间"
            }
          ],
          "talk_status": "已有审校内容分段"
        }
      ],
      "evidence": "payload.json",
      "image_source": "商品链接原图",
      "visual_candidates": [],
      "visual_reviewed_at": "2026-10-12",
      "product_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3788804571355283939&origin_type=604&channel_id=3623712513881090&channel_type=4",
      "link_name": "航嘉 快充插座",
      "link_source": "原商品库只读查询；按添加日期/列表顺序选取本款最新可打开链接",
      "link_status": "核实失败，待确认（2026-10-26核对）；库存另核",
      "binding_scope": "仅按以下已核对实物画面使用；其他日期、容量、颜色及具体配置不能自动套用：2026.7.29.mp4，源360.000秒及既有M20包装缩略图",
      "appearance_match": "包装M20、黑色方形机身、顶部插座布局、前侧USB区和20W侧字与商品图对应；该链接含M20/30/45，须选M20，不扩大到未明款",
      "appearance_checked_at": "2026-10-12T09:30:04.695093+08:00",
      "image": "https://p26-item.ecombdimg.com/img/ecom-shop-material/jpeg_m_0330d8273daf67bd756154876d4da361_sx_293089_www800-800~tplv-5mmsx3fupr-resize_q:1080:1080:q90.webp",
      "link_audit": {
        "id": "PF-40f6e104",
        "name": "航嘉 快充插座",
        "old_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3788804571355283939&origin_type=604&channel_id=3623712513881090&channel_type=4",
        "promotion_status": "核实失败，待确认",
        "page_status": "库存未于本轮重新核查",
        "source_rows": [
          {
            "name": "航嘉 快充插座",
            "row_id": "13",
            "text": "\t\n航嘉 快充插座\n未分类 · ID 3788804571355283939\n航嘉&猫哥评测\n\t29.9\t20.00%\t\n20%\n上次成功 10/18 16:31\n\t核实失败\n10/26 07:09\n\t2026/9/15\t\n复制"
          }
        ],
        "checked_at": "2026-10-26",
        "source": "原商品工作台当日07:00—07:09只读结果"
      }
    },
    {
      "id": "PF-4649776d",
      "name": "AMOI 夏新往复式剃须刀（RAZOR 礼盒，型号待核）",
      "category": "个护与家用",
      "aliases": [
        "夏新剃须刀",
        "AMOI往复式剃须刀",
        "夏新黑银剃须刀",
        "两支细长往复式剃须刀（各款品牌型号待核）",
        "黑灰色往复式电动剃须刀（品牌型号待核）",
        "银灰色往复式电动剃须刀（品牌型号待核）"
      ],
      "description": "按外观关联7场：9月23日、24日第二段、26日、27日、10月1日、12日及19日。黑银细长机身、横向刀网、菱纹背部和内托对应；10月19日按外观补充，品牌与具体型号未读清，不认定各色同SKU。",
      "cautions": [
        "RAZOR 为礼盒可见字样，不据此推定具体 SKU。 剃净效果、材质和报价未经独立测试。 10月1日盒上AMOI/夏新可读，实物为黑银两支细长往复式刀；盒标不证明两支为相同SKU，RAZOR字样来自旧场，本场精确型号仍待核。 10月1日全金属/CNC、防水、续航一个月、多年刀头与79报价为口述未核；所看原帧没有实际剃须效果或浸水测试，不套玛莎拉蒂/宾利品牌。 10月1日本项实物出现已核实；原音疑点与精确音画时码继续审核，属于产品级部分上线，不计整场交付。",
        "2026-10-12仅确认外观相同产品组，未确认精确型号或各颜色为同一SKU；历史材质、防水、续航和报价不能跨场套用。",
        "回查时间来自30秒抽帧，剪辑前需逐帧和原声确认边界。",
        "不能仅凭同场展示认定两支为同型号或同一 SKU。",
        "品牌、材质、防水、续航和当场价格均未独立核实；不自动合并其他日期剃须刀。",
        "品牌、型号、材质、磁吸设计、续航与防水未独立核实。",
        "与9月27日银灰色剃须刀是否同款待包装或商品码确认。",
        "品牌、型号、刀头材质、防水与续航未独立核实。",
        "与9月26日剃须刀是否同款待包装或商品码确认。",
        "10月12日01:14:50为画面锚点，不是完整窗口或精确剪辑点；同盒两支不认定同SKU。",
        "10月19日为外观关联，品牌型号未读清；水缸画面不证明水下开机、防水等级或剃须效果。"
      ],
      "appearances": [
        {
          "recording_id": "M-6b992df647c3735f",
          "basis": "2026-10-12 原素材外观复核 · 回查窗口",
          "windows": [
            [
              4170,
              4590
            ]
          ],
          "visual_anchors_seconds": [
            4230
          ],
          "timing_label": "01:09:30—01:16:30",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-6c9e1bd9ccb966f3",
          "basis": "2026-10-12 原素材外观复核 · 回查窗口",
          "windows": [
            [
              570,
              870
            ]
          ],
          "visual_anchors_seconds": [
            690
          ],
          "timing_label": "00:09:30—00:14:30",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-9a41db0033816128",
          "basis": "2026-10-12 原素材外观复核 · 回查窗口",
          "windows": [
            [
              750,
              1080
            ]
          ],
          "visual_anchors_seconds": [
            900
          ],
          "timing_label": "00:12:30—00:18:00",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-8f069728a48d9a84",
          "basis": "2026-10-12 原素材外观复核 · 回查窗口",
          "windows": [
            [
              660,
              990
            ]
          ],
          "visual_anchors_seconds": [
            810
          ],
          "timing_label": "00:11:00—00:16:30",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-c9d1cc58905bf21e",
          "basis": "2026-10-12 原素材外观复核 · 回查窗口",
          "windows": [
            [
              4530,
              4855.55
            ]
          ],
          "visual_anchors_seconds": [
            4650
          ],
          "timing_label": "01:15:30—01:20:55",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-97b67ce09dcd888d",
          "basis": "2026-10-19 复核已有审校与身份帧",
          "windows": [],
          "visual_identity": "原片01:14:50黑银细长机身、横向刀网及菱纹背部，桌面AMOI礼盒；仅确认外观组，不承诺各色同SKU。",
          "visual_anchors_seconds": [
            4490
          ],
          "timing_label": "01:14:50（完整起止待核）",
          "timing_status": "已确认画面时刻",
          "talk_segments": [
            {
              "start": 4467.6,
              "end": 4468.6,
              "title": "全金属的",
              "aspect": "外观与配件",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-12/2026-10-12-original-1c87259afc02/Codex-product-presence-review-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 4474.6,
              "end": 4475.6,
              "title": "全身全金属的",
              "aspect": "外观与配件",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-12/2026-10-12-original-1c87259afc02/Codex-product-presence-review-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 4499.6,
              "end": 4501.6,
              "title": "上面刀头也是全金属的",
              "aspect": "外观与配件",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-12/2026-10-12-original-1c87259afc02/Codex-product-presence-review-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 4501.6,
              "end": 4502.6,
              "title": "网上一放磁吸的",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-12/2026-10-12-original-1c87259afc02/Codex-product-presence-review-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 4502.6,
              "end": 4503.6,
              "title": "有两种颜色",
              "aspect": "外观与配件",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-12/2026-10-12-original-1c87259afc02/Codex-product-presence-review-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            }
          ],
          "talk_status": "已有审校内容分段"
        },
        {
          "recording_id": "M-7ac841d36a3f1e99",
          "windows": [
            [
              3139,
              3455
            ]
          ],
          "visual_anchors_seconds": [
            3200,
            3300
          ],
          "basis": "2026-10-23直接读取原录像：53:20深灰T形双网刀头及银色菱纹长柄同场，55:00水缸画面。按用户要求以外观关联；品牌与精确型号待核。",
          "visual_identity": "深灰/银色细长机身、T形横向往复式刀网、菱纹背部及黑色内托与已有组对应。仅外观关联，不确认同SKU。",
          "timing_label": "00:52:19—00:57:35（外观对应，品牌型号待核）",
          "timing_status": "回查时间段",
          "talk_status": "讲解分段待核查",
          "talk_segments": []
        }
      ],
      "evidence": "payload.json",
      "image_source": "商品链接原图",
      "visual_reviewed_at": "2026-10-12",
      "visual_candidates": [],
      "product_url": "https://alliance.jinritemai.com/merchants/alliance-general-share?promotion_id=3840414661644255707",
      "link_name": "夏新剃须刀",
      "link_source": "原商品库只读查询；按添加日期/列表顺序选取本款最新可打开链接",
      "link_status": "推广核实正常（2026-10-26核对）；库存另核",
      "binding_scope": "仅按以下已核对实物画面使用；其他日期、容量、颜色及具体配置不能自动套用：2026.9.23.mp4，源4170.000、4190.000、4210.000、4230.000秒",
      "appearance_match": "AMOI夏新包装、黑银色细长机身、弧形颈部和长条网刀头对应商品图；未读取准确型号铭牌，仅绑定已核对的9月23日外观，不自动认可所有日期两支为同SKU",
      "appearance_checked_at": "2026-10-12T09:30:04.695093+08:00",
      "image": "https://p3-aio.ecombdimg.com/obj/ecom-shop-material/jpeg_m_0ee3c3bc5b2f81d0bbdd7d367015b51e_sx_438500_www800-800",
      "merged_product_ids": [
        "PF-017ae10c",
        "PF-99ab41d0",
        "PF-973bf62f"
      ],
      "merge_notes": "2026-10-12已核对9.24第二段、9.26及9.27的机身与刀网外观，归到夏新同外观产品组；保留黑银颜色与型号待核。来源信息保留可回溯。",
      "verification": {
        "status": "7场外观关联；10月19日型号待核",
        "checked_at": "2026-10-23",
        "identity": "用户要求按外观查找并添加；直接核对7场原片抽帧，保留品牌与型号证据边界。",
        "basis": "本地证据目录：/Users/szx/Movies/gpt/夏新原录像查找_20261023",
        "name": "AMOI 夏新往复式剃须刀（RAZOR 礼盒，型号待核）"
      },
      "link_audit": {
        "id": "PF-4649776d",
        "name": "夏新剃须刀",
        "old_url": "https://alliance.jinritemai.com/merchants/alliance-general-share?promotion_id=3840414661644255707",
        "promotion_status": "推广核实正常",
        "page_status": "库存未于本轮重新核查",
        "source_rows": [
          {
            "name": "夏新剃须刀",
            "row_id": "195",
            "text": "\t\n夏新剃须刀\n剃须刀\n\t79\t50%\t\n50%\n\t正常\n10/26 07:00\n\t2026/9/29\t\n复制"
          }
        ],
        "checked_at": "2026-10-26",
        "source": "原商品工作台当日07:00—07:09只读结果"
      }
    },
    {
      "id": "PF-5ac5fd9a",
      "name": "玛莎拉蒂标识智能手表",
      "category": "手表",
      "aliases": [
        "包装标Maserati的智能手表"
      ],
      "description": "黑色圆形智能表体、蓝/红硅胶表带、深蓝三叉戟/Maserati标识礼盒及菜单演示；机械指针款另分。 补充9月9日深蓝Maserati标识礼盒及同组圆屏智能表。黑银表壳与蓝红带分别选取。",
      "cautions": [
        "Maserati字样和三叉标不等于官方授权；红外未取得空调状态变化闭环，健康数值不作诊断。",
        "10月8日盒标MOZI莫兹/Maserati及B-1可读，仅确认标识；不认定官方授权或与历史场次同一SKU。动态与静态表盘续航条件不同，NFC不能公交地铁的限制须保留；材料、屏幕、防水和续航未独立测试，99等口述不承诺现价。 本项仅产品级部分审核，不计本场整场交付。",
        "补充9月9日深蓝Maserati标识礼盒及同组圆屏智能表。黑银表壳与蓝红带分别选取。",
        "外观复核仅确认画面对应关系，不代替型号、配置或商品链接SKU核对。"
      ],
      "appearances": [
        {
          "recording_id": "M-52fe0205044514fa",
          "recording_name": "2026.9.9.mp4",
          "date": "2026-09-09",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              0,
              2250
            ]
          ],
          "visual_identity": "黑色圆形智能表体、蓝/红硅胶表带、深蓝三叉戟/Maserati标识礼盒及菜单演示；机械指针款另分。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "抽帧定位的回查范围，可能包含转场或其他产品，不是精确剪辑边界。",
          "evidence": "2026.9.9",
          "visual_anchors_seconds": [],
          "timing_label": "00:00:00—00:37:30",
          "timing_status": "回查时间段",
          "talk_segments": [
            {
              "start": 26.72,
              "end": 28.56,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "要质量手表的在这不见不要走开",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 109.36,
              "end": 114.56,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "显示器今天没有 显示器今天真没有",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 190.48,
              "end": 191.84,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "把那个统一盒子拉给我了",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 193.44,
              "end": 194.48,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "要统一盒不要错过",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 237.8,
              "end": 238.6,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "这不点不要错过",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 239.6,
              "end": 241.0,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "报个价格就行啊",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 378.8,
              "end": 380.6,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "线长1米6 这个线长够长吧",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 388.8,
              "end": 393.2,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "也卖老外卖70块钱一根 这减减40块钱",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 400.6,
              "end": 409.4,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "然后线长1米6就不用说了 金属的 全金属的",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 420.0,
              "end": 425.0,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "全部可以充电 全部可以充电 不仅充电 而且是240瓦超级快充",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 432.6,
              "end": 433.8,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "它上面还有一个显示器",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 434.8,
              "end": 435.8,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "这个线之前卖40块钱",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 441.0,
              "end": 443.0,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "这里上面会显示充电功率",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 445.2,
              "end": 456.4,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "绝对可以达到37瓦以上 37瓦以上 40瓦 40瓦都达到了 Promance标准的充电功率 就是很多人买的假充电器",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 457.6,
              "end": 460.0,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "可以显示充电功率一眼就看出来了",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 462.8,
              "end": 464.6,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "简测你的充电头是真是假",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 466.6,
              "end": 468.2,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "这个显示器成本十几块钱",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 484.2,
              "end": 486.4,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "来 直不见都不要走开这个",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 513.8,
              "end": 521.2,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "在这充电 看没有 交流电充电信息 我都是100瓦",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 552.2,
              "end": 553.2,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "上面还带个显示",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 554.2,
              "end": 556.0,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "这个卖老外79块",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 557.12,
              "end": 559.2,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "国内39跟屏幕原则像非常激进",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 598.0,
              "end": 599.6,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "是你的那个充电器决定的",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 602.6,
              "end": 607.0,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "而且整个线的材质 金属的",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 607.8,
              "end": 609.6,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "一个数码显示 器这个显示器",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 612.6,
              "end": 615.8,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "觉得应该花40块以上 应该是40块以上",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 616.6,
              "end": 624.8,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "自动断电 那个自动断电 一样连接",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 636.6,
              "end": 638.6,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "就不停都不要走开 都不要走开",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 669.2,
              "end": 675.8,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "我说花了40元 你们赶紧理个发多少钱",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 689.8,
              "end": 691.8,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "假合就是13块酒 没有卖到15块吧",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 724.8,
              "end": 726.8,
              "aspect": "外观与配件",
              "title": "功能介绍与操作演示",
              "quote": "金属的还在数码显示馆",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 741.8,
              "end": 743.8,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "但是他功能价格合适",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 777.8,
              "end": 780.8,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "45瓦的超级弹画家的头",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 789.8,
              "end": 790.8,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "是最便宜的价格了",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 794.8,
              "end": 800.8,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "给你充电配来 直接可以充电",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 801.8,
              "end": 807.8,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "上面直接显示 这边可以显示",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 813.8,
              "end": 814.8,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "这是充电的功率",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 836.8,
              "end": 838.8,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "就是这个充电头轮死边",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 838.8,
              "end": 839.8,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "你是用了什么显示",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 848.8,
              "end": 849.8,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "专注常区行电池",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 853.8,
              "end": 858.8,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "直接显示充电功率 直接显示手机的电池电量 直接显示iPhone17Pormise",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 876.8,
              "end": 880.8,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "视频卖90块钱一个 再少个30块钱",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 884.8,
              "end": 885.8,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "新国不要3C的",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 886.8,
              "end": 887.8,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "新充电器肯定有3C",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 894.8,
              "end": 896.8,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "带显示器的 带显示器的",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 953.8,
              "end": 954.8,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "200块钱一个",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 954.8,
              "end": 955.8,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "苹果官方的40瓦",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 955.8,
              "end": 956.8,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "也卖了200块钱吧",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 959.8,
              "end": 962.8,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "显示有动画的 显示动画 显示功率的这个",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 967.8,
              "end": 968.8,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "这个正常是卖90块钱",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 994.8,
              "end": 995.8,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "然后手机的电池",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1004.8,
              "end": 1029.8,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "一共充了多少瓦进去 低温充电就是保护充电 自动降低充电功率 原装芯片一样 就是自动调节充电功率 然后它自动就把充电的功率 第1个保护这充电器 第2个保护你电池",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 1029.8,
              "end": 1033.8,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "所以这个卖个90块钱差不多吧 90块钱 89块钱",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1043.8,
              "end": 1045.8,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "只是不显示 只是不显示",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1049.8,
              "end": 1050.8,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "这个充电头绝对可以买它",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1068.8,
              "end": 1069.8,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "你们报个价格就行了",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1113.8,
              "end": 1115.8,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "伟货你就不用管价格了",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1125.8,
              "end": 1135.8,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "这个价格 屏幕的价格都不要",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 1139.8,
              "end": 1144.8,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "MOLAND的屏幕 是我们分明率屏幕",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1149.8,
              "end": 1150.8,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "就是兄弟们猜的价格",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1265.0,
              "end": 1267.0,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "不要吃拼好飯就可以了",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1276.0,
              "end": 1281.0,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "不要穿名牌嗎 吃的是你咱們注意的",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1306.0,
              "end": 1308.0,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "不要錢 不要錢",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1333.0,
              "end": 1335.0,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "MOLAN的超高金屏幕",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1402.0,
              "end": 1420.0,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "比這個屏幕賣得便宜 所以一點它跟華為一樣的屏幕 超高金的屏幕 陳以466的這個屏幕",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 1446.0,
              "end": 1447.0,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "MOLAN的屏幕",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1512.0,
              "end": 1514.0,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "不要完美隨一切話",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1545.0,
              "end": 1554.0,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "讓我防水功能 這個可以帶著游泳的 可以帶著游泳是沒關係",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 1588.0,
              "end": 1589.0,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "這個我忘記怎麼操作了",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1603.0,
              "end": 1604.0,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "去年在直播間有演示",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1641.0,
              "end": 1653.0,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "這個質感就是這塊屏幕 比這個屏幕還便宜 華為GT系列屏幕是一樣的",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 1662.0,
              "end": 1664.0,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "到手一套那個藍色表彈",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1707.0,
              "end": 1708.0,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "MO LAN的屏幕",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1718.0,
              "end": 1719.0,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "很多順便盒子包裝都不一樣",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1727.0,
              "end": 1729.0,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "屏幕跟華為也是同級別的",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1779.0,
              "end": 1783.0,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "MOLAN的屏幕 能買到MOLAN屏幕",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1876.0,
              "end": 1879.0,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "也不要 這還不要",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1929.0,
              "end": 1932.0,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "屏幕就看屏幕 就看屏幕就可以了",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1961.0,
              "end": 1963.0,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "然後就看屏幕 就看屏幕",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 2030.0,
              "end": 2031.0,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "你就看屏幕別的功能",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 2060.0,
              "end": 2061.0,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "就快就買個屏幕手機",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 2110.0,
              "end": 2116.0,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "你就穿著這塊屏幕就可以了 你就穿著這塊屏幕看起來就可以了",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 2193.0,
              "end": 2196.0,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "就知道這塊屏幕 MOLAN的屏幕",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-09_2026.9.9.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            }
          ],
          "talk_status": "转写内容初标，需回听核查"
        },
        {
          "recording_id": "M-45a20a0b2807826b",
          "recording_name": "2026.9.10.mp4",
          "date": "2026-09-10",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              1020,
              1650
            ]
          ],
          "visual_identity": "黑色圆形智能表体、蓝/红硅胶表带、深蓝三叉戟/Maserati标识礼盒及菜单演示；机械指针款另分。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "抽帧定位的回查范围，可能包含转场或其他产品，不是精确剪辑边界。",
          "evidence": "2026.9.10",
          "visual_anchors_seconds": [],
          "timing_label": "00:17:00—00:27:30",
          "timing_status": "回查时间段",
          "talk_segments": [
            {
              "start": 1107.76,
              "end": 1113.76,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "给你看一块卖多少钱 把这个价格导致公平上",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-10_2026.9.10.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 1125.76,
              "end": 1127.76,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "这盒子不加一二十块钱这个",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-10_2026.9.10.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1172.76,
              "end": 1174.76,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "这是Molland的屏幕 Molland的屏幕",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-10_2026.9.10.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1183.76,
              "end": 1185.76,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "手表的屏幕分析中分",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-10_2026.9.10.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1189.76,
              "end": 1197.76,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "但是今年300块钱以下的表 之前大家买100块以内的手表是TFT的 今年300块钱以内的都是TFT的",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-10_2026.9.10.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 1200.84,
              "end": 1210.24,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "最好的手表的屏幕是那個 蘋果系列就是歐蘭的屏幕 歐蘭屏幕的",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-10_2026.9.10.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 1259.04,
              "end": 1261.6,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "磁吸的 磁吸無線充電的",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-10_2026.9.10.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1297.64,
              "end": 1298.92,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "第一個很多人問能不能打電話",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-10_2026.9.10.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1388.84,
              "end": 1390.52,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "手錶是MOLAN的屏幕",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-10_2026.9.10.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1533.68,
              "end": 1538.28,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "MOLAND的屏幕 這個屏幕的成本 屏幕成本",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-10_2026.9.10.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1556.16,
              "end": 1559.0,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "然後防水功能給大家看一下 能不能單是游泳",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-10_2026.9.10.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1587.4,
              "end": 1589.4,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "MOLAND的屏幕",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-10_2026.9.10.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1631.4,
              "end": 1632.4,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "現在這個屏幕其實",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-09_2026-09-11/transcripts/2026-09-10_2026.9.10.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            }
          ],
          "talk_status": "转写内容初标，需回听核查"
        },
        {
          "recording_id": "M-2d78fe26965cda89",
          "recording_name": "2026.9.17.mp4",
          "date": "2026-09-17",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              870,
              1950
            ]
          ],
          "visual_identity": "黑色圆形智能表体、蓝/红硅胶表带、深蓝三叉戟/Maserati标识礼盒及菜单演示；机械指针款另分。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "抽帧定位的回查范围，可能包含转场或其他产品，不是精确剪辑边界。",
          "evidence": "2026.9.17",
          "visual_anchors_seconds": [],
          "timing_label": "00:14:30—00:32:30",
          "timing_status": "回查时间段",
          "talk_segments": [
            {
              "start": 888.48,
              "end": 895.98,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "這個手錶的屏幕跟華為的 1000多塊錢的GT的屏幕一樣 MOLAN的超高清屏幕看一下",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 1009.1,
              "end": 1020.1,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "不是那种偶烂的屏幕 最高端的屏幕 偶烂的屏幕 用了一样的屏幕",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 1035.14,
              "end": 1037.34,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "整个手表 这个屏幕旁边没有大海边",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1093.5,
              "end": 1096.5,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "就現在這塊屏幕 這塊摩爛的屏幕",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1109.5,
              "end": 1112.78,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "上面有 电话功能 蓝牙电话功能都有吧",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1157.7,
              "end": 1158.7,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "那5条手机充电",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1197.5,
              "end": 1199.5,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "一个万了和外游泳记都不讲",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1215.96,
              "end": 1218.12,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "不停是華爾手機屏幕手裡都有",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1227.52,
              "end": 1231.92,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "这跟华为同级别屏幕 同级别适往模集分明率",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1238.72,
              "end": 1241.92,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "基本上要的全部都有这个随便出个价格就行了",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1241.92,
              "end": 1243.52,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "来 让防水功能对不对",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1243.52,
              "end": 1246.72,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "然后无线充电也有人划一样的 看那边",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1251.12,
              "end": 1253.12,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "不要猜错了 不要想着",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1276.12,
              "end": 1278.12,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "去年我们最贵的时候卖多少钱",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1287.32,
              "end": 1298.88,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "他只有两套表带一套红色 所以女孩子只有这一个颜色 去年我卖的时候还有另外一个颜色对不对 一个红色一个红色表带一个蓝色表带 现在就只有一个颜色了",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 1341.66,
              "end": 1346.06,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "300块钱以下是买不到TFT的 300块钱以下你是买不到这",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1349.06,
              "end": 1364.86,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "就是今年一个手表的一个芯片 干到都不收屏幕 这个屏幕成为一把二一个芯片 Molan的屏幕跟华为通级别的屏幕",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 1365.86,
              "end": 1367.66,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "就这一点能不能打动你",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1369.06,
              "end": 1372.7,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "然后整个的旁边的模具外观非常非常漂亮",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1377.46,
              "end": 1380.34,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "只有Moran的比如你手机是Moran屏幕对不对",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1403.06,
              "end": 1405.06,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "AMO LAN的屏幕就是懂手标的人",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1415.06,
              "end": 1418.06,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "而且这个彩盒包装 就这盒子好估计",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1418.06,
              "end": 1426.06,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "一个盒子最起码15块钱 这个彩盒最起码15块钱 然后品牌今天就不要说这个品牌多少钱了",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 1459.74,
              "end": 1461.06,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "MOLAN的屏幕",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1499.98,
              "end": 1502.18,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "MOLAN的屏幕 華為通濟別屏幕",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1511.18,
              "end": 1512.78,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "來的不要急 關注家裡面",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1529.58,
              "end": 1531.26,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "到手可以隨便是什麼手機",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1586.1,
              "end": 1588.66,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "自感看一下 什麼叫摩爛屏幕旁邊沒有黑邊",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1675.44,
              "end": 1677.08,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "很多人就会看一下这个屏幕",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1751.92,
              "end": 1756.72,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "但是你就看见这个包装整个的质量",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1756.72,
              "end": 1758.92,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "包装这个包装盒是最低15块钱",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1772.52,
              "end": 1778.56,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "来 拍照 拍照 街途 街途来 拍照街途 街途",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 1789.1,
              "end": 1792.38,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "今年正常在生产的手表300块钱以下的",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1792.38,
              "end": 1794.02,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "都是采用的那个TNT的屏幕",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1800.06,
              "end": 1801.5,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "大家不要相互自己搞自己就可以了",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1837.64,
              "end": 1838.64,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "防水性能对不对",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1850.04,
              "end": 1851.44,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "不要一直放到水里泡着",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1855.24,
              "end": 1878.24,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "但是不要带着它钱水 搜表的防水性能 你说 搜表的防水 它是那个3名叫 比如说一会冷 一会热得那搜表的防水就坏了",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 1898.88,
              "end": 1901.96,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "屏幕手机可以用可以用可以用",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1902.22,
              "end": 1905.54,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "这个不能插卡不能上下它是蓝牙版的蓝牙版的OK",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1907.58,
              "end": 1910.66,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "这是伟货伟货大家以后不要想让表一直这个价格",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1915.26,
              "end": 1919.86,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "10个不要卡,那加上了,我就不讲了",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-17_2026.9.17.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            }
          ],
          "talk_status": "转写内容初标，需回听核查"
        },
        {
          "recording_id": "M-86812a16b84ea2cb",
          "recording_name": "2026-10-08_2101_猫哥评测_7694281328392522539_20261009-035500.mp4",
          "date": "2026-10-08",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              234.0,
              881.5
            ]
          ],
          "visual_identity": "黑色圆形智能表体、蓝/红硅胶表带、深蓝三叉戟/Maserati标识礼盒及菜单演示；机械指针款另分。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "原有分析时间段，结合抽帧复核；正式剪辑仍需逐段回看。",
          "evidence": "2026-10-08_2101_猫哥评测_7694281328392522539_20261009-035500",
          "visual_anchors_seconds": [],
          "timing_label": "00:03:54—00:14:41",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        }
      ],
      "evidence": "payload.json",
      "image_source": "商品链接原图",
      "visual_candidates": [],
      "visual_reviewed_at": "2026-10-12",
      "product_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3847272764289451205&origin_type=604",
      "link_name": "玛莎拉蒂手表",
      "link_source": "原商品库只读查询；按添加日期/列表顺序选取本款最新可打开链接",
      "link_status": "推广链接失效（2026-10-26核对）；库存另核；暂无有效同款替换",
      "binding_scope": "仅按以下已核对实物画面使用；其他日期、容量、颜色及具体配置不能自动套用：10月8日直播原文件，源479.975秒与519.980秒；仅这两帧确认外观",
      "appearance_match": "四处表圈圆形螺丝、三叉戟标识、异形表圈及蓝色表带对应；商品页品牌为魔姿、型号B1玛莎，未作为玛莎拉蒂制造或授权证明",
      "appearance_checked_at": "2026-10-12T09:30:04.695093+08:00",
      "image": "https://p3-item.ecombdimg.com/img/ecom-shop-material/jpeg_m_f1f56963eb81dcf8db35432a004c4bd1_sx_952544_www1600-1600~tplv-5mmsx3fupr-resize_q:1080:1080:q90.webp",
      "link_audit": {
        "id": "PF-5ac5fd9a",
        "name": "玛莎拉蒂手表",
        "old_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3847272764289451205&origin_type=604",
        "promotion_status": "推广链接失效",
        "page_status": "库存未于本轮重新核查",
        "source_rows": [
          {
            "name": "玛莎拉蒂手表",
            "row_id": "197",
            "text": "\t\n玛莎拉蒂手表\n未分类 · ID 3847272764289451205\n\t99\t30%\t\n—\n\t链接失效\n10/26 07:00\n\t2026/10/9\t\n复制"
          }
        ],
        "checked_at": "2026-10-26",
        "source": "原商品工作台当日07:00—07:09只读结果"
      }
    },
    {
      "id": "PF-5af28f8d",
      "name": "DOSS 黑白充电仓耳机（型号待核）",
      "category": "耳机",
      "aliases": [
        "DOSS黑白仓夹耳耳机"
      ],
      "description": "黑/米白椭圆翻盖充电仓与鼓形夹耳组件，DOSS标识场次互相对照；不能与7月的镜面小仓耳机混用。 补充9月22日同组黑白仓/夹耳结构；9月23日窗口收窄到耳机展示段。7月14/26日镜面小仓款、9月7另一段的蓝色耳挂图示款不认定为本款。 10月13日补充10月10日及11日米白DOSS夹耳耳机，原视频锚点720秒、5940秒；参考范围非精确剪辑边界。",
      "cautions": [
        "三场画面仅按同外观产品组整理，不能据此确认同一型号、同一批货或同一 SKU。",
        "9月26日主播关于材质、续航、翻译、降噪与佩戴的描述未独立测试。",
        "现有分析用于选品；具体型号与精确剪辑时码尚未验收。",
        "10月7日品牌由包装及仓面DOSS标识确认，口播中BOSS/DOS为转写误听；不同日期不能据此认定同一批货或SKU。99元及月付8等为口述，材质、翻译、降噪、续航、佩戴与厂商合作说法未独立核实。",
        "补充9月22日同组黑白仓/夹耳结构；9月23日窗口收窄到耳机展示段。7月14/26日镜面小仓款、9月7另一段的蓝色耳挂图示款不认定为本款。",
        "外观复核仅确认画面对应关系，不代替型号、配置或商品链接SKU核对。",
        "来源为已有分析或切片方案，型号及剪辑边界请核对原素材。"
      ],
      "appearances": [
        {
          "recording_id": "M-6cd07e09b524f6e0",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              270,
              1470
            ]
          ],
          "visual_anchors_seconds": [],
          "timing_label": "00:04:30—00:24:30",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-6b992df647c3735f",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              630,
              1410
            ]
          ],
          "visual_anchors_seconds": [],
          "timing_label": "00:10:30—00:23:30",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-2ce4ffbb95b618c1",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              150,
              1290
            ]
          ],
          "visual_anchors_seconds": [],
          "timing_label": "00:02:30—00:21:30",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-b7e88e085124523e",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              0,
              1410
            ]
          ],
          "visual_anchors_seconds": [],
          "timing_label": "00:00:00—00:23:30",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-aa5b92644f8170bb",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对；已有分析 / 切片方案",
          "windows": [
            [
              3630,
              4290
            ]
          ],
          "visual_anchors_seconds": [],
          "timing_label": "01:00:30—01:11:30",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-9b1e50632c1bdde9",
          "basis": "2026-10-13 商品页与原录像既有抽帧逐图外观核对",
          "windows": [
            [
              407.1,
              1654.4
            ]
          ],
          "visual_anchors_seconds": [],
          "timing_label": "00:06:47—00:27:34",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-2719dd72f6f430af",
          "basis": "2026-10-13 商品页与原录像既有抽帧逐图外观核对",
          "windows": [
            [
              5706.5,
              6267.2
            ]
          ],
          "visual_anchors_seconds": [],
          "timing_label": "01:35:06—01:44:27",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        }
      ],
      "evidence": "payload.json",
      "image_source": "商品链接原图",
      "visual_candidates": [],
      "visual_reviewed_at": "2026-10-13T11:40:00.858362+08:00",
      "product_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3846903661326369199&origin_type=604",
      "link_name": "DOSS德士夹耳式蓝牙耳机D60翻译转写智能触控定向传音长效续航SP",
      "link_source": "原商品库只读查询；按添加日期/列表顺序选取本款最新可打开链接",
      "link_status": "推广核实正常（2026-10-26核对）；库存另核",
      "binding_scope": "保留原已核实9月23日895秒、10月7日3799.970秒；新增10月10日720秒、10月11日5940秒米白DOSS实物。其他颜色配置逐款核对。",
      "appearance_match": "DOSS仓面标识、弧形上盖、白金色U形耳夹和舱内布局对应D60商品图；外观匹配不证明不同日期同批货或所有技术参数",
      "appearance_checked_at": "2026-10-13T11:40:00.858362+08:00",
      "image": "https://p26-item.ecombdimg.com/img/ecom-shop-material/jpeg_m_5c43139a38a42a0cbd339a5af0b040e7_sx_192761_www1080-1080~tplv-5mmsx3fupr-resize_q:1080:1080:q90.webp",
      "merged_product_ids": [
        "A-2f8dbb7f69102f60"
      ],
      "merge_notes": "同一场DOSS黑白仓夹耳耳机记录，已绑定商品链接一致",
      "link_audit": {
        "id": "PF-5af28f8d",
        "name": "DOSS德士夹耳式蓝牙耳机D60翻译转写智能触控定向传音长效续航SP",
        "old_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3846903661326369199&origin_type=604",
        "promotion_status": "推广核实正常",
        "page_status": "库存未于本轮重新核查",
        "source_rows": [
          {
            "name": "DOSS德士耳机",
            "row_id": "196",
            "text": "\t\nDOSS德士耳机\n未分类 · ID 3846903661326369199\n\t99\t40%\t\n40%\n\t正常\n10/26 07:00\n\t2026/10/8\t\n复制"
          }
        ],
        "checked_at": "2026-10-26",
        "source": "原商品工作台当日07:00—07:09只读结果"
      }
    },
    {
      "id": "PF-630d3f91",
      "name": "往复式剃须刀（其他／型号未明）",
      "category": "个护与家用",
      "aliases": [
        "三刀头往复式剃须刀（品牌型号待核）",
        "往复式三刀头剃须刀（口播“小锤子3.0”，品牌待核）",
        "往复式电动剃须刀",
        "往复式电动剃须刀（品牌型号待核）"
      ],
      "description": "亮银色长柄、横向多刀网刀头、黑色礼盒，部分场次可见T9标识；与夏新细柄菱纹款及MS19粗柄款区分。 补充9月13、20、21日三刀网亮银长柄素材。9月10日旧关联本轮未获得足够外观证据，保留待核，禁止直接选用。",
      "cautions": [
        "品牌未明确，松下/索尼/博朗是比较或ASR混淆；不能据此命名本品。",
        "防水、续航一个月、耐用多年及“不会刮出血”均未独立验证。",
        "9月18及16所选帧未形成入水演示，9月14只有水箱附近滴水场景；不据此许诺防水等级。",
        "补充9月13、20、21日三刀网亮银长柄素材。9月10日旧关联本轮未获得足够外观证据，保留待核，禁止直接选用。",
        "外观复核仅确认画面对应关系，不代替型号、配置或商品链接SKU核对。",
        "9月12与9月13在15:30、33:30、63:30、96:30四处抽帧完全一致，疑似重复片源；9月13仅作为另一文件入口，不算新的拍摄场次。"
      ],
      "appearances": [
        {
          "recording_id": "M-2fbdb0937c9f1718",
          "recording_name": "2026.09.07.mp4",
          "date": "2026-09-07",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              630,
              1350
            ]
          ],
          "visual_identity": "亮银色长柄、横向多刀网刀头、黑色礼盒，部分场次可见T9标识；与夏新细柄菱纹款及MS19粗柄款区分。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "抽帧定位的回查范围，可能包含转场或其他产品，不是精确剪辑边界。",
          "evidence": "2026.09.07",
          "visual_anchors_seconds": [],
          "timing_label": "00:10:30—00:22:30",
          "timing_status": "回查时间段",
          "talk_segments": [
            {
              "start": 650.0,
              "end": 672.0,
              "title": "最终价格",
              "aspect": "价格与套餐",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-16_2026-09-14/content-v2/reviewed/2026-09-07_2026.09.07/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 782.0,
              "end": 1087.0,
              "title": "从第二个福利品开箱讲到三刀头、磁吸拆洗、旅行锁、适用胡须和最后价格；整段是同一款剃须刀。",
              "aspect": "价格与套餐",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-16_2026-09-14/content-v2/reviewed/2026-09-07_2026.09.07/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 828.0,
              "end": 866.0,
              "title": "三刀头、磁吸、水洗和昵称",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-16_2026-09-14/content-v2/reviewed/2026-09-07_2026.09.07/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 1041.0,
              "end": 1087.0,
              "title": "旅行锁及最终69元",
              "aspect": "价格与套餐",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-16_2026-09-14/content-v2/reviewed/2026-09-07_2026.09.07/segments.json",
              "clock": "已有审校回查时间"
            }
          ],
          "talk_status": "已有审校内容分段"
        },
        {
          "recording_id": "M-45a20a0b2807826b",
          "recording_name": "2026.9.10.mp4",
          "date": "2026-09-10",
          "basis": "2026-10-12 外观复核：待核／未获同款画面证据",
          "windows": [],
          "visual_identity": "本轮抽帧未确认该三刀网剃须刀；旧关联保留待核，不直接使用。",
          "visual_status": "待核",
          "timing_basis": "抽帧定位的回查范围，可能包含转场或其他产品，不是精确剪辑边界。",
          "evidence": "2026.9.10",
          "visual_anchors_seconds": [],
          "timing_label": "尚未确认时间段或商品身份",
          "timing_status": "待核查",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-f1b53e17b0fdd984",
          "recording_name": "2026.9.11.mp4",
          "date": "2026-09-11",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              2610,
              3150
            ]
          ],
          "visual_identity": "亮银色长柄、横向多刀网刀头、黑色礼盒，部分场次可见T9标识；与夏新细柄菱纹款及MS19粗柄款区分。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "抽帧定位的回查范围，可能包含转场或其他产品，不是精确剪辑边界。",
          "evidence": "2026.9.11",
          "visual_anchors_seconds": [],
          "timing_label": "00:43:30—00:52:30",
          "timing_status": "回查时间段",
          "talk_segments": [
            {
              "start": 2623.4,
              "end": 2671.12,
              "title": "猜包装与国家猜测",
              "aspect": "外观与配件",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-16_2026-09-14/content-v2/reviewed/2026-09-11_2026.9.11/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 2673.12,
              "end": 2938.56,
              "title": "展示牙刷、两个刷头及无线充电底座，讲颜色随机、振动方式与续航，最后明确承认后续刷头不知道在哪里配。",
              "aspect": "外观与配件",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-16_2026-09-14/content-v2/reviewed/2026-09-11_2026.9.11/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 2761.56,
              "end": 2817.56,
              "title": "两刷头、底座及续航口述",
              "aspect": "参数与性能说明",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-16_2026-09-14/content-v2/reviewed/2026-09-11_2026.9.11/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 2817.56,
              "end": 2865.56,
              "title": "39元、耗材供应不明",
              "aspect": "价格与套餐",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-16_2026-09-14/content-v2/reviewed/2026-09-11_2026.9.11/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 3001.56,
              "end": 3099.56,
              "title": "Mate80 Pro Max和16+1TB",
              "aspect": "讲解内容",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-16_2026-09-14/content-v2/reviewed/2026-09-11_2026.9.11/segments.json",
              "clock": "已有审校回查时间"
            }
          ],
          "talk_status": "已有审校内容分段"
        },
        {
          "recording_id": "M-aedd8cfb4cc4e65a",
          "recording_name": "2026.9.12.mp4",
          "date": "2026-09-12",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              810,
              1350
            ]
          ],
          "visual_identity": "亮银色长柄、横向多刀网刀头、黑色礼盒，部分场次可见T9标识；与夏新细柄菱纹款及MS19粗柄款区分。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "抽帧定位的回查范围，可能包含转场或其他产品，不是精确剪辑边界。",
          "evidence": "2026.9.12",
          "visual_anchors_seconds": [],
          "timing_label": "00:13:30—00:22:30",
          "timing_status": "回查时间段",
          "talk_segments": [
            {
              "start": 858.0,
              "end": 1131.0,
              "title": "展示刀头、开机和外观，口述防水与粗硬胡须使用场景；完整讲解持续到18:51，后半段包含最终报价和初次使用可能疼痛的提醒。",
              "aspect": "价格与套餐",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-16_2026-09-14/content-v2/reviewed/2026-09-12_2026.9.12/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 954.0,
              "end": 990.0,
              "title": "防水口述与使用人群",
              "aspect": "使用边界",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-16_2026-09-14/content-v2/reviewed/2026-09-12_2026.9.12/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 1052.0,
              "end": 1079.0,
              "title": "末段报价与前几次可能痛",
              "aspect": "价格与套餐",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-16_2026-09-14/content-v2/reviewed/2026-09-12_2026.9.12/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 1093.0,
              "end": 1131.0,
              "title": "结尾报价及粗硬胡须限制",
              "aspect": "价格与套餐",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-16_2026-09-14/content-v2/reviewed/2026-09-12_2026.9.12/segments.json",
              "clock": "已有审校回查时间"
            }
          ],
          "talk_status": "已有审校内容分段"
        },
        {
          "recording_id": "M-876331c2cfde9e91",
          "recording_name": "2026.9.13.mp4",
          "date": "2026-09-13",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对；与9月12疑似重复片源",
          "windows": [
            [
              810,
              1350
            ]
          ],
          "visual_identity": "亮银色长柄、横向多刀网刀头、黑色礼盒，部分场次可见T9标识；与夏新细柄菱纹款及MS19粗柄款区分。 四处抽帧与9月12一致，不认定为独立拍摄场次。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "抽帧定位的回查范围，可能包含转场或其他产品，不是精确剪辑边界。",
          "evidence": "2026.9.13",
          "visual_anchors_seconds": [],
          "timing_label": "00:13:30—00:22:30",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-e0f2c319fea3cfe5",
          "recording_name": "2026.9.14.mp4",
          "date": "2026-09-14",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              450,
              870
            ]
          ],
          "visual_identity": "亮银色长柄、横向多刀网刀头、黑色礼盒，部分场次可见T9标识；与夏新细柄菱纹款及MS19粗柄款区分。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "抽帧定位的回查范围，可能包含转场或其他产品，不是精确剪辑边界。",
          "evidence": "2026.9.14",
          "visual_anchors_seconds": [],
          "timing_label": "00:07:30—00:14:30",
          "timing_status": "回查时间段",
          "talk_segments": [
            {
              "start": 486.5,
              "end": 489.38,
              "aspect": "接口、长度与兼容",
              "title": "外观、材质与配件介绍",
              "quote": "女孩的接口 女孩的接口是双C",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 498.06,
              "end": 500.58,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "我们14块9毛钱这个 真太便宜了这个",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 517.86,
              "end": 524.42,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "这个线说了都卖200块钱一根肉线 线都卖200块钱一根 总共这一套14块9毛钱",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 687.56,
              "end": 691.16,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "全身水洗 充电用一个多月 它不洗口充电",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 691.16,
              "end": 693.06,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "然后这是它的顶个包装",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 695.06,
              "end": 699.56,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "松下属 你的最马正是1000块钱 你们心目中要的最便宜的价格",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 714.06,
              "end": 716.06,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "官方卖400块钱",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 726.56,
              "end": 731.56,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "99块钱 99块三刀头往腹是",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 733.56,
              "end": 736.06,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "三刀头往这外观都没话说了",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 853.66,
              "end": 855.06,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "要不要整箱来买的",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-14_2026.9.14.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            }
          ],
          "talk_status": "转写内容初标，需回听核查"
        },
        {
          "recording_id": "M-371394ef849bd952",
          "recording_name": "2026.9.16.mp4",
          "date": "2026-09-16",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              4590,
              5310
            ]
          ],
          "visual_identity": "亮银色长柄、横向多刀网刀头、黑色礼盒，部分场次可见T9标识；与夏新细柄菱纹款及MS19粗柄款区分。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "抽帧定位的回查范围，可能包含转场或其他产品，不是精确剪辑边界。",
          "evidence": "2026.9.16",
          "visual_anchors_seconds": [],
          "timing_label": "01:16:30—01:28:30",
          "timing_status": "回查时间段",
          "talk_segments": [
            {
              "start": 4596.24,
              "end": 4597.36,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "我不能拿一个东西",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-16_2026.9.16.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 4597.36,
              "end": 4599.24,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "就是拿一个价格去互动运动吗",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-16_2026.9.16.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 4632.88,
              "end": 4635.08,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "我就会特别注意这个品以后就不会上",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-16_2026.9.16.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 4767.26,
              "end": 4769.26,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "这个简单的速度有点不错",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-16_2026.9.16.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 4769.26,
              "end": 4782.58,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "然后我先告诉大家多少钱 这个线最起码它的做工成本应该在50块钱以上 这个车中的PD快成时候30导的20块钱吧 这个成本70块钱左右 然后卖老美卖多少钱 卖300块钱",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-16_2026.9.16.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 4800.0,
              "end": 4821.4,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "然后这一套多少钱呢 这一套14块9毛钱 这个线的成本最起码要50块钱才能做出来",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-16_2026.9.16.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 4870.32,
              "end": 4871.84,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "能不能达到这儿水准",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-16_2026.9.16.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 4875.94,
              "end": 4879.02,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "有人从我们这老货卖在老去卖多少钱",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-16_2026.9.16.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 4907.52,
              "end": 4910.56,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "头架线一起14块就冒险",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-16_2026.9.16.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 4954.88,
              "end": 4957.7,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "这条线不是这条线卖14块9是",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-16_2026.9.16.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 4962.04,
              "end": 4963.58,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "一起14块9毛钱",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-16_2026.9.16.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 5103.7,
              "end": 5106.7,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "不要找貓哥找偉哥",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-16_2026.9.16.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 5148.6,
              "end": 5150.6,
              "aspect": "功能与操作",
              "title": "功能介绍与操作演示",
              "quote": "三十岁以上你不用这种机上那个显示你够了",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-16_2026.9.16.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 5161.6,
              "end": 5163.6,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "这个充电试件可以用一个多月这个",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-16_2026.9.16.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 5163.6,
              "end": 5169.1,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "这个卖多少钱这个 那400块,300块钱",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-16_2026.9.16.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 5172.1,
              "end": 5184.1,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "可以防水啊 前身防水看着面",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-16_2026.9.16.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 5195.3,
              "end": 5197.46,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "这个外观没话说 来个步给我擦一下了",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-16_2026.9.16.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 5207.98,
              "end": 5209.46,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "不要 他这中间是那个软",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-16_2026.9.16.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 5223.54,
              "end": 5226.22,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "这个算一个伟货了这个多少钱",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-16_2026.9.16.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 5297.38,
              "end": 5298.58,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "这上车都不要啊",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-16_2026.9.16.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            }
          ],
          "talk_status": "转写内容初标，需回听核查"
        },
        {
          "recording_id": "M-49a94fdd1a30bb84",
          "recording_name": "2026.9.18.mp4",
          "date": "2026-09-18",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              990,
              1530
            ]
          ],
          "visual_identity": "亮银色长柄、横向多刀网刀头、黑色礼盒，部分场次可见T9标识；与夏新细柄菱纹款及MS19粗柄款区分。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "抽帧定位的回查范围，可能包含转场或其他产品，不是精确剪辑边界。",
          "evidence": "2026.9.18",
          "visual_anchors_seconds": [],
          "timing_label": "00:16:30—00:25:30",
          "timing_status": "回查时间段",
          "talk_segments": [
            {
              "start": 1020.74,
              "end": 1023.74,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "这个请遇到大家就不用担心他价格的",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1134.56,
              "end": 1138.6,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "这个防水可以啊 来 防水效果也是非常非常不错的",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1141.92,
              "end": 1143.56,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "续航时间充一次电可以用一个度月",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1160.32,
              "end": 1162.36,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "聲音大因為他的功率大數字",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1175.68,
              "end": 1177.72,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "你用不了這麼高功率的",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1187.18,
              "end": 1199.96,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "然后这个多少钱这个 你看一下他赶我卖多少钱这个 开波系列人这果补之后还卖400块钱",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 1200.0,
              "end": 1207.4,
              "aspect": "外观与配件",
              "title": "外观、材质与配件介绍",
              "quote": "看着没有 国补招他们算看一下它整个外观 算不算 整个外观 上面这是盖子",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            },
            {
              "start": 1268.72,
              "end": 1270.32,
              "aspect": "使用边界",
              "title": "适用范围与使用提醒",
              "quote": "不要有壓力就可以了 好不好",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1356.84,
              "end": 1358.2,
              "aspect": "参数与性能说明",
              "title": "参数、续航与性能口述",
              "quote": "你看這個功率有多大一個",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1370.84,
              "end": 1377.64,
              "aspect": "价格与套餐",
              "title": "价格、下单与付款说明",
              "quote": "我就說說69元如果能保你用個兩年 可以的69块钱 让你无闻力刮个两年可以了",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-09-01_2026-09-30/transcripts/2026-09-18_2026.9.18.transcript.json",
              "clock": "原录像转写回查时间，音画切点未精校",
              "status": "转写初标，未逐句回听"
            }
          ],
          "talk_status": "转写内容初标，需回听核查"
        },
        {
          "recording_id": "M-77f975c5c38e5ee4",
          "recording_name": "2026.9.20.MP4",
          "date": "2026-09-20",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              450,
              870
            ]
          ],
          "visual_identity": "亮银色长柄、横向多刀网刀头、黑色礼盒，部分场次可见T9标识；与夏新细柄菱纹款及MS19粗柄款区分。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "抽帧定位的回查范围，可能包含转场或其他产品，不是精确剪辑边界。",
          "evidence": "2026.9.20",
          "visual_anchors_seconds": [],
          "timing_label": "00:07:30—00:14:30",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-68f069c180f0ad3e",
          "recording_name": "2026.9.21.mp4",
          "date": "2026-09-21",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              810,
              1350
            ]
          ],
          "visual_identity": "亮银色长柄、横向多刀网刀头、黑色礼盒，部分场次可见T9标识；与夏新细柄菱纹款及MS19粗柄款区分。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "抽帧定位的回查范围，可能包含转场或其他产品，不是精确剪辑边界。",
          "evidence": "2026.9.21",
          "visual_anchors_seconds": [],
          "timing_label": "00:13:30—00:22:30",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        }
      ],
      "evidence": "payload.json",
      "image_source": "商品链接原图",
      "visual_candidates": [],
      "visual_reviewed_at": "2026-10-12",
      "product_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3842970860688376078&origin_type=604&channel_id=3714548599144706&channel_type=4",
      "link_name": "莱永剃须刀",
      "link_source": "https://maoge.ikumao.cn/douyin/?view=products",
      "link_status": "推广核实正常（2026-10-26核对）；库存另核",
      "image": "https://p3-item.ecombdimg.com/img/ecom-shop-material/jpeg_m_eee34a10a9711c94f532cebc0f2e98ec_sx_115299_www1080-1080~tplv-5mmsx3fupr-resize_q:1080:1080:q90.webp",
      "link_audit": {
        "id": "PF-630d3f91",
        "name": "莱永剃须刀",
        "old_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3842970860688376078&origin_type=604&channel_id=3714548599144706&channel_type=4",
        "promotion_status": "推广核实正常",
        "page_status": "库存未于本轮重新核查",
        "source_rows": [
          {
            "name": "莱永剃须刀",
            "row_id": "188",
            "text": "\t\n莱永剃须刀\n剃须刀 · ID 3842970860688376078\n\t69\t40%\t\n40%\n\t正常\n10/26 07:01\n\t2026/9/21\t\n复制"
          }
        ],
        "checked_at": "2026-10-26",
        "source": "原商品工作台当日07:00—07:09只读结果"
      }
    },
    {
      "id": "PF-7584460b",
      "name": "iPad mini 7（容量与联网版本需分款）",
      "category": "平板与学习设备",
      "aliases": [
        "iPad mini 7 256GB eSIM版（口述国行ASIS）",
        "iPad mini 7 Wi-Fi 256GB（A2996包装标识）",
        "iPad mini 7（短暂展示/比较）",
        "iPad mini 7：128GB／99新（口述）",
        "苹果 iPad mini 7（蓝色256GB eSIM版）",
        "iPad mini 7 256GB WiFi ASIS资源机（二手准新品）",
        "iPad mini 7 256GB WLAN A2996（ASIS资源机）"
      ],
      "description": "小尺寸平直边框平板、单后置摄像头及Apple标识；仅机身不能区分mini 6/7、容量或联网版本。 保留7月15/20、8月13三场，补8月13回查段。7月17日仅发现相似mini外观，代际未确认，另列候选。",
      "cautions": [
        "口述ASIS货源不能直接等于常规原封全新零售机；“当新机买”是销售说法。",
        "两年质保和电池100是页面/主播主张，具体责任主体及健康数据未核。",
        "保留7月15/20、8月13三场，补8月13回查段。7月17日仅发现相似mini外观，代际未确认，另列候选。",
        "外观复核仅确认画面对应关系，不代替型号、配置或商品链接SKU核对。"
      ],
      "appearances": [
        {
          "recording_id": "M-6272dfc571123b0f",
          "recording_name": "2026.7.15.mp4",
          "date": "2026-07-15",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              3578.46,
              3600.46
            ],
            [
              3606.8,
              3978.48
            ],
            [
              3998.52,
              4017.72
            ],
            [
              4024.64,
              4068.24
            ],
            [
              5184.6,
              5188.6
            ],
            [
              5429.06,
              5497.7
            ],
            [
              5503.14,
              5652.14
            ]
          ],
          "visual_identity": "小尺寸平直边框平板、单后置摄像头及Apple标识；仅机身不能区分mini 6/7、容量或联网版本。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "原有分析时间段，结合抽帧复核；正式剪辑仍需逐段回看。",
          "evidence": "2026.7.15",
          "visual_anchors_seconds": [],
          "timing_label": "00:59:38—01:00:00、01:00:06—01:06:18、01:06:38—01:06:57、01:07:04—01:07:48、01:26:24—01:26:28、01:30:29—01:31:37、01:31:43—01:34:12",
          "timing_status": "回查时间段",
          "talk_segments": [
            {
              "start": 3578.46,
              "end": 3600.46,
              "title": "苹果电脑开场，立即更正不是新机。",
              "aspect": "讲解内容",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-15_2026.7.15/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 3606.8,
              "end": 3771.32,
              "title": "A2251/13.3英寸/i7/16+512口述及macOS、TouchBar展示。",
              "aspect": "讲解内容",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-15_2026.7.15/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 3771.32,
              "end": 3901.52,
              "title": "2999及双系统演示，随后承认样机只有一个系统，称发货再装。",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-15_2026.7.15/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 3902.16,
              "end": 3978.48,
              "title": "二手保值观点、尺寸对比、绘图不保证与7天试用，充电器配件。",
              "aspect": "外观与配件",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-15_2026.7.15/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 3998.52,
              "end": 4017.72,
              "title": "内存升级与价值口述。",
              "aspect": "参数与性能说明",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-15_2026.7.15/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 4024.64,
              "end": 4068.24,
              "title": "厚度与手机对比、二手外观及电池数据可改，不保证续航。",
              "aspect": "外观与配件",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-15_2026.7.15/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 5429.06,
              "end": 5497.7,
              "title": "iPadmini7、eSIM及8.3英寸、随身携带。",
              "aspect": "讲解内容",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-15_2026.7.15/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 5503.14,
              "end": 5652.14,
              "title": "装口袋演示、256GB/eSIM、4288与12期357.33、二年质保页面。",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-15_2026.7.15/segments.json",
              "clock": "已有审校回查时间"
            }
          ],
          "talk_status": "已有审校内容分段"
        },
        {
          "recording_id": "M-961593fedd8eadd5",
          "recording_name": "2026.7.20.mp4",
          "date": "2026-07-20",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              3773.08,
              3777.76
            ],
            [
              3854.88,
              3913.72
            ],
            [
              3921.36,
              4154.74
            ],
            [
              4212.34,
              4231.7
            ],
            [
              4264.94,
              4267.94
            ],
            [
              4279.94,
              4321.7
            ],
            [
              4345.94,
              4397.66
            ]
          ],
          "visual_identity": "小尺寸平直边框平板、单后置摄像头及Apple标识；仅机身不能区分mini 6/7、容量或联网版本。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "原有分析时间段，结合抽帧复核；正式剪辑仍需逐段回看。",
          "evidence": "2026.7.20",
          "visual_anchors_seconds": [],
          "timing_label": "01:02:53—01:02:57、01:04:14—01:05:13、01:05:21—01:09:14、01:10:12—01:10:31、01:11:04—01:11:07、01:11:19—01:12:01、01:12:25—01:13:17",
          "timing_status": "回查时间段",
          "talk_segments": [
            {
              "start": 3854.88,
              "end": 3913.72,
              "title": "iPad mini7 256GB蜂窝eSIM版，外观与天线。",
              "aspect": "外观与配件",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-20_2026.7.20/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 3921.36,
              "end": 4154.74,
              "title": "国行ASIS、A17 Pro口述、256GB/eSIM、4288和12期357.33；非免费，所谓最高配随即承认还有512GB。",
              "aspect": "讲解内容",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-20_2026.7.20/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 4212.34,
              "end": 4231.7,
              "title": "平板分期路径及4288/每月357口述。",
              "aspect": "价格与套餐",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-20_2026.7.20/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 4264.94,
              "end": 4267.94,
              "title": "又称最高配，需结合256并非最大容量的前文。",
              "aspect": "参数与性能说明",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-20_2026.7.20/segments.json",
              "clock": "已有审校回查时间",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 4279.94,
              "end": 4321.7,
              "title": "2700多旧价属128GB WiFi及补贴，不能套本次256GB蜂窝。",
              "aspect": "使用边界",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-20_2026.7.20/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 4345.94,
              "end": 4397.66,
              "title": "再讲4288/12期357.33，键盘笔赠品口述，写号需运营商。",
              "aspect": "讲解内容",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-20_2026.7.20/segments.json",
              "clock": "已有审校回查时间"
            }
          ],
          "talk_status": "已有审校内容分段"
        },
        {
          "recording_id": "M-603ee0e2ea5dc64c",
          "recording_name": "2026.8.13.mp4",
          "date": "2026-08-13",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              4830,
              5310
            ]
          ],
          "visual_identity": "小尺寸平直边框平板、单后置摄像头及Apple标识；仅机身不能区分mini 6/7、容量或联网版本。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "抽帧定位的回查范围，可能包含转场或其他产品，不是精确剪辑边界。",
          "evidence": "2026.8.13",
          "visual_anchors_seconds": [],
          "timing_label": "01:20:30—01:28:30",
          "timing_status": "回查时间段",
          "talk_segments": [
            {
              "start": 4763.08,
              "end": 5320.04,
              "title": "回收近新，最后5488元；键盘另售。",
              "aspect": "价格与套餐",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-01_2026-08-31/content-v2/reviewed/2026-08-13_2026.8.13/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 4853.5,
              "end": 4888.9,
              "title": "代际来源及电池口述",
              "aspect": "参数与性能说明",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-01_2026-08-31/content-v2/reviewed/2026-08-13_2026.8.13/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 4997.9,
              "end": 5040.8,
              "title": "卡槽演示和兼容",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-01_2026-08-31/content-v2/reviewed/2026-08-13_2026.8.13/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 5085.7,
              "end": 5147.26,
              "title": "容量/硬盘与售后",
              "aspect": "参数与性能说明",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-01_2026-08-31/content-v2/reviewed/2026-08-13_2026.8.13/segments.json",
              "clock": "已有审校回查时间"
            }
          ],
          "talk_status": "已有审校内容分段"
        }
      ],
      "evidence": "payload.json",
      "image_source": "商品链接原图",
      "visual_candidates": [
        {
          "recording_id": "M-0f0506b75dccf769",
          "date": "2026-07-17",
          "name": "2026.7.17.mp4",
          "windows": [
            [
              5130,
              5610
            ]
          ],
          "reason": "小尺寸Apple平板外形相近，但mini 6/7代际未确认，未增加到已关联素材。"
        }
      ],
      "visual_reviewed_at": "2026-10-12",
      "product_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3796100518275842402&origin_type=604",
      "link_name": "iPad MINI7",
      "link_source": "原商品库只读查询，同型号按本次列表最新顺序优先",
      "link_status": "推广核实正常（2026-10-26核对）；库存另核",
      "image": "https://p26-item.ecombdimg.com/img/ecom-shop-material/jpeg_m_e19ac075b9eba29ef47d5b82ccb5fa68_sx_402920_www800-800~tplv-5mmsx3fupr-resize_q:1080:1080:q90.webp",
      "link_audit": {
        "id": "PF-7584460b",
        "name": "iPad MINI7",
        "old_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3796100518275842402&origin_type=604",
        "promotion_status": "推广核实正常",
        "page_status": "库存未于本轮重新核查",
        "source_rows": [
          {
            "name": "iPad MINI7",
            "row_id": "169",
            "text": "\t\niPad MINI7\n未分类 · ID 3796100518275842402\n\t—\t—\t\n1%\n\t待补基准\n10/26 07:02\n\t2026/9/15\t\n复制"
          },
          {
            "name": "iPad MINI7",
            "row_id": "108",
            "text": "\t\niPad MINI7\n未分类 · ID 3796100518275842402\n\t—\t1.00%\t\n1%\n\t正常\n10/26 07:05\n\t2026/9/15\t\n复制"
          }
        ],
        "checked_at": "2026-10-26",
        "source": "原商品工作台当日07:00—07:09只读结果"
      }
    },
    {
      "id": "PF-7da42cfa",
      "name": "金运 KINYO C13耳夹耳机",
      "category": "耳机",
      "aliases": [
        "金运KINYO C13开放式耳夹耳机"
      ],
      "description": "白色圆角充电仓与白色弧形连接耳机组件，黑色款同时展示，配合KINYO/C13包装核对。 补8月11/13回查段，8月11后段有再次展示。未确认新增同款日期。",
      "cautions": [
        "型号和UI可以确认；音质、降噪、翻译准确率/离线、续航、全球销量第一和公益宣传未独立验证。",
        "补8月11/13回查段，8月11后段有再次展示。未确认新增同款日期。",
        "外观复核仅确认画面对应关系，不代替型号、配置或商品链接SKU核对。"
      ],
      "appearances": [
        {
          "recording_id": "M-108cc658f4c20796",
          "recording_name": "2026.08.11.mp4",
          "date": "2026-08-11",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              2070,
              3150
            ],
            [
              6450,
              7050
            ]
          ],
          "visual_identity": "白色圆角充电仓与白色弧形连接耳机组件，黑色款同时展示，配合KINYO/C13包装核对。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "抽帧定位的回查范围，可能包含转场或其他产品，不是精确剪辑边界。",
          "evidence": "2026.08.11",
          "visual_anchors_seconds": [],
          "timing_label": "00:34:30—00:52:30、01:47:30—01:57:30",
          "timing_status": "回查时间段",
          "talk_segments": [
            {
              "start": 2140.38,
              "end": 3134.16,
              "title": "本场主报价399元，画面另有329元条件优惠；12期为33.25×12、总399。",
              "aspect": "价格与套餐",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-01_2026-08-31/content-v2/reviewed/2026-08-11_2026.08.11/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 2233.94,
              "end": 2278.18,
              "title": "盒及Dongle",
              "aspect": "外观与配件",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-01_2026-08-31/content-v2/reviewed/2026-08-11_2026.08.11/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 2370.66,
              "end": 2418.0,
              "title": "芯片和体感",
              "aspect": "参数与性能说明",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-01_2026-08-31/content-v2/reviewed/2026-08-11_2026.08.11/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 2516.2,
              "end": 2538.56,
              "title": "续航双设备",
              "aspect": "参数与性能说明",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-01_2026-08-31/content-v2/reviewed/2026-08-11_2026.08.11/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 2553.98,
              "end": 2564.32,
              "title": "芯片名称",
              "aspect": "参数与性能说明",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-01_2026-08-31/content-v2/reviewed/2026-08-11_2026.08.11/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 2756.26,
              "end": 2827.7,
              "title": "价格和分期",
              "aspect": "价格与套餐",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-01_2026-08-31/content-v2/reviewed/2026-08-11_2026.08.11/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 2985.68,
              "end": 3008.8,
              "title": "跌倒功能口述",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-01_2026-08-31/content-v2/reviewed/2026-08-11_2026.08.11/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 6370.08,
              "end": 7103.72,
              "title": "最终99元；18个月质量换新、15天试用及顺丰为卖方承诺。",
              "aspect": "价格与套餐",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-01_2026-08-31/content-v2/reviewed/2026-08-11_2026.08.11/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 6526.04,
              "end": 6581.1,
              "title": "13mm/4.7g/通话降噪",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-01_2026-08-31/content-v2/reviewed/2026-08-11_2026.08.11/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 6608.6,
              "end": 6647.2,
              "title": "App功能",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-01_2026-08-31/content-v2/reviewed/2026-08-11_2026.08.11/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 6720.88,
              "end": 6739.7,
              "title": "续航",
              "aspect": "参数与性能说明",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-01_2026-08-31/content-v2/reviewed/2026-08-11_2026.08.11/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 6883.18,
              "end": 6925.32,
              "title": "试用清洁和生活防水",
              "aspect": "使用边界",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-01_2026-08-31/content-v2/reviewed/2026-08-11_2026.08.11/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 6996.0,
              "end": 7018.96,
              "title": "摩擦佩戴",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-01_2026-08-31/content-v2/reviewed/2026-08-11_2026.08.11/segments.json",
              "clock": "已有审校回查时间"
            }
          ],
          "talk_status": "已有审校内容分段"
        },
        {
          "recording_id": "M-603ee0e2ea5dc64c",
          "recording_name": "2026.8.13.mp4",
          "date": "2026-08-13",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              3750,
              4770
            ]
          ],
          "visual_identity": "白色圆角充电仓与白色弧形连接耳机组件，黑色款同时展示，配合KINYO/C13包装核对。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "抽帧定位的回查范围，可能包含转场或其他产品，不是精确剪辑边界。",
          "evidence": "2026.8.13",
          "visual_anchors_seconds": [],
          "timing_label": "01:02:30—01:19:30",
          "timing_status": "回查时间段",
          "talk_segments": [
            {
              "start": 3854.72,
              "end": 4750.04,
              "title": "99元；白/黑两色，App功能展示与售后承诺是主要选题。",
              "aspect": "价格与套餐",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-01_2026-08-31/content-v2/reviewed/2026-08-13_2026.8.13/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 3940.96,
              "end": 4019.36,
              "title": "材质擦拭与佩戴",
              "aspect": "外观与配件",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-01_2026-08-31/content-v2/reviewed/2026-08-13_2026.8.13/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 4151.12,
              "end": 4238.24,
              "title": "翻译菜单及宣称",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-01_2026-08-31/content-v2/reviewed/2026-08-13_2026.8.13/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 4254.24,
              "end": 4277.68,
              "title": "参数与擦拭",
              "aspect": "参数与性能说明",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-01_2026-08-31/content-v2/reviewed/2026-08-13_2026.8.13/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 4346.04,
              "end": 4406.56,
              "title": "99价格与售后",
              "aspect": "价格与套餐",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-01_2026-08-31/content-v2/reviewed/2026-08-13_2026.8.13/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 4647.48,
              "end": 4685.04,
              "title": "漏音和通话",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-01_2026-08-31/content-v2/reviewed/2026-08-13_2026.8.13/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 4724.12,
              "end": 4750.04,
              "title": "限购和续航",
              "aspect": "参数与性能说明",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-01_2026-08-31/content-v2/reviewed/2026-08-13_2026.8.13/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 4753.68,
              "end": 4763.08,
              "title": "讲直播手机要补电，不新增商品。",
              "aspect": "讲解内容",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-08-01_2026-08-31/content-v2/reviewed/2026-08-13_2026.8.13/segments.json",
              "clock": "已有审校回查时间"
            }
          ],
          "talk_status": "已有审校内容分段"
        }
      ],
      "evidence": "payload.json",
      "image_source": "商品链接原图",
      "visual_candidates": [],
      "visual_reviewed_at": "2026-10-12",
      "product_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3836357330635719002&origin_type=604&channel_id=3705315421444354&channel_type=4",
      "link_name": "金运耳机C13",
      "link_source": "原商品库只读查询，同型号按本次列表最新顺序优先",
      "link_status": "推广链接失效（2026-10-26核对）；库存另核；暂无有效同款替换",
      "image": "https://p3-item.ecombdimg.com/img/ecom-shop-material/jpeg_m_1b738003aef50c5e05813c3454daf434_sx_265291_www1440-1440~tplv-5mmsx3fupr-resize_q:1080:1080:q90.webp",
      "link_audit": {
        "id": "PF-7da42cfa",
        "name": "金运耳机C13",
        "old_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3836357330635719002&origin_type=604&channel_id=3705315421444354&channel_type=4",
        "promotion_status": "推广链接失效",
        "page_status": "库存未于本轮重新核查",
        "source_rows": [
          {
            "name": "金运耳机C13",
            "row_id": "168",
            "text": "\t\n金运耳机C13\n未分类 · ID 3836357330635719002\n\t109\t40.00%\t\n—\n\t链接失效\n10/26 07:02\n\t2026/9/15\t\n复制"
          }
        ],
        "checked_at": "2026-10-26",
        "source": "原商品工作台当日07:00—07:09只读结果"
      }
    },
    {
      "id": "PF-98c55e65",
      "name": "得力多面插座转换器（型号待核）",
      "category": "充电与手机配件",
      "aliases": [],
      "description": "圆角方块多面插孔转换器、背面固定三脚插头与侧面USB口；蓝灰/粉/绿配色分别核对，额定参数以铭牌为准。 补充9月24日同结构粉绿配色转换器，9月22日蓝灰配色已有近景；同结构不能证明具体型号、功率和USB规格一致。",
      "cautions": [
        "白色长排插是演示道具，不作为这款商品统计。",
        "型号、功率和认证信息未从画面独立确认。",
        "补充9月24日同结构粉绿配色转换器，9月22日蓝灰配色已有近景；同结构不能证明具体型号、功率和USB规格一致。",
        "外观复核仅确认画面对应关系，不代替型号、配置或商品链接SKU核对。"
      ],
      "appearances": [
        {
          "recording_id": "M-6cd07e09b524f6e0",
          "recording_name": "2026.9.22.mp4",
          "date": "2026-09-22",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              270,
              630
            ]
          ],
          "visual_identity": "圆角方块多面插孔转换器、背面固定三脚插头与侧面USB口；蓝灰/粉/绿配色分别核对，额定参数以铭牌为准。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "抽帧定位的回查范围，可能包含转场或其他产品，不是精确剪辑边界。",
          "evidence": "2026.9.22",
          "visual_anchors_seconds": [],
          "timing_label": "00:04:30—00:10:30",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-2ce4ffbb95b618c1",
          "recording_name": "2026.9.24.mp4",
          "date": "2026-09-24",
          "basis": "2026-10-12 外观复核：同结构不同配色；型号待核",
          "windows": [
            [
              330,
              420
            ]
          ],
          "visual_identity": "圆角方块多面插孔转换器、背面固定三脚插头与侧面USB口；蓝灰/粉/绿配色分别核对，额定参数以铭牌为准。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "30秒间隔抽帧确认的回查范围，不是精确剪辑边界。",
          "evidence": "得力补查",
          "visual_anchors_seconds": [],
          "timing_label": "00:05:30—00:07:00",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        }
      ],
      "evidence": "payload.json",
      "image_source": "商品链接原图",
      "visual_candidates": [],
      "visual_reviewed_at": "2026-10-12",
      "product_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3837582747082293606&origin_type=604&channel_id=3708055648227074&channel_type=4",
      "link_name": "得力小魔方充电头",
      "link_source": "原商品库只读查询；按添加日期/列表顺序选取本款最新可打开链接",
      "link_status": "推广链接失效（2026-10-26核对）；库存另核；暂无有效同款替换",
      "binding_scope": "仅按以下已核对实物画面使用；其他日期、容量、颜色及具体配置不能自动套用：2026.9.22.mp4，已查看原目录实物缩略图，源秒数未记录",
      "appearance_match": "魔方壳体、双色侧面和多面插孔布局与商品图对应；目录已有得力品牌实物记录",
      "appearance_checked_at": "2026-10-12T09:30:04.695093+08:00",
      "image": "https://p26-item.ecombdimg.com/img/ecom-shop-material/jpeg_m_c43a7f5882a0db6a08f22728906b7c45_sx_271746_www1131-1131~tplv-5mmsx3fupr-resize_q:1080:1080:q90.webp",
      "link_audit": {
        "id": "PF-98c55e65",
        "name": "得力小魔方充电头",
        "old_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3837582747082293606&origin_type=604&channel_id=3708055648227074&channel_type=4",
        "promotion_status": "推广链接失效",
        "page_status": "库存未于本轮重新核查",
        "source_rows": [
          {
            "name": "得力小魔方充电头",
            "row_id": "193",
            "text": "\t\n得力小魔方充电头\n充电头 · ID 3837582747082293606\n\t12.9\t10%\t\n11%\n上次成功 10/20 07:00\n\t链接失效\n10/26 07:01\n\t2026/9/24\t\n复制"
          }
        ],
        "checked_at": "2026-10-26",
        "source": "原商品工作台当日07:00—07:09只读结果"
      }
    },
    {
      "id": "PF-a04d7254",
      "name": "云小鹿 Meet 60 AI鼠标",
      "category": "电脑周边与存储",
      "aliases": [
        "云小鹿 CloudDeer Meet 60 AI三模鼠标"
      ],
      "description": "白色长椭圆鼠标、红色滚轮、滚轮下方按键及Meet 60包装，与桌面操作画面对应。 7月29日白色红滚轮机身外观已复核，保留原时间段。本轮未确认新增同款日期。",
      "cautions": [
        "语音输入和翻译均存在可见错误，不能只剪成功文字、删掉失误后宣称准确无误。",
        "本日未完成AI生成或会议记录，不能算功能已验证；须安装配套软件，AI并非离线鼠标内运算的证据。",
        "7月29日白色红滚轮机身外观已复核，保留原时间段。本轮未确认新增同款日期。",
        "外观复核仅确认画面对应关系，不代替型号、配置或商品链接SKU核对。"
      ],
      "appearances": [
        {
          "recording_id": "M-3351cde4751e7974",
          "recording_name": "2026.7.29.mp4",
          "date": "2026-07-29",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              5362.96,
              5839.96
            ]
          ],
          "visual_identity": "白色长椭圆鼠标、红色滚轮、滚轮下方按键及Meet 60包装，与桌面操作画面对应。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "原有分析时间段，结合抽帧复核；正式剪辑仍需逐段回看。",
          "evidence": "2026.7.29",
          "visual_anchors_seconds": [],
          "timing_label": "01:29:22—01:37:19",
          "timing_status": "回查时间段",
          "talk_segments": [
            {
              "start": 5362.96,
              "end": 5839.96,
              "title": "云小鹿Mate60 AI三模鼠标，语音输入与翻译有可见错误，AI/会议软件未准备好，99元12期与收尾答疑。",
              "aspect": "价格与套餐",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-29_2026.7.29/segments.json",
              "clock": "已有审校回查时间"
            }
          ],
          "talk_status": "已有审校内容分段"
        }
      ],
      "evidence": "payload.json",
      "image_source": "商品链接原图",
      "visual_candidates": [],
      "visual_reviewed_at": "2026-10-12",
      "product_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3786971107798679830&origin_type=604",
      "link_name": "云小鹿ai鼠标",
      "link_source": "原商品库只读查询；按添加日期/列表顺序选取本款最新可打开链接",
      "link_status": "推广核实正常（2026-10-26核对）；库存另核",
      "binding_scope": "仅按以下已核对实物画面使用；其他日期、容量、颜色及具体配置不能自动套用：2026.7.29.mp4，源5440.000秒",
      "appearance_match": "白色机身、红色滚轮、听键、侧边圆形及条形按键与商品图对应，包装可读Meet60",
      "appearance_checked_at": "2026-10-12T09:30:04.695093+08:00",
      "image": "https://p3-item.ecombdimg.com/img/ecom-shop-material/png_m_82e4b4c2daf27c805fb9318a05b40a50_sx_1067366_www1080-1080~tplv-5mmsx3fupr-resize_q:1080:1080:q90.webp",
      "link_audit": {
        "id": "PF-a04d7254",
        "name": "云小鹿ai鼠标",
        "old_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3786971107798679830&origin_type=604",
        "promotion_status": "推广核实正常",
        "page_status": "库存未于本轮重新核查",
        "source_rows": [
          {
            "name": "云小鹿ai鼠标",
            "row_id": "116",
            "text": "\t\n云小鹿ai鼠标\n未分类 · ID 3786971107798679830\n\t99\t40.00%\t\n40%\n\t正常\n10/26 07:04\n\t2026/9/15\t\n复制"
          }
        ],
        "checked_at": "2026-10-26",
        "source": "原商品工作台当日07:00—07:09只读结果"
      }
    },
    {
      "id": "PF-e4ae2087",
      "name": "MAGCUBIC投影仪（HY350MAX与未明款）",
      "category": "音箱与投影",
      "aliases": [
        "MAGCUBIC HY350MAX 投影仪（页面型号）",
        "正投MAGCUBIC短焦投影仪（具体型号待核）"
      ],
      "description": "浅灰方形投影机、前面密集格栅与大镜头、侧支架；7月21/30分别记录，不能直接认定两场完全同型号。 7月21/30现有素材已复核。9月24第二段与9月26第二段为黑面白壳外观，未作为灰色格栅款新增同款素材。",
      "cautions": [
        "不得宣传完全不关灯、白天强光效果；拍摄曝光也影响观感。",
        "原生1080P不能写成原生4K/8K；播放兼容性口述不等于实际解码测试。",
        "7月21/30现有素材已复核。9月24第二段与9月26第二段为黑面白壳外观，未作为灰色格栅款新增同款素材。",
        "外观复核仅确认画面对应关系，不代替型号、配置或商品链接SKU核对。"
      ],
      "appearances": [
        {
          "recording_id": "M-22185293e96d6bad",
          "recording_name": "2026.7.21.mp4",
          "date": "2026-07-21",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              1273.5,
              1973.1
            ],
            [
              1982.1,
              2080.84
            ],
            [
              2092.24,
              2107.34
            ],
            [
              2155.34,
              2160.34
            ]
          ],
          "visual_identity": "浅灰方形投影机、前面密集格栅与大镜头、侧支架；7月21/30分别记录，不能直接认定两场完全同型号。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "原有分析时间段，结合抽帧复核；正式剪辑仍需逐段回看。",
          "evidence": "2026.7.21",
          "visual_anchors_seconds": [],
          "timing_label": "00:21:13—00:32:53、00:33:02—00:34:40、00:34:52—00:35:07、00:35:55—00:36:00",
          "timing_status": "回查时间段",
          "talk_segments": [
            {
              "start": 1273.5,
              "end": 1973.1,
              "title": "MAGCUBIC投影仪实地投墙、对焦校正、U盘样片与距离展示；最终599。",
              "aspect": "讲解内容",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-21_2026.7.21/segments.json",
              "clock": "已有审校回查时间"
            },
            {
              "start": 1982.1,
              "end": 2080.84,
              "title": "补充599、短距离投影和强光需拉窗帘，售后与赠品须核具体条件。",
              "aspect": "讲解内容",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-21_2026.7.21/segments.json",
              "clock": "已有审校回查时间"
            }
          ],
          "talk_status": "已有审校内容分段"
        },
        {
          "recording_id": "M-4c1779a30fd9f580",
          "recording_name": "2026.7.30.mp4",
          "date": "2026-07-30",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              4296.92,
              5132.3
            ]
          ],
          "visual_identity": "浅灰方形投影机、前面密集格栅与大镜头、侧支架；7月21/30分别记录，不能直接认定两场完全同型号。",
          "visual_status": "外观同组，型号/配置待逐场核对",
          "timing_basis": "原有分析时间段，结合抽帧复核；正式剪辑仍需逐段回看。",
          "evidence": "2026.7.30",
          "visual_anchors_seconds": [],
          "timing_label": "01:11:36—01:25:32",
          "timing_status": "回查时间段",
          "talk_segments": [
            {
              "start": 4296.92,
              "end": 5132.3,
              "title": "正投MAGCUBIC投影仪，换白墙并关闭部分灯，移机自动校正、影视首页和U盘演示；内存更正2+16，最终599元。",
              "aspect": "价格与套餐",
              "evidence": "/Volumes/视频文件/ai分析直播内容/素材与分析/分析结果/2026-07-01_2026-07-31/content-v2/reviewed/2026-07-30_2026.7.30/segments.json",
              "clock": "已有审校回查时间"
            }
          ],
          "talk_status": "已有审校内容分段"
        }
      ],
      "evidence": "payload.json",
      "image_source": "商品链接原图",
      "visual_candidates": [],
      "visual_reviewed_at": "2026-10-12",
      "product_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3786611902503845997&origin_type=604&channel_id=3699364565646082&channel_type=4",
      "link_name": "MAG投影仪",
      "link_source": "原商品库只读查询；按添加日期/列表顺序选取本款最新可打开链接",
      "link_status": "推广核实正常（2026-10-26核对）；库存另核",
      "binding_scope": "仅按以下已核对实物画面使用；其他日期、容量、颜色及具体配置不能自动套用：已查看素材目录原实物缩略图，源秒数未记录",
      "appearance_match": "MAGCUBIC标识、金属色网孔前面板、右侧圆镜头、左侧椭圆窗口及U形支架对应商品图；不套给雷神PLAYER",
      "appearance_checked_at": "2026-10-12T09:30:04.695093+08:00",
      "image": "https://p9-aio.ecombdimg.com/obj/ecom-shop-material/jpeg_m_4a2d686e671667a6221e9d8ec48be9e7_sx_416658_www800-800",
      "link_audit": {
        "id": "PF-e4ae2087",
        "name": "MAG投影仪",
        "old_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3786611902503845997&origin_type=604&channel_id=3699364565646082&channel_type=4",
        "promotion_status": "推广核实正常",
        "page_status": "库存未于本轮重新核查",
        "source_rows": [
          {
            "name": "MAG投影仪",
            "row_id": "167",
            "text": "\t\nMAG投影仪\n未分类 · ID 3786611902503845997\n\t599\t30.00%\t\n30%\n\t正常\n10/26 07:02\n\t2026/9/15\t\n复制"
          }
        ],
        "checked_at": "2026-10-26",
        "source": "原商品工作台当日07:00—07:09只读结果"
      }
    },
    {
      "id": "A-6f11746d6c5ab899",
      "name": "淘丁堡H8系列圆屏智能手表（H8 P／H8 Pro）",
      "category": "手表",
      "aliases": [
        "淘丁堡 H8 P 智能手表",
        "淘丁堡WATCH Pro",
        "WATCH Pro",
        "3848948611220111434"
      ],
      "description": "汇总H8 P与H8 Pro的素材入口。H8 P场次保留订单标题、表带及功能说明；H8 Pro场次保留黑银两色、曲面表盘和菜单演示。按每条素材原名称分别选款，现有商品链接对应H8 Pro。",
      "cautions": [
        "来源为已有分析或切片方案，型号及剪辑边界请核对原素材。",
        "补充9月21、23、26第一段、27、29日同外观套装组；H8 P/Pro不可只按圆屏认定。现有H8 Pro链接不能自动用于H8 P功能话术。",
        "外观复核仅确认画面对应关系，不代替型号、配置或商品链接SKU核对。",
        "订单标题仅写 H8 P，未证实 Pro 后缀。 支付、健康监测和售后承诺未独立核验。 10月1日实际订单标题为淘丁堡H8·P，不是华为；圆表与钢带可见。售价239、个人优惠后225.2只记录当时画面，不作所有人的价格；订单图含私人地址，不上传。 蓝牙通话与导航依赖手机；AI菜单曾缺失待更新。独立微信、NFC、健康、防水及5–7天续航未独立验证，钢带重与皮带不可泡水的说明须保留。 10月1日本项实物出现已核实；原音疑点与精确音画时码继续审核，属于产品级部分上线，不计整场交付。",
        "2026-10-19 新链接标题写WATCH Pro，参数栏写H8 Pro；商品主图与原链接使用相同图片资源9b142d49e6be30f1d022c0ae29fd982a。网页价格仅显示2??，不记录精确价格。"
      ],
      "appearances": [
        {
          "recording_id": "M-9159a46bc5731110",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              1364.0,
              3372.76
            ]
          ],
          "visual_anchors_seconds": [],
          "timing_label": "00:22:44—00:56:12",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-68f069c180f0ad3e",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              2370,
              4830
            ]
          ],
          "visual_anchors_seconds": [],
          "timing_label": "00:39:30—01:20:30",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-6cd07e09b524f6e0",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对；已有产品目录",
          "windows": [
            [
              1830,
              3450
            ]
          ],
          "visual_anchors_seconds": [],
          "timing_label": "00:30:30—00:57:30",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-6b992df647c3735f",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              2490,
              4110
            ]
          ],
          "visual_anchors_seconds": [],
          "timing_label": "00:41:30—01:08:30",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-9a41db0033816128",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              2250,
              3450
            ]
          ],
          "visual_anchors_seconds": [],
          "timing_label": "00:37:30—00:57:30",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-8f069728a48d9a84",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              2970,
              4530
            ]
          ],
          "visual_anchors_seconds": [],
          "timing_label": "00:49:30—01:15:30",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-f319369b146d11f0",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "windows": [
            [
              2250,
              3510
            ]
          ],
          "visual_anchors_seconds": [],
          "timing_label": "00:37:30—00:58:30",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-c9d1cc58905bf21e",
          "basis": "2026-10-12 外观复核：外观同组；型号配置逐场核对；已有产品目录",
          "windows": [
            [
              1890,
              3450
            ]
          ],
          "visual_anchors_seconds": [],
          "timing_label": "00:31:30—00:57:30",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        }
      ],
      "evidence": "产品索引.json",
      "visual_candidates": [],
      "visual_reviewed_at": "2026-10-12",
      "product_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3843396030414585934&origin_type=604",
      "link_name": "【新品上市】WATCH Pro男士淘丁堡AI智能手表潮流运动简约离线支付M",
      "link_source": "原商品工作台2026-10-24核实正常；实时商品页品牌型号和主图复核",
      "link_status": "推广链接失效（2026-10-26核对）；库存另核；暂无有效同款替换",
      "binding_scope": "H8 Pro场次；H8 P不可自动匹配",
      "image_source": "2026-10-24新链接主图",
      "image": "https://p26-item.ecombdimg.com/img/ecom-shop-material/png_m_9b142d49e6be30f1d022c0ae29fd982a_sx_329711_www800-800~tplv-5mmsx3fupr-resize_q:1080:1080:q90.webp",
      "merged_product_ids": [
        "PF-16a193d5"
      ],
      "merge_notes": "用户指定汇总两条淘丁堡手表信息；按H8系列集中查询，H8 P及H8 Pro原名称与场次分别保留，未认定两者为相同SKU。H8 Pro链接仅适用于已核对的H8 Pro素材。",
      "candidate_links": [
        {
          "name": "淘丁堡H8pro 手表（原链接）",
          "url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3844086654470062360&origin_type=604"
        }
      ],
      "verification": {
        "status": "新链接已核对 · H8 Pro分款使用",
        "checked_at": "2026-10-19",
        "evidence": "/Users/szx/Movies/gpt/淘丁堡新链接补充_20261019/商品页面核对.md",
        "identity": "新链接标题WATCH Pro，参数栏H8 Pro；与原链接主图相同。原8场为系列素材入口，H8 P场次不自动匹配本链接。",
        "basis": "商品页可见参数及主图资源核对；价格与性能未独立验证。",
        "name": "淘丁堡H8系列圆屏智能手表（H8 P／H8 Pro）"
      },
      "link_audit": {
        "id": "A-6f11746d6c5ab899",
        "name": "【新品上市】WATCH Pro男士淘丁堡AI智能手表潮流运动简约离线支付M",
        "old_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3843396030414585934&origin_type=604",
        "promotion_status": "推广链接失效",
        "page_status": "库存未于本轮重新核查",
        "source_rows": [
          {
            "name": "淘丁堡手表（更新链接）",
            "row_id": "212",
            "text": "\t\n淘丁堡手表（更新链接）\n手表 · ID 3843396030414585934\n\t239\t45%\t\n45%\n上次成功 10/25 07:00\n\t链接失效\n10/26 07:00\n\t2026/10/23\t\n复制"
          }
        ],
        "checked_at": "2026-10-26",
        "source": "原商品工作台当日07:00—07:09只读结果"
      },
      "link_history": [
        {
          "url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3848948611220111434&origin_type=604",
          "name": "淘丁堡 WATCH Pro 智能手表（商品页参数 H8 Pro）",
          "replaced_at": "2026-10-24",
          "reason": "原站推广失效，替换同型号正常新链接"
        }
      ],
      "link_override": true
    },
    {
      "id": "U-BLACKFOMBO-FC30-3843901869952992943",
      "name": "黑蜂暴 FC30 自带双线充电宝（容量分款）",
      "category": "充电与手机配件",
      "aliases": [
        "BLACK FOMBO",
        "黑蜂暴",
        "黑风暴",
        "黑暴风",
        "富驰充电宝",
        "FC30"
      ],
      "description": "10月13日原录像约1:13:00—1:16:30，白色机身、圆形屏区、黑挂绳、自带线及正面日进斗金贴纸；73分30秒BLACK FOMBO与黑蜂暴标识清楚，与用户链接商品图对应。现场大小两款分别展示，按容量选取。",
      "cautions": [
        "链接详情标型号FC30；录像未读清每台背部型号/容量铭牌，不把大小款自动视为同一SKU。",
        "网页价格隐藏，不能把59/79等历史口述作为当前售价。3C、22.5W、容量及可登机均未作独立技术核验。",
        "4380—4590秒为外观回查范围，剪辑前核对原音与具体款式，勿沿用其他商品话术。"
      ],
      "appearances": [
        {
          "recording_id": "M-e602436554dd38e0",
          "recording_name": "2026-10-13_2113_猫哥评测_7696139784422558505_20261014-034037.mp4",
          "date": "2026-10-13",
          "basis": "2026-10-15原录像外观回看，链接商品图比对",
          "windows": [
            [
              4380,
              4590
            ]
          ],
          "visual_identity": "黑蜂暴BLACK FOMBO字标，白色长圆角机身、黑色圆形屏区、黑挂绳、自带线与日进斗金贴纸同组对应",
          "timing_basis": "30秒抽帧核对回查范围；不是精确剪辑边界，前后可能有其他款式",
          "evidence": "BLACK-FOMBO-4410.jpg",
          "visual_anchors_seconds": [],
          "timing_label": "01:13:00—01:16:30",
          "timing_status": "回查时间段",
          "talk_segments": [
            {
              "start": 4355.0,
              "end": 4618.8,
              "title": "BLACK FOMBO标识充电宝",
              "aspect": "讲解内容",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-13/2026-10-13-original-e935aa00f420/Codex-product-presence-review-v2/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）"
            }
          ],
          "talk_status": "已有审校内容分段"
        }
      ],
      "evidence": "BLACK-FOMBO-4410.jpg",
      "link_override": true,
      "product_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3843901869952992943&origin_type=604&channel_id=3385503713057829&channel_type=4",
      "link_name": "【猫哥专属】3C认证可上飞机黑蜂暴富驰快充充电宝大容量20000毫安手机通用",
      "link_source": "用户指定商品链接；只读打开详情核对",
      "link_status": "推广核实正常（2026-10-26核对）；库存另核",
      "image_source": "用户补充商品链接图",
      "binding_scope": "10月13日4380—4590秒外观组；按大小和容量逐款选取",
      "appearance_match": "黑蜂暴BLACK FOMBO字标，白色长圆角机身、黑色圆形屏区、黑挂绳、自带线与日进斗金贴纸同组对应",
      "appearance_checked_at": "2026-10-15T15:17:27.081398+08:00",
      "image": "https://p26-item.ecombdimg.com/img/ecom-shop-material/png_m_f244247e95db7184cfacbf58039b3c07_sx_1274844_www1112-1112~tplv-5mmsx3fupr-resize_q:1080:1080:q90.webp",
      "link_audit": {
        "id": "U-BLACKFOMBO-FC30-3843901869952992943",
        "name": "【猫哥专属】3C认证可上飞机黑蜂暴富驰快充充电宝大容量20000毫安手机通用",
        "old_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3843901869952992943&origin_type=604&channel_id=3385503713057829&channel_type=4",
        "promotion_status": "推广核实正常",
        "page_status": "库存未于本轮重新核查",
        "source_rows": [
          {
            "name": "黑蜂暴充电宝",
            "row_id": "201",
            "text": "\t\n黑蜂暴充电宝\n未分类 · ID 3843901869952992943\n\t59\t5%\t\n5%\n\t正常\n10/26 07:00\n\t2026/10/15\t\n复制"
          }
        ],
        "checked_at": "2026-10-26",
        "source": "原商品工作台当日07:00—07:09只读结果"
      }
    },
    {
      "id": "PF-gt3-38233996",
      "name": "千幻 SHINECON × Maserati GT3 夹耳式耳机（蓝／咖色）",
      "category": "耳机",
      "aliases": [
        "玛莎GT3",
        "GT-3",
        "GT3",
        "千幻夹耳耳机"
      ],
      "description": "已关联12场：原4—5月9场，以及10/23、10/24、10/25三场新增外观对应素材。新增场次按蓝/咖色皮纹横向长圆充电仓、挂绳及夹耳结构核查；完整型号与SKU待核，未认定完整翻译功能实测。",
      "cautions": [
        "时间段为已核对锚点附近的回查窗口，不是完整产品讲解或精确剪辑边界。",
        "4/16第二段原文件暂不能解码，未计入已核对素材。5/24等日期未获得本款实物确认，不因品牌口播关联。",
        "商品页功能文案为商家描述，本次仅核对型号、品牌标识与外观；不同颜色分别选取。",
        "10/23、10/24、10/25为外观对应；完整型号、SKU及讲解起止待核，仅标已确认画面时刻，不代表完整翻译实测。"
      ],
      "appearances": [
        {
          "recording_id": "M-c2dbfe65d8b9bb21",
          "basis": "2026-10-16原录像实物抽帧核对；GT-3包装及蓝/咖色皮纹长圆仓、夹耳结构对应商品图",
          "windows": [
            [
              2020,
              2120
            ]
          ],
          "visual_anchors_seconds": [
            2040,
            2100
          ],
          "timing_label": "00:33:40—00:35:20",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-d30db7b60768e6f9",
          "basis": "2026-10-16原录像实物抽帧核对；GT-3包装及蓝/咖色皮纹长圆仓、夹耳结构对应商品图",
          "windows": [
            [
              1510,
              1670
            ]
          ],
          "visual_anchors_seconds": [
            1530,
            1650
          ],
          "timing_label": "00:25:10—00:27:50",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-27f89ecf0e45d412",
          "basis": "2026-10-16原录像实物抽帧核对；GT-3包装及蓝/咖色皮纹长圆仓、夹耳结构对应商品图",
          "windows": [
            [
              701,
              830
            ]
          ],
          "visual_anchors_seconds": [
            721,
            810
          ],
          "timing_label": "00:11:41—00:13:50",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-3d0138cc9dacc6d4",
          "basis": "2026-10-16原录像实物抽帧核对；GT-3包装及蓝/咖色皮纹长圆仓、夹耳结构对应商品图",
          "windows": [
            [
              880,
              1270
            ]
          ],
          "visual_anchors_seconds": [
            900,
            1250
          ],
          "timing_label": "00:14:40—00:21:10",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-f5607eff3095a507",
          "basis": "2026-10-16原录像实物抽帧核对；GT-3包装及蓝/咖色皮纹长圆仓、夹耳结构对应商品图",
          "windows": [
            [
              1695,
              1795
            ]
          ],
          "visual_anchors_seconds": [
            1715,
            1775
          ],
          "timing_label": "00:28:15—00:29:55",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-f14402ca6b4ce67f",
          "basis": "2026-10-16原录像实物抽帧核对；GT-3包装及蓝/咖色皮纹长圆仓、夹耳结构对应商品图",
          "windows": [
            [
              3166,
              3265
            ]
          ],
          "visual_anchors_seconds": [
            3186,
            3245
          ],
          "timing_label": "00:52:46—00:54:25",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-d7657629b32a5c8b",
          "basis": "2026-10-16原录像实物抽帧核对；GT-3包装及蓝/咖色皮纹长圆仓、夹耳结构对应商品图",
          "windows": [
            [
              4699,
              4820
            ]
          ],
          "visual_anchors_seconds": [
            4719,
            4800
          ],
          "timing_label": "01:18:19—01:20:20",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-76e6d11f42fe91fa",
          "basis": "2026-10-16原录像实物抽帧核对；GT-3包装及蓝/咖色皮纹长圆仓、夹耳结构对应商品图",
          "windows": [
            [
              3225,
              3420
            ]
          ],
          "visual_anchors_seconds": [
            3245,
            3400
          ],
          "timing_label": "00:53:45—00:57:00",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-222ce0013b8cb0e0",
          "basis": "2026-10-16原录像实物抽帧核对；GT-3包装及蓝/咖色皮纹长圆仓、夹耳结构对应商品图",
          "windows": [
            [
              3640,
              3750
            ]
          ],
          "visual_anchors_seconds": [
            3660,
            3730
          ],
          "timing_label": "01:00:40—01:02:30",
          "timing_status": "回查时间段",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-f29e3b5dff5ddeb7",
          "basis": "2026-10-26原录像画面复核：蓝/咖色皮纹横向长圆仓、挂绳及夹耳结构外观对应；完整型号与SKU待核",
          "windows": [],
          "visual_anchors_seconds": [
            1460
          ],
          "timing_label": "00:24:20（外观对应；完整起止待核）",
          "timing_status": "已确认画面时刻",
          "reference_only": true,
          "talk_segments": [],
          "talk_status": "讲解分段待核查；不代表完整翻译实测"
        },
        {
          "recording_id": "M-70fe7f961d1323cd",
          "basis": "2026-10-26原录像画面复核：蓝/咖色皮纹横向长圆仓、挂绳及夹耳结构外观对应；完整型号与SKU待核",
          "windows": [],
          "visual_anchors_seconds": [
            900
          ],
          "timing_label": "00:15:00（外观对应；完整起止待核）",
          "timing_status": "已确认画面时刻",
          "reference_only": true,
          "talk_segments": [],
          "talk_status": "讲解分段待核查；不代表完整翻译实测"
        },
        {
          "recording_id": "M-31025b756cafcdfd",
          "basis": "2026-10-26原录像画面复核：蓝/咖色皮纹横向长圆仓、挂绳及夹耳结构外观对应；完整型号与SKU待核",
          "windows": [],
          "visual_anchors_seconds": [
            6067
          ],
          "timing_label": "01:41:07（外观对应；完整起止待核）",
          "timing_status": "已确认画面时刻",
          "reference_only": true,
          "talk_segments": [],
          "talk_status": "讲解分段待核查；不代表完整翻译实测"
        }
      ],
      "evidence": "2026-10-16商品页与4/14至5/24原录像抽帧核查",
      "link_override": true,
      "product_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3823399671867506714&origin_type=604",
      "link_name": "玛莎拉蒂联名千幻GT3智能Ai同声传译高清降噪蓝牙耳机mgdsp",
      "link_source": "用户提供；2026-10-16商品页与原录像核查",
      "link_status": "推广核实正常（2026-10-26核对）；库存另核",
      "image_source": "用户补充商品链接图",
      "image": "https://p26-item.ecombdimg.com/img/ecom-shop-material/jpeg_m_7652e27617ba3a14262a1ca4a729833f_sx_552761_www800-800~tplv-5mmsx3fupr-resize_q:1080:1080:q90.webp",
      "link_audit": {
        "id": "PF-gt3-38233996",
        "name": "玛莎拉蒂联名千幻GT3智能Ai同声传译高清降噪蓝牙耳机mgdsp",
        "old_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3823399671867506714&origin_type=604",
        "promotion_status": "推广核实正常",
        "page_status": "库存未于本轮重新核查",
        "source_rows": [
          {
            "name": "玛莎GT3",
            "row_id": "187",
            "text": "\t\n玛莎GT3\n耳机 · ID 3823399671867506714\n\t139\t45%\t\n45%\n\t正常\n10/26 07:01\n\t2026/9/21\t\n复制"
          }
        ],
        "checked_at": "2026-10-26",
        "source": "原商品工作台当日07:00—07:09只读结果"
      }
    },
    {
      "id": "PF-5b7ab356",
      "name": "mentech 美碳 WATCH Xe1 运动手表（包装/页面标识）",
      "category": "手表",
      "aliases": [
        "mentech 美碳 WATCH Xe1 运动手表（包装/页面标识）"
      ],
      "description": "已核查6月3日、10月5日、10月17日第二段共3场。包装WATCH Xe1、表盘mentech及圆形螺钉表框对应；颜色、成色与套餐分别核对。当前商品为准新品／资源机。",
      "cautions": [
        "续航与传感器未独立测试",
        "代次以实物为准",
        "10月5日白盒和白色表盘均可见mentech WATCH Xe1；龙年包装、颜色、表带与套餐仍需分别核对。",
        "14天与只看时间两个月属于不同使用条件的主播说法，不承诺两个月常规续航；GPS、材质、健康与防水指标未独立测试。 主播提到屏幕亮度和不能接电话；299元等报价及实际商品选项未确认。",
        "10月5日本项实物出现已核实；本场其他内容、原音中的疑点和精确音画时码继续审核，不代表整场交付。",
        "商品页标注准新品、资源机，不能宣传全新。价格仅显示3??及券后2??，精确价格未核。",
        "日期已核查；抽帧锚点不等于剪辑边界。10月17日音轨回查00:10:34—00:29:23、00:30:03—00:31:55未对齐音画，不填为视频切点。"
      ],
      "appearances": [
        {
          "recording_id": "M-f0987366b9993294",
          "basis": "2026-10-19 日期核查：已有审校与身份帧复核",
          "windows": [],
          "visual_identity": "原片00:36:07表盘mentech与圆形螺钉外框；既有审校包装标WATCH Xe1",
          "evidence": "/Users/szx/Movies/gpt/美碳Xe1日期核查_20261019/日期核查.md",
          "visual_anchors_seconds": [
            2167
          ],
          "timing_label": "00:36:07（完整起止待核）",
          "timing_status": "已确认画面时刻",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-5913c6147cd828d0",
          "basis": "2026-10-19 日期核查：已有审校与身份帧复核",
          "windows": [],
          "visual_identity": "原片00:33:00美碳Xe1标牌、mentech外箱、圆表及黄色表带",
          "evidence": "/Users/szx/Movies/gpt/美碳Xe1日期核查_20261019/日期核查.md",
          "visual_anchors_seconds": [
            1980
          ],
          "timing_label": "00:33:00（完整起止待核）",
          "timing_status": "已确认画面时刻",
          "talk_segments": [],
          "talk_status": "讲解分段待核查"
        },
        {
          "recording_id": "M-f8a8d896fc4c146d",
          "basis": "2026-10-19 日期核查：已有审校与身份帧复核",
          "windows": [],
          "visual_identity": "第二段00:12:00白盒WATCH Xe1；00:21:00表盘mentech与螺钉外框",
          "evidence": "/Users/szx/Movies/gpt/美碳Xe1日期核查_20261019/日期核查.md",
          "visual_anchors_seconds": [
            720,
            1260
          ],
          "timing_label": "00:12:00、00:21:00（完整起止待核）",
          "timing_status": "已确认画面时刻",
          "talk_segments": [
            {
              "start": 813.58,
              "end": 816.18,
              "title": "就是它在没有连接手机的情况下",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-review-v2/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 816.18,
              "end": 818.18,
              "title": "正常常亮显示",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-review-v2/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 818.98,
              "end": 820.18,
              "title": "屏幕一直在亮着",
              "aspect": "参数与性能说明",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-review-v2/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 820.18,
              "end": 821.18,
              "title": "这个屏幕一直在亮着",
              "aspect": "参数与性能说明",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-review-v2/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 823.98,
              "end": 825.58,
              "title": "屏幕一直在亮着",
              "aspect": "参数与性能说明",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-review-v2/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1085.58,
              "end": 1087.58,
              "title": "这块屏幕它不自发光",
              "aspect": "参数与性能说明",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-review-v2/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1234.12,
              "end": 1238.0,
              "title": "它没有电话功能 但是它所有专业的运动员功能",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-review-v2/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1257.86,
              "end": 1260.04,
              "title": "办法办法为这个屏幕怎么显示不清晰",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-review-v2/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1261.24,
              "end": 1263.3,
              "title": "绝对没有你的欧蓝屏显示清晰",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-review-v2/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1372.26,
              "end": 1373.76,
              "title": "手发价格2999",
              "aspect": "价格与套餐",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-review-v2/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1490.42,
              "end": 1492.7,
              "title": "不能插烤不能插烤不能打电话",
              "aspect": "使用边界",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-review-v2/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1493.2,
              "end": 1494.16,
              "title": "不能插烤不能打电话",
              "aspect": "使用边界",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-review-v2/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1494.16,
              "end": 1495.24,
              "title": "没有支付功能",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-review-v2/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1528.94,
              "end": 1532.26,
              "title": "他这个屏幕当他没亮的时候你是触摸不了的你要把这个按键点一下",
              "aspect": "参数与性能说明",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-review-v2/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1555.34,
              "end": 1558.34,
              "title": "电池可以差不多如果你不连手机用两个月时间就是",
              "aspect": "参数与性能说明",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-review-v2/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1558.34,
              "end": 1560.86,
              "title": "这个屏幕一直在亮着可以用两个月时间",
              "aspect": "参数与性能说明",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-review-v2/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1603.12,
              "end": 1608.76,
              "title": "他来电话里有电话提醒他只是震动他没有影响你甚至他为了防水做好他的没有洋生气",
              "aspect": "使用边界",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-review-v2/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）"
            },
            {
              "start": 1642.34,
              "end": 1645.08,
              "title": "1.211.3英寸的1.3英寸的",
              "aspect": "讲解内容",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-review-v2/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1710.88,
              "end": 1713.42,
              "title": "你把零上上了啊两百九十九块钱这个",
              "aspect": "讲解内容",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-review-v2/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1864.12,
              "end": 1870.14,
              "title": "没有经济500块钱而且这个是双屏全新定位就是他的定位精度可以做到礼米机的",
              "aspect": "价格与套餐",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-review-v2/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）"
            },
            {
              "start": 1871.1,
              "end": 1875.94,
              "title": "然后续航时间两个月半反半半个月他真的你们不想买他的屏幕真的不好",
              "aspect": "参数与性能说明",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-review-v2/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 1905.66,
              "end": 1908.56,
              "title": "接不了电话接不了电话来手表接不了电话",
              "aspect": "讲解内容",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-review-v2/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            }
          ],
          "talk_status": "已有审校内容分段"
        }
      ],
      "evidence": "/Volumes/视频文件/ai分析直播内容/网站目录/catalog-20261009-oct08-nine-presences-v50/payload.json",
      "image_source": "用户商品链接主图",
      "footage_image": "product-images/PF-5b7ab356.jpg",
      "product_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3838954735503802848&origin_type=604",
      "link_name": "mentech 美碳 WATCH Xe1 运动手表（准新品／资源机）",
      "link_source": "2026-10-19 用户提供链接，商品页核对",
      "link_status": "推广核实正常（2026-10-26核对）；库存另核",
      "candidate_links": [],
      "image": "https://p26-item.ecombdimg.com/img/ecom-shop-material/jpeg_m_2152b8a131b5221eb39372fad41bb322_sx_368666_www720-720~tplv-5mmsx3fupr-resize_q:1080:1080:q90.webp",
      "verification": {
        "status": "商品链接已核对 · 准新品分款确认",
        "identity": "6月3日、10月5日、10月17日第二段共3场已核查。6月23日仅X系列线索、具体型号未确认，不加入。",
        "checked_at": "2026-10-19",
        "basis": "商品页面、既有素材核查记录及实物截图；性能未独立验证。",
        "name": "mentech 美碳 WATCH Xe1 运动手表（包装/页面标识）"
      },
      "link_audit": {
        "id": "PF-5b7ab356",
        "name": "mentech 美碳 WATCH Xe1 运动手表（准新品／资源机）",
        "old_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3838954735503802848&origin_type=604",
        "promotion_status": "推广核实正常",
        "page_status": "库存未于本轮重新核查",
        "source_rows": [
          {
            "name": "美碳 WATCH Xe1 运动手表（准新品）",
            "row_id": "205",
            "text": "\t\n美碳 WATCH Xe1 运动手表（准新品）\n手表 · ID 3838954735503802848\n\t299.90\t20%\t\n20%\n\t正常\n10/26 07:00\n\t2026/10/18\t\n复制"
          }
        ],
        "checked_at": "2026-10-26",
        "source": "原商品工作台当日07:00—07:09只读结果"
      }
    },
    {
      "id": "PF-09d1bc1f",
      "name": "灰色双Type-C智能断电数据线（当前商品图240W）",
      "category": "充电与手机配件",
      "aliases": [
        "自动断电数据线",
        "A1",
        "2米",
        "双C",
        "3848241311635341798"
      ],
      "product_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3848241311635341798&origin_type=604",
      "link_name": "2026新款智能自动断电快充数据线适用于安卓系列手机2米充电线",
      "link_source": "2026-10-24实时商品页标题与主图核对",
      "link_status": "推广核实正常（2026-10-26核对）；库存另核",
      "link_override": true,
      "candidate_links": [],
      "image": "https://p26-item.ecombdimg.com/img/ecom-shop-material/jpeg_m_d4c28b0aac96b8a266fc8f3814d62134_sx_170537_www1280-1280~tplv-5mmsx3fupr-resize:1280:1280.jpeg",
      "image_source": "2026-10-24商品页图片",
      "description": "按外观关联5场：10月14日、15日、16日第二段、17日第二段及22日。10月22日12:00双Type-C接头、电源图形和灰色软线近景已核对。当前商品主图240W，但22日当场有100W/240W冲突及暂停购买说明，具体SKU与实际功率仍待核。",
      "cautions": [
        "2026-10-20曾见100W商品图；2026-10-24当前主图为240W，不把历史页面差异当作实际功率测量。",
        "仅按外观关联，完整型号、长度及具体SKU未逐场核实。",
        "自动断电、充满灭灯、护电池和240W为商品宣传或口述，未独立测试完整充满断电过程。",
        "页面当前显示已抢光，价格未完整显示；不能据旧录像报价判断现价。",
        "时间段为回查范围，非精确剪辑切点；不并入多接头或其他颜色结构数据线。",
        "10月22日已有审校记载：主播发现链接100W与口播240W冲突，要求暂不拍并表示次日问清；不得剪去该说明而当成功率已确认。"
      ],
      "appearances": [
        {
          "recording_id": "M-614d1c8867a91640",
          "basis": "【时间段】00:05:00—00:07:30。【核查】仅已抽帧确认的定位范围，完整展示起止尚待核；灰色线身、金属双C及指示接头外观参考，2026-10-24商品主图已为240W；按外观对应，具体SKU待核。",
          "windows": [
            [
              300,
              450
            ]
          ],
          "visual_anchors_seconds": [
            450
          ],
          "reference_only": true,
          "timing_label": "00:05:00—00:07:30",
          "timing_status": "回查时间段",
          "talk_segments": [
            {
              "start": 314.0,
              "end": 315.0,
              "title": "现在有两米长",
              "aspect": "接口、长度与兼容",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-14/2026-10-14-original-ef1d3a05db8d/Codex-first-three-presence-review-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 325.0,
              "end": 326.0,
              "title": "240瓦的",
              "aspect": "参数与性能说明",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-14/2026-10-14-original-ef1d3a05db8d/Codex-first-three-presence-review-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 334.0,
              "end": 335.0,
              "title": "这里一个灯",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-14/2026-10-14-original-ef1d3a05db8d/Codex-first-three-presence-review-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            }
          ],
          "talk_status": "已有审校内容分段"
        },
        {
          "recording_id": "M-3185ce0fb33e42f9",
          "basis": "【时间段】00:04:50—00:11:08。【核查】音轨回查范围，已用原帧核对外观；灰色线身、金属双C及指示接头外观参考，2026-10-24商品主图已为240W；按外观对应，具体SKU待核。",
          "windows": [
            [
              290,
              668
            ]
          ],
          "visual_anchors_seconds": [
            600
          ],
          "reference_only": true,
          "timing_label": "00:04:50—00:11:08",
          "timing_status": "回查时间段",
          "talk_segments": [
            {
              "start": 306.8,
              "end": 307.84,
              "title": "因為有兩米的",
              "aspect": "接口、长度与兼容",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-15/2026-10-15-original-5658de74010a/Codex-first-two-review-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 332.08,
              "end": 334.12,
              "title": "它裡面有個芯片會自動給你手機",
              "aspect": "参数与性能说明",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-15/2026-10-15-original-5658de74010a/Codex-first-two-review-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 334.28,
              "end": 335.4,
              "title": "完全斷電",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-15/2026-10-15-original-5658de74010a/Codex-first-two-review-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 380.56,
              "end": 381.96,
              "title": "充到100%這個燈就滅了",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-15/2026-10-15-original-5658de74010a/Codex-first-two-review-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 426.52,
              "end": 429.36,
              "title": "一碼可惜的芯片支持PD快充240W",
              "aspect": "参数与性能说明",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-15/2026-10-15-original-5658de74010a/Codex-first-two-review-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 435.92,
              "end": 437.08,
              "title": "支持CarPlay",
              "aspect": "接口、长度与兼容",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-15/2026-10-15-original-5658de74010a/Codex-first-two-review-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 511.36,
              "end": 513.44,
              "title": "它還有一種是簡配版的100W的",
              "aspect": "讲解内容",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-15/2026-10-15-original-5658de74010a/Codex-first-two-review-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 516.0,
              "end": 517.6,
              "title": "最滿配的240W",
              "aspect": "参数与性能说明",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-15/2026-10-15-original-5658de74010a/Codex-first-two-review-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            }
          ],
          "talk_status": "已有审校内容分段"
        },
        {
          "recording_id": "M-8dec7c28434dfd5b",
          "basis": "【时间段】00:04:24—00:08:52、00:09:48—00:10:40、00:11:21—00:11:57、00:12:51—00:13:44。【核查】音轨回查范围，已用原帧核对外观；灰色线身、金属双C及指示接头外观参考，2026-10-24商品主图已为240W；按外观对应，具体SKU待核。",
          "windows": [
            [
              264,
              532
            ],
            [
              588,
              640
            ],
            [
              681,
              717
            ],
            [
              771,
              824
            ]
          ],
          "visual_anchors_seconds": [
            400
          ],
          "reference_only": true,
          "timing_label": "00:04:24—00:08:52、00:09:48—00:10:40、00:11:21—00:11:57、00:12:51—00:13:44",
          "timing_status": "回查时间段",
          "talk_segments": [
            {
              "start": 305.2,
              "end": 306.2,
              "title": "两米",
              "aspect": "接口、长度与兼容",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-16/2026-10-16-original-97ecca74f920/Codex-product-presence-review-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 310.2,
              "end": 311.2,
              "title": "这个是1米5",
              "aspect": "接口、长度与兼容",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-16/2026-10-16-original-97ecca74f920/Codex-product-presence-review-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 346.2,
              "end": 347.2,
              "title": "首先是PD功率",
              "aspect": "参数与性能说明",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-16/2026-10-16-original-97ecca74f920/Codex-product-presence-review-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 348.2,
              "end": 349.2,
              "title": "最快240块",
              "aspect": "价格与套餐",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-16/2026-10-16-original-97ecca74f920/Codex-product-presence-review-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 354.2,
              "end": 356.2,
              "title": "保护自动断电",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-16/2026-10-16-original-97ecca74f920/Codex-product-presence-review-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 431.2,
              "end": 432.2,
              "title": "2米的",
              "aspect": "接口、长度与兼容",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-16/2026-10-16-original-97ecca74f920/Codex-product-presence-review-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 453.2,
              "end": 454.2,
              "title": "可以支持CarPlay",
              "aspect": "接口、长度与兼容",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-16/2026-10-16-original-97ecca74f920/Codex-product-presence-review-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 483.2,
              "end": 484.2,
              "title": "12块9",
              "aspect": "价格与套餐",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-16/2026-10-16-original-97ecca74f920/Codex-product-presence-review-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 526.2,
              "end": 527.2,
              "title": "这是C口的",
              "aspect": "接口、长度与兼容",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-16/2026-10-16-original-97ecca74f920/Codex-product-presence-review-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 527.2,
              "end": 528.2,
              "title": "双C的",
              "aspect": "接口、长度与兼容",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-16/2026-10-16-original-97ecca74f920/Codex-product-presence-review-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 821.2,
              "end": 822.2,
              "title": "这个是断电数线",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-16/2026-10-16-original-97ecca74f920/Codex-product-presence-review-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            }
          ],
          "talk_status": "已有审校内容分段"
        },
        {
          "recording_id": "M-f8a8d896fc4c146d",
          "basis": "【时间段】00:02:55—00:07:06、00:09:37—00:10:30。【核查】音轨回查范围，已用原帧核对外观；灰色线身、金属双C及指示接头外观参考，2026-10-24商品主图已为240W；按外观对应，具体SKU待核。",
          "windows": [
            [
              175,
              426
            ],
            [
              577,
              630
            ]
          ],
          "visual_anchors_seconds": [
            580
          ],
          "reference_only": true,
          "timing_label": "00:02:55—00:07:06、00:09:37—00:10:30",
          "timing_status": "回查时间段",
          "talk_segments": [
            {
              "start": 202.58,
              "end": 203.78,
              "title": "TPE的那个",
              "aspect": "外观与配件",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-partial-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 220.58,
              "end": 221.58,
              "title": "一个是1mark芯片",
              "aspect": "参数与性能说明",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-partial-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 221.98,
              "end": 224.58,
              "title": "第二个是里面有个自动断电芯片",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-partial-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 239.98,
              "end": 240.98,
              "title": "它上面有一个灯",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-partial-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 251.58,
              "end": 252.78,
              "title": "通到百分之百之后",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-partial-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 253.58,
              "end": 254.58,
              "title": "就把这里垫断掉",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-partial-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 271.58,
              "end": 273.18,
              "title": "然后可以支持数据传出",
              "aspect": "接口、长度与兼容",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-partial-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 273.18,
              "end": 275.18,
              "title": "可以支持 CarPlay Car Live",
              "aspect": "接口、长度与兼容",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-partial-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 280.58,
              "end": 281.98,
              "title": "线的街头全部是全金属的",
              "aspect": "外观与配件",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-partial-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 302.98,
              "end": 304.58,
              "title": "12块9毛钱上这",
              "aspect": "价格与套餐",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-partial-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 334.38,
              "end": 336.78,
              "title": "240瓦的是PD协议",
              "aspect": "参数与性能说明",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-partial-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 339.38,
              "end": 340.98,
              "title": "最高功率就是240瓦",
              "aspect": "参数与性能说明",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-partial-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 347.18,
              "end": 349.18,
              "title": "这个我们是12块9瓦钱",
              "aspect": "价格与套餐",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-partial-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 392.58,
              "end": 395.38,
              "title": "全自动断电数据12块9瓦钱",
              "aspect": "价格与套餐",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-partial-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 400.18,
              "end": 401.78,
              "title": "这线的材质可以2米的",
              "aspect": "接口、长度与兼容",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-partial-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 597.98,
              "end": 599.18,
              "title": "它只能是C口的",
              "aspect": "接口、长度与兼容",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-partial-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 608.58,
              "end": 610.38,
              "title": "因为充满了就垫断了",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-partial-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 610.38,
              "end": 612.38,
              "title": "用这条线充满垫断了",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-partial-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            },
            {
              "start": 621.38,
              "end": 622.78,
              "title": "线是充满断垫",
              "aspect": "功能与操作",
              "evidence": "/Volumes/视频文件/ai分析直播内容/持续分析/内容审校/2026-10-17/2026-10-17-original-5d76cdea93fa/Codex-product-presence-partial-v1/segments.json",
              "clock": "原音转写回查时间（音画同步未精校）",
              "status": "原文摘录定位，非该方面完整起止"
            }
          ],
          "talk_status": "已有审校内容分段"
        },
        {
          "recording_id": "M-fca55ffd2fca7cae",
          "windows": [],
          "visual_anchors_seconds": [
            720
          ],
          "timing_label": "00:12:00（接头近景；完整起止待核）",
          "timing_status": "已确认画面时刻",
          "reference_only": true,
          "basis": "2026-10-24直接读取原录像12:00，灰色线、金属双Type-C接头及电源图形指示区清楚，与链接图外观对应。已有音轨回查09:58—14:55尚未精校音画，未作为视频时间段。",
          "visual_identity": "双C金属壳、电源图形及灰色软线外观对应，具体SKU待核。",
          "talk_segments": [],
          "talk_status": "讲解分段待核；须保留规格冲突说明"
        }
      ],
      "verification": {
        "status": "5场外观关联；10月22日已新增",
        "checked_at": "2026-10-24",
        "identity": "按外观关联5场：10月14日、15日、16日第二段、17日第二段及22日。10月22日12:00双Type-C接头、电源图形和灰色软线近景已核对。当前商品主图240W，但22日当场有100W/240W冲突及暂停购买说明，具体SKU与实际功率仍待核。",
        "basis": "实时商品页主图及4场原录像抽帧，10月16日00:06:40可读接头240W及电源图形。",
        "evidence_folder": "/Users/szx/Movies/gpt/断电线新增素材_20261024",
        "name": "灰色双Type-C智能断电数据线（当前商品图240W）"
      },
      "link_audit": {
        "id": "PF-09d1bc1f",
        "name": "2026新款智能自动断电快充数据线适用于安卓系列手机2米充电线",
        "old_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3848241311635341798&origin_type=604",
        "promotion_status": "推广核实正常",
        "page_status": "库存未于本轮重新核查",
        "source_rows": [
          {
            "name": "断电快充数据线",
            "row_id": "200",
            "text": "\t\n断电快充数据线\n未分类 · ID 3848241311635341798\n\t12.8\t40%\t\n40%\n\t正常\n10/26 07:00\n\t2026/10/15\t\n复制"
          }
        ],
        "checked_at": "2026-10-26",
        "source": "原商品工作台当日07:00—07:09只读结果"
      }
    },
    {
      "id": "PF-0b6e42b4",
      "name": "礼米40W AVS氮化镓充电头（IP17-AVS40W-GAN）",
      "category": "充电与手机配件",
      "aliases": [
        "礼米",
        "AVS",
        "40W",
        "IP17-AVS40W-GAN",
        "3849128254669717583"
      ],
      "description": "已核查10月16日第一段、第二段及10月17日第二段共3场。礼米包装、40W动态/最高60W字样、白色单C口及折叠插脚外观对应；各场完整型号与销售选项仍需分别确认。",
      "product_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3849128254669717583&origin_type=604&channel_id=3386375462138917&channel_type=4",
      "link_name": "礼米40W AVS动态快充头（氮化镓）",
      "link_source": "用户提供，2026-10-21实时商品页与原片核对",
      "link_status": "推广核实正常（2026-10-26核对）；库存另核",
      "link_override": true,
      "candidate_links": [],
      "image": "https://p3-item.ecombdimg.com/img/ecom-shop-material/png_m_c8009d4db314c11d38785cf677d8b53e_sx_1957355_www1492-1492~tplv-5mmsx3fupr-resize:1492:1492.jpeg",
      "image_source": "2026-10-21实时商品页原图",
      "appearances": [
        {
          "recording_id": "M-573371778fd05cbe",
          "windows": [
            [
              1976,
              2527
            ]
          ],
          "basis": "第一段：00:40:30包装可读礼米、40W动态适配器（最高60W）及IP17-AVS40型号前缀。",
          "visual_anchors_seconds": [
            2430
          ],
          "timing_status": "回查时间段",
          "timing_label": "00:32:56—00:42:07",
          "talk_status": "讲解分段待核查",
          "talk_segments": []
        },
        {
          "recording_id": "M-8dec7c28434dfd5b",
          "windows": [
            [
              532,
              817
            ]
          ],
          "basis": "第二段：00:09:20白色折叠插脚、单C口和礼米图形标识；具体完整型号待核。",
          "visual_anchors_seconds": [
            560
          ],
          "timing_status": "回查时间段",
          "timing_label": "00:08:52—00:13:37",
          "talk_status": "讲解分段待核查",
          "talk_segments": []
        },
        {
          "recording_id": "M-f8a8d896fc4c146d",
          "windows": [
            [
              426,
              634
            ]
          ],
          "basis": "第二段：00:08:20包装清楚显示礼米及40W Dynamic AVS power adapter with 60W Max，完整型号未展示。",
          "visual_anchors_seconds": [
            500
          ],
          "timing_status": "回查时间段",
          "timing_label": "00:07:06—00:10:34",
          "talk_status": "讲解分段待核查",
          "talk_segments": []
        }
      ],
      "cautions": [
        "商品页品牌礼米、型号IP17-AVS40W-GAN；录像完整型号未逐场读清，不把相似外观当作完全相同SKU。",
        "40W/最高60W是页面与包装标称，非持续60W负载实测；AVS、协议、氮化镓及安全认证未独立测试。",
        "仅充电头，不能默认随附数据线。与黑面数显充电头及其他旧40W款分开。",
        "时间段取自已有音轨回查分析，辅以原录像身份帧；非精确剪辑起止。"
      ],
      "verification": {
        "name": "礼米40W AVS氮化镓充电头",
        "checked_at": "2026-10-21",
        "status": "3场品牌/包装与外观对应",
        "identity": "页面礼米/IP17-AVS40W-GAN；原录像见礼米包装、40W动态/最高60W及白色单C折叠头。完整型号逐场待核。",
        "basis": "实时商品页与10月16日第一段2430秒、第二段560秒、10月17日第二段500秒原片抽帧。",
        "evidence_folder": "/Users/szx/Movies/gpt/礼米AVS充电头添加_20261021/证据"
      },
      "link_audit": {
        "id": "PF-0b6e42b4",
        "name": "礼米40W AVS动态快充头（氮化镓）",
        "old_url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3849128254669717583&origin_type=604&channel_id=3386375462138917&channel_type=4",
        "promotion_status": "推广核实正常",
        "page_status": "库存未于本轮重新核查",
        "source_rows": [
          {
            "name": "苹果充电头40w氮化镓",
            "row_id": "207",
            "text": "\t\n苹果充电头40w氮化镓\n未分类 · ID 3849128254669717583\n\t19.9\t20%\t\n20%\n\t正常\n10/26 07:00\n\t2026/10/19\t\n复制"
          }
        ],
        "checked_at": "2026-10-26",
        "source": "原商品工作台当日07:00—07:09只读结果"
      }
    }
  ],
  "recordings": [
    {
      "id": "M-e602436554dd38e0",
      "name": "2026-10-13_2113_猫哥评测_7696139784422558505_20261014-034037.mp4",
      "path": "2026-10-13_2113_猫哥评测_7696139784422558505_20261014-034037.mp4",
      "relative_path": "2026-10-13_2113_猫哥评测_7696139784422558505_20261014-034037.mp4",
      "date": "2026-10-13",
      "kind": "原始回放",
      "bytes": 2137752903,
      "analysis": [
        {
          "name": "黑蜂暴 FC30 自带双线充电宝（容量分款）",
          "category": "充电与手机配件",
          "windows": [
            [
              4380,
              4590
            ]
          ],
          "description": "黑蜂暴BLACK FOMBO字标，白色长圆角机身、黑色圆形屏区、黑挂绳、自带线与日进斗金贴纸同组对应",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "U-BLACKFOMBO-FC30-3843901869952992943"
      ],
      "status": "已有外观复核记录",
      "duration": 6658.68,
      "note": ""
    },
    {
      "id": "M-2719dd72f6f430af",
      "name": "2026-10-11_2054_猫哥评测_7695392716686904106_20261012-033743.mp4",
      "path": "2026-10-11_2054_猫哥评测_7695392716686904106_20261012-033743.mp4",
      "relative_path": "2026-10-11_2054_猫哥评测_7695392716686904106_20261012-033743.mp4",
      "date": "2026-10-11",
      "kind": "原始回放",
      "bytes": 2023323662,
      "analysis": [
        {
          "name": "DOSS 黑白充电仓耳机（型号待核）",
          "category": "耳机",
          "windows": [
            [
              5706.5,
              6267.2
            ]
          ],
          "description": "2026-10-13 商品页与原录像既有抽帧逐图外观核对",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "PF-5af28f8d"
      ],
      "status": "已有外观复核记录",
      "note": ""
    },
    {
      "id": "M-9b1e50632c1bdde9",
      "name": "2026-10-10_2037_猫哥评测_7695017447367445289_20261011-031336.mp4",
      "path": "2026-10-10_2037_猫哥评测_7695017447367445289_20261011-031336.mp4",
      "relative_path": "2026-10-10_2037_猫哥评测_7695017447367445289_20261011-031336.mp4",
      "date": "2026-10-10",
      "kind": "原始回放",
      "bytes": 1595666894,
      "analysis": [
        {
          "name": "DOSS 黑白充电仓耳机（型号待核）",
          "category": "耳机",
          "windows": [
            [
              407.1,
              1654.4
            ]
          ],
          "description": "2026-10-13 商品页与原录像既有抽帧逐图外观核对",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "PF-5af28f8d"
      ],
      "status": "已有外观复核记录",
      "note": ""
    },
    {
      "id": "M-86812a16b84ea2cb",
      "name": "2026-10-08_2101_猫哥评测_7694281328392522539_20261009-035500.mp4",
      "path": "2026-10-08_2101_猫哥评测_7694281328392522539_20261009-035500.mp4",
      "relative_path": "2026-10-08_2101_猫哥评测_7694281328392522539_20261009-035500.mp4",
      "date": "2026-10-08",
      "kind": "原始回放",
      "bytes": 2094863597,
      "analysis": [
        {
          "name": "华为 Pura 80 Pro（12GB＋512GB／1TB需分款）",
          "category": "手机",
          "windows": [
            [
              6290.0,
              6648.0
            ]
          ],
          "description": "圆角三角相机岛、三圆镜头不等大，配合HUAWEI Pura系列白盒核对；同场基础款/Pro/Pro+与容量不能只看背面确定。",
          "evidence": "已核对的素材时间点"
        },
        {
          "name": "玛莎拉蒂标识智能手表",
          "category": "手表",
          "windows": [
            [
              234.0,
              881.5
            ]
          ],
          "description": "黑色圆形智能表体、蓝/红硅胶表带、深蓝三叉戟/Maserati标识礼盒及菜单演示；机械指针款另分。",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "PF-24538be1",
        "PF-5ac5fd9a",
        "PF-d43b70e1"
      ],
      "status": "已有外观复核记录",
      "note": ""
    },
    {
      "id": "M-aa5b92644f8170bb",
      "name": "2026-10-07_2059_猫哥评测_7693909674034531108_20261008-031650.mp4",
      "path": "2026-10-07_2059_猫哥评测_7693909674034531108_20261008-031650.mp4",
      "relative_path": "2026-10-07_2059_猫哥评测_7693909674034531108_20261008-031650.mp4",
      "date": "2026-10-07",
      "kind": "原始回放",
      "bytes": 2199859893,
      "analysis": [
        {
          "name": "DOSS 黑白充电仓耳机（型号待核）",
          "category": "耳机",
          "windows": [
            [
              3630,
              4290
            ]
          ],
          "description": "2026-10-12 外观复核：外观同组；型号配置逐场核对；已有分析 / 切片方案",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "PF-5af28f8d",
        "PF-d43b70e1"
      ],
      "status": "已有外观复核记录",
      "note": ""
    },
    {
      "id": "M-1c674f0464fcde0a",
      "name": "2026.10.4.mp4",
      "path": "2026.10.4.mp4",
      "relative_path": "2026.10.4.mp4",
      "date": "2026-10-04",
      "kind": "原始回放",
      "bytes": 1472128478,
      "analysis": [
        {
          "name": "华为 Pura 80 Pro（12GB＋512GB／1TB需分款）",
          "category": "手机",
          "windows": [
            [
              3150,
              4050
            ]
          ],
          "description": "圆角三角相机岛、三圆镜头不等大，配合HUAWEI Pura系列白盒核对；同场基础款/Pro/Pro+与容量不能只看背面确定。",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "PF-24538be1"
      ],
      "status": "已有外观复核记录",
      "note": ""
    },
    {
      "id": "M-0a936d777127e3ec",
      "name": "2026.10.3.mp4",
      "path": "2026.10.3.mp4",
      "relative_path": "2026.10.3.mp4",
      "date": "2026-10-03",
      "kind": "原始回放",
      "bytes": 1351788641,
      "analysis": [
        {
          "name": "华为 Pura 80 Pro（12GB＋512GB／1TB需分款）",
          "category": "手机",
          "windows": [
            [
              1350,
              2310
            ]
          ],
          "description": "圆角三角相机岛、三圆镜头不等大，配合HUAWEI Pura系列白盒核对；同场基础款/Pro/Pro+与容量不能只看背面确定。",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "PF-24538be1"
      ],
      "status": "已有外观复核记录",
      "note": ""
    },
    {
      "id": "M-c9d1cc58905bf21e",
      "name": "2026.10.1.mp4",
      "path": "2026.10.1.mp4",
      "relative_path": "2026.10.1.mp4",
      "date": "2026-10-01",
      "kind": "原始回放",
      "bytes": 1352255908,
      "analysis": [
        {
          "name": "AMOI 夏新往复式剃须刀（RAZOR 礼盒，型号待核）",
          "category": "个护与家用",
          "windows": [
            [
              4530,
              4855.55
            ]
          ],
          "description": "2026-10-12 原素材外观复核 · 回查窗口",
          "evidence": "已核对的素材时间点"
        },
        {
          "name": "淘丁堡H8系列圆屏智能手表（H8 P／H8 Pro）",
          "category": "手表",
          "windows": [
            [
              1890,
              3450
            ]
          ],
          "description": "2026-10-12 外观复核：外观同组；型号配置逐场核对；已有产品目录",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "A-6f11746d6c5ab899",
        "PF-4649776d"
      ],
      "status": "已有外观复核记录",
      "note": ""
    },
    {
      "id": "M-f319369b146d11f0",
      "name": "2026.9.29.mp4",
      "path": "2026.9.29.mp4",
      "relative_path": "2026.9.29.mp4",
      "date": "2026-09-29",
      "kind": "原始回放",
      "bytes": 1651576288,
      "analysis": [
        {
          "name": "淘丁堡H8系列圆屏智能手表（H8 P／H8 Pro）",
          "category": "手表",
          "windows": [
            [
              2250,
              3510
            ]
          ],
          "description": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "A-6f11746d6c5ab899"
      ],
      "status": "已有外观复核记录",
      "note": ""
    },
    {
      "id": "M-8f069728a48d9a84",
      "name": "2026.9.27.mp4",
      "path": "2026.9.27.mp4",
      "relative_path": "2026.9.27.mp4",
      "date": "2026-09-27",
      "kind": "原始回放",
      "bytes": 1482858426,
      "analysis": [
        {
          "name": "AMOI 夏新往复式剃须刀（RAZOR 礼盒，型号待核）",
          "category": "个护与家用",
          "windows": [
            [
              660,
              990
            ]
          ],
          "description": "2026-10-12 原素材外观复核 · 回查窗口",
          "evidence": "已核对的素材时间点"
        },
        {
          "name": "淘丁堡H8系列圆屏智能手表（H8 P／H8 Pro）",
          "category": "手表",
          "windows": [
            [
              2970,
              4530
            ]
          ],
          "description": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "PF-4649776d",
        "A-6f11746d6c5ab899"
      ],
      "status": "已有外观复核记录",
      "note": ""
    },
    {
      "id": "M-9a41db0033816128",
      "name": "2026.9.26.mp4",
      "path": "2026.9.26.mp4",
      "relative_path": "2026.9.26.mp4",
      "date": "2026-09-26",
      "kind": "原始回放",
      "bytes": 1403754489,
      "analysis": [
        {
          "name": "AMOI 夏新往复式剃须刀（RAZOR 礼盒，型号待核）",
          "category": "个护与家用",
          "windows": [
            [
              750,
              1080
            ]
          ],
          "description": "2026-10-12 原素材外观复核 · 回查窗口",
          "evidence": "已核对的素材时间点"
        },
        {
          "name": "淘丁堡H8系列圆屏智能手表（H8 P／H8 Pro）",
          "category": "手表",
          "windows": [
            [
              2250,
              3450
            ]
          ],
          "description": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "PF-4649776d",
        "A-6f11746d6c5ab899"
      ],
      "status": "已有外观复核记录",
      "note": ""
    },
    {
      "id": "M-b7e88e085124523e",
      "name": "2026.9.26-2.mp4",
      "path": "2026.9.26-2.mp4",
      "relative_path": "2026.9.26-2.mp4",
      "date": "2026-09-26",
      "kind": "原始回放",
      "bytes": 853283319,
      "analysis": [
        {
          "name": "华为 Pura 80 Pro（12GB＋512GB／1TB需分款）",
          "category": "手机",
          "windows": [
            [
              1350,
              2310
            ]
          ],
          "description": "圆角三角相机岛、三圆镜头不等大，配合HUAWEI Pura系列白盒核对；同场基础款/Pro/Pro+与容量不能只看背面确定。",
          "evidence": "已核对的素材时间点"
        },
        {
          "name": "DOSS 黑白充电仓耳机（型号待核）",
          "category": "耳机",
          "windows": [
            [
              0,
              1410
            ]
          ],
          "description": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "PF-24538be1",
        "PF-5af28f8d"
      ],
      "status": "已有外观复核记录",
      "note": ""
    },
    {
      "id": "M-2ce4ffbb95b618c1",
      "name": "2026.9.24.mp4",
      "path": "2026.9.24.mp4",
      "relative_path": "2026.9.24.mp4",
      "date": "2026-09-24",
      "kind": "原始回放",
      "bytes": 870157809,
      "analysis": [
        {
          "name": "DOSS 黑白充电仓耳机（型号待核）",
          "category": "耳机",
          "windows": [
            [
              150,
              1290
            ]
          ],
          "description": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "evidence": "已核对的素材时间点"
        },
        {
          "name": "得力多面插座转换器（型号待核）",
          "category": "充电与手机配件",
          "windows": [
            [
              330,
              420
            ]
          ],
          "description": "圆角方块多面插孔转换器、背面固定三脚插头与侧面USB口；蓝灰/粉/绿配色分别核对，额定参数以铭牌为准。",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "PF-5af28f8d",
        "PF-98c55e65"
      ],
      "status": "已有外观复核记录",
      "note": ""
    },
    {
      "id": "M-6c9e1bd9ccb966f3",
      "name": "2026.9.24-2.mp4",
      "path": "2026.9.24-2.mp4",
      "relative_path": "2026.9.24-2.mp4",
      "date": "2026-09-24",
      "kind": "原始回放",
      "bytes": 706810627,
      "analysis": [
        {
          "name": "AMOI 夏新往复式剃须刀（RAZOR 礼盒，型号待核）",
          "category": "个护与家用",
          "windows": [
            [
              570,
              870
            ]
          ],
          "description": "2026-10-12 原素材外观复核 · 回查窗口",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "PF-4649776d"
      ],
      "status": "已有外观复核记录",
      "note": ""
    },
    {
      "id": "M-6b992df647c3735f",
      "name": "2026.9.23.mp4",
      "path": "2026.9.23.mp4",
      "relative_path": "2026.9.23.mp4",
      "date": "2026-09-23",
      "kind": "原始回放",
      "bytes": 1854205646,
      "analysis": [
        {
          "name": "华为 Pura 80 Pro（12GB＋512GB／1TB需分款）",
          "category": "手机",
          "windows": [
            [
              2070,
              2550
            ]
          ],
          "description": "圆角三角相机岛、三圆镜头不等大，配合HUAWEI Pura系列白盒核对；同场基础款/Pro/Pro+与容量不能只看背面确定。",
          "evidence": "已核对的素材时间点"
        },
        {
          "name": "AMOI 夏新往复式剃须刀（RAZOR 礼盒，型号待核）",
          "category": "个护与家用",
          "windows": [
            [
              4170,
              4590
            ]
          ],
          "description": "2026-10-12 原素材外观复核 · 回查窗口",
          "evidence": "已核对的素材时间点"
        },
        {
          "name": "DOSS 黑白充电仓耳机（型号待核）",
          "category": "耳机",
          "windows": [
            [
              630,
              1410
            ]
          ],
          "description": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "evidence": "已核对的素材时间点"
        },
        {
          "name": "淘丁堡H8系列圆屏智能手表（H8 P／H8 Pro）",
          "category": "手表",
          "windows": [
            [
              2490,
              4110
            ]
          ],
          "description": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "PF-4649776d",
        "PF-5af28f8d",
        "PF-24538be1",
        "A-6f11746d6c5ab899"
      ],
      "status": "已有外观复核记录",
      "note": ""
    },
    {
      "id": "M-6cd07e09b524f6e0",
      "name": "2026.9.22.mp4",
      "path": "2026.9.22.mp4",
      "relative_path": "2026.9.22.mp4",
      "date": "2026-09-22",
      "kind": "原始回放",
      "bytes": 1172637452,
      "analysis": [
        {
          "name": "华为 Pura 80 Pro（12GB＋512GB／1TB需分款）",
          "category": "手机",
          "windows": [
            [
              1350,
              1830
            ]
          ],
          "description": "圆角三角相机岛、三圆镜头不等大，配合HUAWEI Pura系列白盒核对；同场基础款/Pro/Pro+与容量不能只看背面确定。",
          "evidence": "已核对的素材时间点"
        },
        {
          "name": "DOSS 黑白充电仓耳机（型号待核）",
          "category": "耳机",
          "windows": [
            [
              270,
              1470
            ]
          ],
          "description": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "evidence": "已核对的素材时间点"
        },
        {
          "name": "得力多面插座转换器（型号待核）",
          "category": "充电与手机配件",
          "windows": [
            [
              270,
              630
            ]
          ],
          "description": "圆角方块多面插孔转换器、背面固定三脚插头与侧面USB口；蓝灰/粉/绿配色分别核对，额定参数以铭牌为准。",
          "evidence": "已核对的素材时间点"
        },
        {
          "name": "淘丁堡H8系列圆屏智能手表（H8 P／H8 Pro）",
          "category": "手表",
          "windows": [
            [
              1830,
              3450
            ]
          ],
          "description": "2026-10-12 外观复核：外观同组；型号配置逐场核对；已有产品目录",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "A-6f11746d6c5ab899",
        "PF-98c55e65",
        "PF-24538be1",
        "PF-5af28f8d"
      ],
      "status": "已有外观复核记录",
      "note": ""
    },
    {
      "id": "M-68f069c180f0ad3e",
      "name": "2026.9.21.mp4",
      "path": "2026.9.21.mp4",
      "relative_path": "2026.9.21.mp4",
      "date": "2026-09-21",
      "kind": "原始回放",
      "bytes": 1564348816,
      "analysis": [
        {
          "name": "往复式剃须刀（其他／型号未明）",
          "category": "个护与家用",
          "windows": [
            [
              810,
              1350
            ]
          ],
          "description": "亮银色长柄、横向多刀网刀头、黑色礼盒，部分场次可见T9标识；与夏新细柄菱纹款及MS19粗柄款区分。",
          "evidence": "已核对的素材时间点"
        },
        {
          "name": "淘丁堡H8系列圆屏智能手表（H8 P／H8 Pro）",
          "category": "手表",
          "windows": [
            [
              2370,
              4830
            ]
          ],
          "description": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "PF-630d3f91",
        "A-6f11746d6c5ab899"
      ],
      "status": "已有外观复核记录",
      "note": ""
    },
    {
      "id": "M-77f975c5c38e5ee4",
      "name": "2026.9.20.MP4",
      "path": "2026.9.20.MP4",
      "relative_path": "2026.9.20.MP4",
      "date": "2026-09-20",
      "kind": "原始回放",
      "bytes": 1339160672,
      "analysis": [
        {
          "name": "华为 Pura 80 Pro（12GB＋512GB／1TB需分款）",
          "category": "手机",
          "windows": [
            [
              870,
              1770
            ]
          ],
          "description": "圆角三角相机岛、三圆镜头不等大，配合HUAWEI Pura系列白盒核对；同场基础款/Pro/Pro+与容量不能只看背面确定。",
          "evidence": "已核对的素材时间点"
        },
        {
          "name": "往复式剃须刀（其他／型号未明）",
          "category": "个护与家用",
          "windows": [
            [
              450,
              870
            ]
          ],
          "description": "亮银色长柄、横向多刀网刀头、黑色礼盒，部分场次可见T9标识；与夏新细柄菱纹款及MS19粗柄款区分。",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "PF-24538be1",
        "PF-630d3f91"
      ],
      "status": "已有外观复核记录",
      "note": ""
    },
    {
      "id": "M-9159a46bc5731110",
      "name": "2026.9.20.-1.MP4",
      "path": "2026.9.20.-1.MP4",
      "relative_path": "2026.9.20.-1.MP4",
      "date": "2026-09-20",
      "kind": "原始回放",
      "bytes": 1025222914,
      "analysis": [
        {
          "name": "淘丁堡H8系列圆屏智能手表（H8 P／H8 Pro）",
          "category": "手表",
          "windows": [
            [
              1364.0,
              3372.76
            ]
          ],
          "description": "2026-10-12 外观复核：外观同组；型号配置逐场核对",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "A-6f11746d6c5ab899"
      ],
      "status": "已有外观复核记录",
      "note": ""
    },
    {
      "id": "M-49a94fdd1a30bb84",
      "name": "2026.9.18.mp4",
      "path": "2026.9.18.mp4",
      "relative_path": "2026.9.18.mp4",
      "date": "2026-09-18",
      "kind": "原始回放",
      "bytes": 1719445341,
      "analysis": [
        {
          "name": "华为 Pura 80 Pro（12GB＋512GB／1TB需分款）",
          "category": "手机",
          "windows": [
            [
              1530,
              2670
            ]
          ],
          "description": "圆角三角相机岛、三圆镜头不等大，配合HUAWEI Pura系列白盒核对；同场基础款/Pro/Pro+与容量不能只看背面确定。",
          "evidence": "已核对的素材时间点"
        },
        {
          "name": "往复式剃须刀（其他／型号未明）",
          "category": "个护与家用",
          "windows": [
            [
              990,
              1530
            ]
          ],
          "description": "亮银色长柄、横向多刀网刀头、黑色礼盒，部分场次可见T9标识；与夏新细柄菱纹款及MS19粗柄款区分。",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "PF-24538be1",
        "PF-630d3f91"
      ],
      "status": "已有外观复核记录",
      "note": ""
    },
    {
      "id": "M-2d78fe26965cda89",
      "name": "2026.9.17.mp4",
      "path": "2026.9.17.mp4",
      "relative_path": "2026.9.17.mp4",
      "date": "2026-09-17",
      "kind": "原始回放",
      "bytes": 2014612592,
      "analysis": [
        {
          "name": "玛莎拉蒂标识智能手表",
          "category": "手表",
          "windows": [
            [
              870,
              1950
            ]
          ],
          "description": "黑色圆形智能表体、蓝/红硅胶表带、深蓝三叉戟/Maserati标识礼盒及菜单演示；机械指针款另分。",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "PF-5ac5fd9a",
        "PF-d43b70e1"
      ],
      "status": "已有外观复核记录",
      "note": ""
    },
    {
      "id": "M-371394ef849bd952",
      "name": "2026.9.16.mp4",
      "path": "2026.9.16.mp4",
      "relative_path": "2026.9.16.mp4",
      "date": "2026-09-16",
      "kind": "原始回放",
      "bytes": 1912048374,
      "analysis": [
        {
          "name": "华为 Pura 80 Pro（12GB＋512GB／1TB需分款）",
          "category": "手机",
          "windows": [
            [
              6660,
              7290
            ]
          ],
          "description": "圆角三角相机岛、三圆镜头不等大，配合HUAWEI Pura系列白盒核对；同场基础款/Pro/Pro+与容量不能只看背面确定。",
          "evidence": "已核对的素材时间点"
        },
        {
          "name": "往复式剃须刀（其他／型号未明）",
          "category": "个护与家用",
          "windows": [
            [
              4590,
              5310
            ]
          ],
          "description": "亮银色长柄、横向多刀网刀头、黑色礼盒，部分场次可见T9标识；与夏新细柄菱纹款及MS19粗柄款区分。",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "PF-24538be1",
        "PF-630d3f91"
      ],
      "status": "已有外观复核记录",
      "note": ""
    },
    {
      "id": "M-e0f2c319fea3cfe5",
      "name": "2026.9.14.mp4",
      "path": "2026.9.14.mp4",
      "relative_path": "2026.9.14.mp4",
      "date": "2026-09-14",
      "kind": "原始回放",
      "bytes": 1706622038,
      "analysis": [
        {
          "name": "华为 Pura 80 Pro（12GB＋512GB／1TB需分款）",
          "category": "手机",
          "windows": [
            [
              3150,
              3930
            ]
          ],
          "description": "圆角三角相机岛、三圆镜头不等大，配合HUAWEI Pura系列白盒核对；同场基础款/Pro/Pro+与容量不能只看背面确定。",
          "evidence": "已核对的素材时间点"
        },
        {
          "name": "往复式剃须刀（其他／型号未明）",
          "category": "个护与家用",
          "windows": [
            [
              450,
              870
            ]
          ],
          "description": "亮银色长柄、横向多刀网刀头、黑色礼盒，部分场次可见T9标识；与夏新细柄菱纹款及MS19粗柄款区分。",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "PF-24538be1",
        "PF-630d3f91",
        "PF-d43b70e1"
      ],
      "status": "已有外观复核记录",
      "note": ""
    },
    {
      "id": "M-876331c2cfde9e91",
      "name": "2026.9.13.mp4",
      "path": "2026.9.13.mp4",
      "relative_path": "2026.9.13.mp4",
      "date": "2026-09-13",
      "kind": "原始回放",
      "bytes": 1968097138,
      "analysis": [
        {
          "name": "往复式剃须刀（其他／型号未明）",
          "category": "个护与家用",
          "windows": [
            [
              810,
              1350
            ]
          ],
          "description": "亮银色长柄、横向多刀网刀头、黑色礼盒，部分场次可见T9标识；与夏新细柄菱纹款及MS19粗柄款区分。 四处抽帧与9月12一致，不认定为独立拍摄场次。",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "PF-630d3f91"
      ],
      "status": "已有外观复核记录",
      "note": ""
    },
    {
      "id": "M-aedd8cfb4cc4e65a",
      "name": "2026.9.12.mp4",
      "path": "2026.9.12.mp4",
      "relative_path": "2026.9.12.mp4",
      "date": "2026-09-12",
      "kind": "原始回放",
      "bytes": 1968097138,
      "analysis": [
        {
          "name": "往复式剃须刀（其他／型号未明）",
          "category": "个护与家用",
          "windows": [
            [
              810,
              1350
            ]
          ],
          "description": "亮银色长柄、横向多刀网刀头、黑色礼盒，部分场次可见T9标识；与夏新细柄菱纹款及MS19粗柄款区分。",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "PF-630d3f91",
        "PF-d43b70e1"
      ],
      "status": "已有外观复核记录",
      "note": ""
    },
    {
      "id": "M-f1b53e17b0fdd984",
      "name": "2026.9.11.mp4",
      "path": "2026.9.11.mp4",
      "relative_path": "2026.9.11.mp4",
      "date": "2026-09-11",
      "kind": "原始回放",
      "bytes": 1960278568,
      "analysis": [
        {
          "name": "往复式剃须刀（其他／型号未明）",
          "category": "个护与家用",
          "windows": [
            [
              2610,
              3150
            ]
          ],
          "description": "亮银色长柄、横向多刀网刀头、黑色礼盒，部分场次可见T9标识；与夏新细柄菱纹款及MS19粗柄款区分。",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "PF-630d3f91",
        "PF-d43b70e1"
      ],
      "status": "已有外观复核记录",
      "note": ""
    },
    {
      "id": "M-45a20a0b2807826b",
      "name": "2026.9.10.mp4",
      "path": "2026.9.10.mp4",
      "relative_path": "2026.9.10.mp4",
      "date": "2026-09-10",
      "kind": "原始回放",
      "bytes": 1826110871,
      "analysis": [
        {
          "name": "玛莎拉蒂标识智能手表",
          "category": "手表",
          "windows": [
            [
              1020,
              1650
            ]
          ],
          "description": "黑色圆形智能表体、蓝/红硅胶表带、深蓝三叉戟/Maserati标识礼盒及菜单演示；机械指针款另分。",
          "evidence": "已核对的素材时间点"
        },
        {
          "name": "往复式剃须刀（其他／型号未明）",
          "category": "个护与家用",
          "windows": [],
          "description": "本轮抽帧未确认该三刀网剃须刀；旧关联保留待核，不直接使用。",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "PF-5ac5fd9a",
        "PF-630d3f91"
      ],
      "status": "已有外观复核记录",
      "note": ""
    },
    {
      "id": "M-52fe0205044514fa",
      "name": "2026.9.9.mp4",
      "path": "2026.9.9.mp4",
      "relative_path": "2026.9.9.mp4",
      "date": "2026-09-09",
      "kind": "原始回放",
      "bytes": 2101128232,
      "analysis": [
        {
          "name": "玛莎拉蒂标识智能手表",
          "category": "手表",
          "windows": [
            [
              0,
              2250
            ]
          ],
          "description": "黑色圆形智能表体、蓝/红硅胶表带、深蓝三叉戟/Maserati标识礼盒及菜单演示；机械指针款另分。",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "PF-5ac5fd9a"
      ],
      "status": "已有外观复核记录",
      "note": ""
    },
    {
      "id": "M-2fbdb0937c9f1718",
      "name": "2026.09.07.mp4",
      "path": "2026.09.07.mp4",
      "relative_path": "2026.09.07.mp4",
      "date": "2026-09-07",
      "kind": "原始回放",
      "bytes": 2008286380,
      "analysis": [
        {
          "name": "往复式剃须刀（其他／型号未明）",
          "category": "个护与家用",
          "windows": [
            [
              630,
              1350
            ]
          ],
          "description": "亮银色长柄、横向多刀网刀头、黑色礼盒，部分场次可见T9标识；与夏新细柄菱纹款及MS19粗柄款区分。",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "PF-630d3f91"
      ],
      "status": "已有外观复核记录",
      "note": ""
    },
    {
      "id": "M-603ee0e2ea5dc64c",
      "name": "2026.8.13.mp4",
      "path": "2026.8.13.mp4",
      "relative_path": "2026.8.13.mp4",
      "date": "2026-08-13",
      "kind": "原始回放",
      "bytes": 1689207109,
      "analysis": [
        {
          "name": "iPad mini 7（容量与联网版本需分款）",
          "category": "平板与学习设备",
          "windows": [
            [
              4830,
              5310
            ]
          ],
          "description": "小尺寸平直边框平板、单后置摄像头及Apple标识；仅机身不能区分mini 6/7、容量或联网版本。",
          "evidence": "已核对的素材时间点"
        },
        {
          "name": "金运 KINYO C13耳夹耳机",
          "category": "耳机",
          "windows": [
            [
              3750,
              4770
            ]
          ],
          "description": "白色圆角充电仓与白色弧形连接耳机组件，黑色款同时展示，配合KINYO/C13包装核对。",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "PF-7584460b",
        "PF-7da42cfa"
      ],
      "status": "已有外观复核记录",
      "note": ""
    },
    {
      "id": "M-108cc658f4c20796",
      "name": "2026.08.11.mp4",
      "path": "2026.08.11.mp4",
      "relative_path": "2026.08.11.mp4",
      "date": "2026-08-11",
      "kind": "原始回放",
      "bytes": 1283840476,
      "analysis": [
        {
          "name": "金运 KINYO C13耳夹耳机",
          "category": "耳机",
          "windows": [
            [
              2070,
              3150
            ],
            [
              6450,
              7050
            ]
          ],
          "description": "白色圆角充电仓与白色弧形连接耳机组件，黑色款同时展示，配合KINYO/C13包装核对。",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "PF-7da42cfa"
      ],
      "status": "已有外观复核记录",
      "note": ""
    },
    {
      "id": "M-4c1779a30fd9f580",
      "name": "2026.7.30.mp4",
      "path": "2026.7.30.mp4",
      "relative_path": "2026.7.30.mp4",
      "date": "2026-07-30",
      "kind": "原始回放",
      "bytes": 1426493174,
      "analysis": [
        {
          "name": "航嘉桌面插座（M20与未明款）",
          "category": "电脑周边与存储",
          "windows": [
            [
              424.02,
              858.06
            ]
          ],
          "description": "深灰低矮方形桌面插座，交流孔在顶面、多个USB口在侧面；7月29日可见航嘉M20包装。",
          "evidence": "已核对的素材时间点"
        },
        {
          "name": "MAGCUBIC投影仪（HY350MAX与未明款）",
          "category": "音箱与投影",
          "windows": [
            [
              4296.92,
              5132.3
            ]
          ],
          "description": "浅灰方形投影机、前面密集格栅与大镜头、侧支架；7月21/30分别记录，不能直接认定两场完全同型号。",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "PF-40f6e104",
        "PF-e4ae2087"
      ],
      "status": "已有外观复核记录",
      "duration": 5157.64,
      "note": ""
    },
    {
      "id": "M-3351cde4751e7974",
      "name": "2026.7.29.mp4",
      "path": "2026.7.29.mp4",
      "relative_path": "2026.7.29.mp4",
      "date": "2026-07-29",
      "kind": "原始回放",
      "bytes": 1689284429,
      "analysis": [
        {
          "name": "航嘉桌面插座（M20与未明款）",
          "category": "电脑周边与存储",
          "windows": [
            [
              241.46,
              567.02
            ],
            [
              570.66,
              605.66
            ],
            [
              612.16,
              694.26
            ]
          ],
          "description": "深灰低矮方形桌面插座，交流孔在顶面、多个USB口在侧面；7月29日可见航嘉M20包装。",
          "evidence": "已核对的素材时间点"
        },
        {
          "name": "云小鹿 Meet 60 AI鼠标",
          "category": "电脑周边与存储",
          "windows": [
            [
              5362.96,
              5839.96
            ]
          ],
          "description": "白色长椭圆鼠标、红色滚轮、滚轮下方按键及Meet 60包装，与桌面操作画面对应。",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "PF-40f6e104",
        "PF-a04d7254"
      ],
      "status": "已有外观复核记录",
      "duration": 5852.59,
      "note": ""
    },
    {
      "id": "M-eb3a69ed345be4c5",
      "name": "2026.7.23.mp4",
      "path": "2026.7.23.mp4",
      "relative_path": "2026.7.23.mp4",
      "date": "2026-07-23",
      "kind": "原始回放",
      "bytes": 1837704284,
      "analysis": [
        {
          "name": "华硕a豆 Watch Fit S1Max",
          "category": "手表",
          "windows": [
            [
              1206.0,
              1848.86
            ]
          ],
          "description": "圆角方形薄表体、侧面按键、黑色表带，与a豆薄款手表原有画面对应。",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "PF-1eabc888"
      ],
      "status": "已有外观复核记录",
      "duration": 6152.95,
      "note": ""
    },
    {
      "id": "M-22185293e96d6bad",
      "name": "2026.7.21.mp4",
      "path": "2026.7.21.mp4",
      "relative_path": "2026.7.21.mp4",
      "date": "2026-07-21",
      "kind": "原始回放",
      "bytes": 1628334050,
      "analysis": [
        {
          "name": "MAGCUBIC投影仪（HY350MAX与未明款）",
          "category": "音箱与投影",
          "windows": [
            [
              1273.5,
              1973.1
            ],
            [
              1982.1,
              2080.84
            ],
            [
              2092.24,
              2107.34
            ],
            [
              2155.34,
              2160.34
            ]
          ],
          "description": "浅灰方形投影机、前面密集格栅与大镜头、侧支架；7月21/30分别记录，不能直接认定两场完全同型号。",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "PF-e4ae2087"
      ],
      "status": "已有外观复核记录",
      "duration": 5857.18,
      "note": ""
    },
    {
      "id": "M-961593fedd8eadd5",
      "name": "2026.7.20.mp4",
      "path": "2026.7.20.mp4",
      "relative_path": "2026.7.20.mp4",
      "date": "2026-07-20",
      "kind": "原始回放",
      "bytes": 1759647189,
      "analysis": [
        {
          "name": "山水 W165／夹耳耳机（逐场核型）",
          "category": "耳机",
          "windows": [
            [
              5262.32,
              5554.6
            ],
            [
              5569.8,
              5585.84
            ],
            [
              5587.16,
              5658.64
            ],
            [
              5680.76,
              5698.08
            ]
          ],
          "description": "扁椭圆翻盖充电仓、金属光泽夹耳组件，包装白底黄边；黑、粉、白分别核对，不以仓色推断型号。",
          "evidence": "已核对的素材时间点"
        },
        {
          "name": "iPad mini 7（容量与联网版本需分款）",
          "category": "平板与学习设备",
          "windows": [
            [
              3773.08,
              3777.76
            ],
            [
              3854.88,
              3913.72
            ],
            [
              3921.36,
              4154.74
            ],
            [
              4212.34,
              4231.7
            ],
            [
              4264.94,
              4267.94
            ],
            [
              4279.94,
              4321.7
            ],
            [
              4345.94,
              4397.66
            ]
          ],
          "description": "小尺寸平直边框平板、单后置摄像头及Apple标识；仅机身不能区分mini 6/7、容量或联网版本。",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "PF-03d5649d",
        "PF-7584460b"
      ],
      "status": "已有外观复核记录",
      "duration": 5834.03,
      "note": ""
    },
    {
      "id": "M-6272dfc571123b0f",
      "name": "2026.7.15.mp4",
      "path": "2026.7.15.mp4",
      "relative_path": "2026.7.15.mp4",
      "date": "2026-07-15",
      "kind": "原始回放",
      "bytes": 1730580356,
      "analysis": [
        {
          "name": "iPad mini 7（容量与联网版本需分款）",
          "category": "平板与学习设备",
          "windows": [
            [
              3578.46,
              3600.46
            ],
            [
              3606.8,
              3978.48
            ],
            [
              3998.52,
              4017.72
            ],
            [
              4024.64,
              4068.24
            ],
            [
              5184.6,
              5188.6
            ],
            [
              5429.06,
              5497.7
            ],
            [
              5503.14,
              5652.14
            ]
          ],
          "description": "小尺寸平直边框平板、单后置摄像头及Apple标识；仅机身不能区分mini 6/7、容量或联网版本。",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "PF-7584460b"
      ],
      "status": "已有外观复核记录",
      "duration": 6230.36,
      "note": ""
    },
    {
      "id": "M-f82d16669b7a7d7c",
      "name": "2026.7.9_原版.mp4",
      "path": "2026.7.9_原版.mp4",
      "relative_path": "2026.7.9/2026.7.9_原版.mp4",
      "date": "2026-07-09",
      "kind": "原始回放",
      "bytes": 1807920061,
      "analysis": [
        {
          "name": "山水 W165／夹耳耳机（逐场核型）",
          "category": "耳机",
          "windows": [
            [
              906.0,
              957.08
            ],
            [
              958.28,
              1054.62
            ],
            [
              1066.42,
              1155.72
            ],
            [
              1156.82,
              1347.2
            ],
            [
              1359.76,
              1435.08
            ]
          ],
          "description": "扁椭圆翻盖充电仓、金属光泽夹耳组件，包装白底黄边；黑、粉、白分别核对，不以仓色推断型号。",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "PF-03d5649d"
      ],
      "status": "已有外观复核记录",
      "duration": 5806.86,
      "note": ""
    },
    {
      "id": "M-279e35aebe55abba",
      "name": "2026.7.2_原版.mp4",
      "path": "2026.7.2_原版.mp4",
      "relative_path": "2026.7.2/2026.7.2_原版.mp4",
      "date": "2026-07-02",
      "kind": "原始回放",
      "bytes": 1200206458,
      "analysis": [
        {
          "name": "山水 W165／夹耳耳机（逐场核型）",
          "category": "耳机",
          "windows": [
            [
              700.46,
              729.94
            ],
            [
              736.14,
              965.66
            ],
            [
              967.66,
              1026.3
            ],
            [
              1028.8,
              1074.28
            ],
            [
              1076.28,
              1160.72
            ],
            [
              1165.36,
              1181.32
            ]
          ],
          "description": "扁椭圆翻盖充电仓、金属光泽夹耳组件，包装白底黄边；黑、粉、白分别核对，不以仓色推断型号。",
          "evidence": "已核对的素材时间点"
        }
      ],
      "product_ids": [
        "PF-03d5649d"
      ],
      "status": "已有外观复核记录",
      "duration": 4135.55,
      "note": ""
    },
    {
      "id": "M-c2dbfe65d8b9bb21",
      "name": "2026.4.14.mp4",
      "path": "2026.4.14.mp4",
      "relative_path": "2026.4.14.mp4",
      "date": "2026-04-14",
      "kind": "原始回放",
      "bytes": 2465222895,
      "analysis": [],
      "product_ids": [
        "PF-gt3-38233996"
      ],
      "status": "GT3原录像外观已核对"
    },
    {
      "id": "M-d30db7b60768e6f9",
      "name": "2026.4.15.mp4",
      "path": "2026.4.15.mp4",
      "relative_path": "2026.4.15.mp4",
      "date": "2026-04-15",
      "kind": "原始回放",
      "bytes": 1786824727,
      "analysis": [],
      "product_ids": [
        "PF-gt3-38233996"
      ],
      "status": "GT3原录像外观已核对"
    },
    {
      "id": "M-27f89ecf0e45d412",
      "name": "2026.4.19-2.mp4",
      "path": "2026.4.19-2.mp4",
      "relative_path": "2026.4.19-2.mp4",
      "date": "2026-04-19",
      "kind": "原始回放",
      "bytes": 1068999416,
      "analysis": [],
      "product_ids": [
        "PF-gt3-38233996"
      ],
      "status": "GT3原录像外观已核对"
    },
    {
      "id": "M-3d0138cc9dacc6d4",
      "name": "2026.4.22-2.mp4",
      "path": "2026.4.22-2.mp4",
      "relative_path": "2026.4.22-2.mp4",
      "date": "2026-04-22",
      "kind": "原始回放",
      "bytes": 1049948760,
      "analysis": [],
      "product_ids": [
        "PF-gt3-38233996"
      ],
      "status": "GT3原录像外观已核对"
    },
    {
      "id": "M-f5607eff3095a507",
      "name": "2026.4.30.mp4",
      "path": "2026.4.30.mp4",
      "relative_path": "2026.4.30.mp4",
      "date": "2026-04-30",
      "kind": "原始回放",
      "bytes": 1938804356,
      "analysis": [],
      "product_ids": [
        "PF-gt3-38233996"
      ],
      "status": "GT3原录像外观已核对"
    },
    {
      "id": "M-f14402ca6b4ce67f",
      "name": "2026.5.03.mp4",
      "path": "2026.5.03.mp4",
      "relative_path": "2026.5.03.mp4",
      "date": "2026-05-03",
      "kind": "原始回放",
      "bytes": 1839756897,
      "analysis": [],
      "product_ids": [
        "PF-gt3-38233996"
      ],
      "status": "GT3原录像外观已核对"
    },
    {
      "id": "M-d7657629b32a5c8b",
      "name": "2026.5.04.mp4",
      "path": "2026.5.04.mp4",
      "relative_path": "2026.5.04.mp4",
      "date": "2026-05-04",
      "kind": "原始回放",
      "bytes": 1686732059,
      "analysis": [],
      "product_ids": [
        "PF-gt3-38233996"
      ],
      "status": "GT3原录像外观已核对"
    },
    {
      "id": "M-76e6d11f42fe91fa",
      "name": "2026.5.05-2.mp4",
      "path": "2026.5.05-2.mp4",
      "relative_path": "2026.5.05-2.mp4",
      "date": "2026-05-05",
      "kind": "原始回放",
      "bytes": 1167960778,
      "analysis": [],
      "product_ids": [
        "PF-gt3-38233996"
      ],
      "status": "GT3原录像外观已核对"
    },
    {
      "id": "M-222ce0013b8cb0e0",
      "name": "2026.5.17.mp4",
      "path": "2026.5.17.mp4",
      "relative_path": "2026.5.17.mp4",
      "date": "2026-05-17",
      "kind": "原始回放",
      "bytes": 1682990651,
      "analysis": [],
      "product_ids": [
        "PF-gt3-38233996"
      ],
      "status": "GT3原录像外观已核对"
    },
    {
      "id": "M-5913c6147cd828d0",
      "name": "2026.10.05.mp4",
      "path": "/Volumes/视频文件/猫哥评测直播回放/2026.10.05.mp4",
      "relative_path": "2026.10.05.mp4",
      "date": "2026-10-05",
      "kind": "原始回放",
      "bytes": 2108400592,
      "analysis": [],
      "product_ids": [
        "PF-5b7ab356"
      ],
      "status": "已有产品目录"
    },
    {
      "id": "M-f0987366b9993294",
      "name": "2026.6.3.mp4",
      "date": "2026-06-03",
      "path": "/Volumes/视频文件/猫哥评测直播回放/2026.6.3.mp4",
      "relative_path": "2026.6.3.mp4",
      "kind": "原始回放",
      "bytes": 1774889646,
      "analysis": [],
      "product_ids": [
        "PF-5b7ab356"
      ],
      "status": "产品出现已核查"
    },
    {
      "id": "M-f8a8d896fc4c146d",
      "name": "2026-10-17_2251_猫哥评测_7697649353908898602_20261018-034943.mp4",
      "date": "2026-10-17",
      "path": "/Volumes/视频文件/猫哥评测直播回放/2026-10-17_2251_猫哥评测_7697649353908898602_20261018-034943.mp4",
      "relative_path": "2026-10-17_2251_猫哥评测_7697649353908898602_20261018-034943.mp4",
      "kind": "原始回放",
      "bytes": 1161112470,
      "analysis": [],
      "product_ids": [
        "PF-5b7ab356",
        "PF-09d1bc1f",
        "PF-0b6e42b4"
      ],
      "status": "产品出现已核查"
    },
    {
      "id": "M-97b67ce09dcd888d",
      "name": "2026-10-12_2055_猫哥评测_7695764177872866091_20261013-032420.mp4",
      "path": "/Volumes/视频文件/猫哥评测直播回放/2026-10-12_2055_猫哥评测_7695764177872866091_20261013-032420.mp4",
      "relative_path": "2026-10-12_2055_猫哥评测_7695764177872866091_20261013-032420.mp4",
      "date": "2026-10-12",
      "kind": "原始回放",
      "bytes": 1983947832,
      "analysis": [],
      "product_ids": [
        "PF-4649776d"
      ],
      "status": "产品出现已核查"
    },
    {
      "id": "M-614d1c8867a91640",
      "name": "2026-10-14_2055_猫哥评测_7696506225772497683_20261015-031843.mp4",
      "path": "/Volumes/视频文件/猫哥评测直播回放/2026-10-14_2055_猫哥评测_7696506225772497683_20261015-031843.mp4",
      "relative_path": "2026-10-14_2055_猫哥评测_7696506225772497683_20261015-031843.mp4",
      "date": "2026-10-14",
      "kind": "原始回放",
      "bytes": 1688580927,
      "analysis": [],
      "product_ids": [
        "PF-09d1bc1f"
      ],
      "status": "已有外观复核记录",
      "note": "数据线外观参考，规格待核"
    },
    {
      "id": "M-3185ce0fb33e42f9",
      "name": "2026-10-15_2102_猫哥评测_7696879084718148394_20261016-142542.mp4",
      "path": "/Volumes/视频文件/猫哥评测直播回放/2026-10-15_2102_猫哥评测_7696879084718148394_20261016-142542.mp4",
      "relative_path": "2026-10-15_2102_猫哥评测_7696879084718148394_20261016-142542.mp4",
      "date": "2026-10-15",
      "kind": "原始回放",
      "bytes": 1925166365,
      "analysis": [],
      "product_ids": [
        "PF-09d1bc1f"
      ],
      "status": "已有外观复核记录",
      "note": "数据线外观参考，规格待核"
    },
    {
      "id": "M-8dec7c28434dfd5b",
      "name": "2026-10-16_2248_猫哥评测_7697277454137772819_20261017-034711.mp4",
      "path": "/Volumes/视频文件/猫哥评测直播回放/2026-10-16_2248_猫哥评测_7697277454137772819_20261017-034711.mp4",
      "relative_path": "2026-10-16_2248_猫哥评测_7697277454137772819_20261017-034711.mp4",
      "date": "2026-10-16",
      "kind": "原始回放",
      "bytes": 745772650,
      "analysis": [],
      "product_ids": [
        "PF-09d1bc1f",
        "PF-0b6e42b4"
      ],
      "status": "已有外观复核记录",
      "note": "数据线外观参考，规格待核"
    },
    {
      "id": "M-573371778fd05cbe",
      "name": "2026-10-16_2105_猫哥评测_7697251068907965247_20261017-031601.mp4",
      "path": "/Volumes/视频文件/猫哥评测直播回放/2026-10-16_2105_猫哥评测_7697251068907965247_20261017-031601.mp4",
      "relative_path": "2026-10-16_2105_猫哥评测_7697251068907965247_20261017-031601.mp4",
      "date": "2026-10-16",
      "kind": "原始回放",
      "bytes": 1196222741,
      "analysis": [],
      "product_ids": [
        "PF-0b6e42b4"
      ],
      "status": "已有外观复核记录",
      "note": ""
    },
    {
      "id": "M-7ac841d36a3f1e99",
      "name": "2026-10-19_2109_猫哥评测_7698365249421839140_20261020-110042.mp4",
      "path": "/Volumes/视频文件/猫哥评测直播回放/2026-10-19_2109_猫哥评测_7698365249421839140_20261020-110042.mp4",
      "relative_path": "2026-10-19_2109_猫哥评测_7698365249421839140_20261020-110042.mp4",
      "date": "2026-10-19",
      "kind": "原始回放",
      "bytes": 1950281686,
      "analysis": [],
      "product_ids": [
        "PF-4649776d"
      ],
      "status": "原片外观复核",
      "note": ""
    },
    {
      "id": "M-fca55ffd2fca7cae",
      "name": "2026-10-22_2109_猫哥评测_7699478463660772139_20261023-031614.mp4",
      "path": "/Volumes/视频文件/猫哥评测直播回放/2026-10-22_2109_猫哥评测_7699478463660772139_20261023-031614.mp4",
      "relative_path": "2026-10-22_2109_猫哥评测_7699478463660772139_20261023-031614.mp4",
      "date": "2026-10-22",
      "kind": "原始回放",
      "bytes": 2272817881,
      "analysis": [],
      "product_ids": [
        "PF-09d1bc1f"
      ],
      "status": "原片外观核查",
      "note": ""
    },
    {
      "id": "M-f29e3b5dff5ddeb7",
      "name": "2026-10-23.mp4",
      "path": "2026-10-23.mp4",
      "relative_path": "2026-10-23.mp4",
      "date": "2026-10-23",
      "kind": "原始回放",
      "bytes": 2280835322,
      "analysis": [
        {
          "name": "千幻 SHINECON × Maserati GT3 夹耳式耳机（蓝／咖色）",
          "category": "耳机",
          "windows": [],
          "visual_anchors_seconds": [
            1460
          ],
          "description": "外观对应；完整型号与SKU待核",
          "evidence": "原录像画面核查"
        }
      ],
      "product_ids": [
        "PF-gt3-38233996"
      ],
      "status": "已有外观复核记录",
      "note": "蓝色皮纹横向长圆仓、挂绳及夹耳结构外观对应；完整型号与SKU待核。"
    },
    {
      "id": "M-70fe7f961d1323cd",
      "name": "2026-10-24.mp4",
      "path": "2026-10-24.mp4",
      "relative_path": "2026-10-24.mp4",
      "date": "2026-10-24",
      "kind": "原始回放",
      "bytes": 1456034622,
      "analysis": [
        {
          "name": "千幻 SHINECON × Maserati GT3 夹耳式耳机（蓝／咖色）",
          "category": "耳机",
          "windows": [],
          "visual_anchors_seconds": [
            900
          ],
          "description": "外观对应；完整型号与SKU待核",
          "evidence": "原录像画面核查"
        }
      ],
      "product_ids": [
        "PF-gt3-38233996"
      ],
      "status": "已有外观复核记录",
      "note": "蓝色皮纹横向长圆仓、挂绳及夹耳结构外观对应；完整型号与SKU待核。"
    },
    {
      "id": "M-31025b756cafcdfd",
      "name": "2026-10-25.mp4",
      "path": "2026-10-25.mp4",
      "relative_path": "2026-10-25.mp4",
      "date": "2026-10-25",
      "kind": "原始回放",
      "bytes": 2225850395,
      "analysis": [
        {
          "name": "千幻 SHINECON × Maserati GT3 夹耳式耳机（蓝／咖色）",
          "category": "耳机",
          "windows": [],
          "visual_anchors_seconds": [
            6067
          ],
          "description": "外观对应；完整型号与SKU待核",
          "evidence": "原录像画面核查"
        }
      ],
      "product_ids": [
        "PF-gt3-38233996"
      ],
      "status": "已有外观复核记录",
      "note": "蓝色皮纹横向长圆仓、挂绳及夹耳结构外观对应；完整型号与SKU待核。"
    }
  ],
  "deleted_products": [],
  "shop_links": [
    {
      "name": "【猫哥专属】娱小电【3C认证】超薄折叠支架磁吸q12外接电池PD充电宝金属无线充",
      "url": "https://haohuo.jinritemai.com/ecommerce/trade/detail/index.html?id=3844283467328258512&origin_type=604&channel_id=3380051563131941&channel_type=4",
      "image": "https://p3-item.ecombdimg.com/img/ecom-shop-material/png_m_7250cb123c5e4a5d82b2f13e173ec5ef_sx_2162650_www1279-1279~tplv-5mmsx3fupr-resize_q:1080:1080:q90.webp"
    }
  ],
  "stats": {
    "raw_recordings": 61,
    "slices": 0,
    "raw_with_products": 61
  },
  "updated_at": "2026-10-26",
  "source_root": "云端查询快照",
  "product_merges": []
};
