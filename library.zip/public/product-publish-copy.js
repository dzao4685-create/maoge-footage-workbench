/* Local, editable publishing drafts. No remote model or publishing API. */
(function () {
  let currentId = '', variant = 0;
  const versions = {title: 0, intro: 0, topics: 0};
  const groups = [
    [/耳机/, '耳机', ['耳机','数码好物','耳机怎么选','好物分享','猫哥评测']],
    [/剃须/, '剃须刀', ['剃须刀','男士日常','剃须刀怎么选','好物分享','猫哥评测']],
    [/电池|充电宝/, '充电宝', ['充电宝','手机配件','充电宝怎么选','数码好物','猫哥评测']],
    [/手表/, '手表', ['手表','手表怎么选','日常搭配','好物分享','猫哥评测']],
    [/手机/, '手机', ['手机','手机怎么选','数码好物','好物分享','猫哥评测']]
  ];
  document.body.insertAdjacentHTML('beforeend', `<dialog id="publishCopyDialog"><div class="dhead"><h2>抖音发布文案</h2><button class="btn close">关闭</button></div><div class="dbody"><p id="publishProductName"></p><p class="subtle">产品特点＋使用场景风格草稿，不带商品品牌和型号。请结合实际画面检查后使用；发布时确认话题识别生效。</p><p id="publishGenerationStatus" role="status" class="subtle"></p><form id="publishCopyForm"><label>视频重点（选填，只填写片中实际出现的内容）<input id="publishFocus" maxlength="100" placeholder="例如：吸附展示、充电演示"></label><div class="buttons" style="margin:14px 0"><button class="btn primary" type="submit">全部重新生成</button></div></form><div class="formgrid"><label class="wide">标题<textarea id="publishTitle" rows="2"></textarea><button type="button" class="btn" data-copy-publish="publishTitle">复制标题</button><button type="button" class="btn" data-regenerate-publish="title">重新生成标题</button></label><label class="wide">简介（约150字）<textarea id="publishIntro" rows="6"></textarea><span class="subtle" id="publishIntroCount" aria-live="polite"></span><button type="button" class="btn" data-copy-publish="publishIntro">复制简介</button><button type="button" class="btn" data-regenerate-publish="intro">重新生成简介</button></label><label class="wide">标签 / 话题（5个）<textarea id="publishTopics" rows="2"></textarea><button type="button" class="btn" data-copy-publish="publishTopics">复制话题</button><button type="button" class="btn" data-regenerate-publish="topics">重新生成话题</button></label></div><div class="buttons" style="margin-top:18px"><button class="btn primary" data-copy-publish="all" type="button">一键复制全部</button></div><p class="subtle">不自动加入价格、续航、原装、认证、优惠等承诺。商品规格与权益以核实结果为准。</p></div></dialog>`);
  let generating = false;
  function generate(part = 'all') {
    const p = productMap[currentId];
    if (!p) return;
    const group = groups.find(g => g[0].test((p.name || '') + ' ' + p.category));
    const kind = group?.[1] || '实用好物';
    const focus = Array.from($('#publishFocus').value.trim()).slice(0,40).join('');
    // Only approved scene words enter copy; never echo product names or free-form focus.
    const sceneRules = [
      [/吸附|磁吸/, '吸附和取下'], [/支架|折叠/, '支架展开和收起'],
      [/充电|试充/, '充电操作'], [/佩戴|戴上/, '佩戴方式'],
      [/刀头|拆装/, '部件拆装'], [/表带/, '表带细节'],
      [/屏幕|触控|操作/, '日常操作'], [/外观|机身/, '外观细节']
    ];
    const scenes = sceneRules.filter(([rule]) => rule.test(focus)).map(([,text]) => text).slice(0,2);
    const profiles = [
      [/Pura|华为/i, '手机', '机身采用圆角三角形相机区域，背部镜头布局很有辨识度。视频展示了机身外观和包装细节，换机时关注屏幕、握持和日常操作的朋友，可以先看看实物展示。'],
      [/iPad|平板/i, '小尺寸平板', '小尺寸机身搭配平直边框，背部采用单摄像头设计。视频展示了机身和包装，想用来随身携带、阅读或日常使用，可以先看看实际大小和外观细节。'],
      [/金运|KINYO/i, '夹耳式耳机', '圆角充电仓搭配弧形夹耳组件，黑白外观可以分别看。视频展示了充电仓轮廓与耳机结构，关注耳机佩戴形式、拿取和随身收纳的朋友，可以看看这些实物细节。'],
      [/山水.*耳机/, '夹耳式耳机', '扁椭圆翻盖充电仓搭配金属光泽的夹耳组件，黑色、粉色和白色各有不同风格。视频展示了仓体和耳机外观，喜欢这类设计的朋友可以对照自己偏好的颜色。'],
      [/得力/, '多面插座转换器', '圆角方块机身，多面布局插孔，侧面带充电接口，蓝灰和粉绿配色可以分别看。视频展示了外观与接口位置，桌面整理时可以先对照插头形状和摆放空间。'],
      [/航嘉/, '桌面插座', '深灰色低矮机身，插孔位于顶面，充电接口分布在侧面。视频展示了外观和接口布局，日常桌面使用可以关注线材朝向、插头间距和摆放方式。'],
      [/MAG|投影/i, '投影仪', '浅灰色机身搭配前面格栅和镜头，侧面带支架结构。视频展示了机身轮廓与摆放相关细节，想了解家里怎么放置的朋友，可以先看看实物的外观和支撑方式。'],
      [/云小鹿|鼠标/, '鼠标', '白色长椭圆机身搭配红色滚轮，滚轮下方设有按键。视频展示了机身外观和包装，日常办公或桌面使用，可以先看看轮廓、按键位置与自己的操作习惯是否合拍。'],
      [/黑蜂暴|FC30|BLACKFOMBO/i, '充电宝', '自带双线，线材随机身收纳，正面带电量显示区域。视频展示了机身、挂绳和接线充电的操作，日常出门给手机补电，可以重点看看拿取和收纳方式。'],
      [/娱小电|BK005|q12/i, '磁吸充电宝', '机身带折叠支架，吸附在手机背面后，还能展开支架摆放。视频展示了吸附、取下和支架开合，不同颜色的外观也有对应画面，选款时可对照自己喜欢的颜色。'],
      [/DOSS|德士/i, '夹耳式耳机', '椭圆翻盖充电仓搭配夹耳结构，黑色和米白色外观各有特点。视频展示了充电仓、耳机轮廓与夹耳部件，日常听歌、接电话前，可以先看看这种佩戴方式和收纳设计。'],
      [/GT3|千幻/i, '夹耳式耳机', '长圆形充电仓搭配皮纹外观，侧面带挂绳和开孔细节，蓝色与咖色呈现不同风格。视频里可以看到充电仓和夹耳组件的近景，喜欢这类设计的朋友可以看看实物细节。'],
      [/夏新|AMOI/i, '往复式剃须刀', '细长机身搭配横向刀网，背面带菱形纹理，黑银两种外观各有特点。视频以实物展示为主，刀网、机身轮廓和按键位置都能对照查看，适合关注日常剃须用品的朋友了解。'],
      [/莱永/i, '往复式剃须刀', '亮银色长柄搭配多刀网刀头，整体线条简洁。视频展示了机身和刀头的近景，关注握持方式、刀头结构和收纳外观的朋友，可以跟着画面一起看看这些细节。'],
      [/玛莎拉蒂.*手表|玛莎拉蒂手表/, '圆屏智能手表', '圆形表体搭配蓝色或红色表带，外观偏运动风格。视频展示了表体、表带和菜单操作，日常搭配可以先看上手后的样子，再留意自己常用的操作入口。'],
      [/H8|淘丁堡/i, '圆屏智能手表', '圆形屏幕搭配不同风格表带，黑银外观可以分别看。视频展示了表体、表带和菜单细节，日常通勤还是休闲搭配，可以先对照自己喜欢的外观和佩戴方式。'],
      [/华硕|a豆/i, '方屏智能手表', '圆角方形薄表体搭配黑色表带，侧面按键位置清楚。视频展示了表体轮廓和佩戴相关细节，喜欢简洁外观的朋友，可以看看它与日常穿搭的搭配方式。']
    ];
    const profile = profiles.find(([rule]) => rule.test(p.name || ''));
    const displayKind = profile?.[1] || kind;
    const details = profile?.[2] || '这段视频围绕实物展示展开，外观、结构和操作细节可以跟着画面逐项查看。日常准备怎么用，就重点看对应的部分，先了解清楚再选款。';
    const extraFocus = scenes.length ? '本段重点展示'+scenes.join('、')+'。' : '';
    const titles = [displayKind+'上手看看，外观细节一次看清', displayKind+'日常怎么用？跟着实物一起看', '关注'+displayKind+'的朋友，看看这些细节'];
    const intros = [
      displayKind+'，'+details+extraFocus+'近景看外观，操作看过程，视频里的展示可以作为挑选参考。不同款式分别对照，具体配置和适配情况按所选商品确认。喜欢这种风格，可以点开商品看看详情。',
      '这款'+displayKind+'，从外观到实物细节一起看。'+details+extraFocus+'视频展示与选款信息记得对应，颜色、配置和适配情况分别核对。想了解这类好物的朋友，可以点开商品详情继续看看。',
      '今天看看这款'+displayKind+'。'+details+extraFocus+'把细节放近看，把操作过程看明白，选款更有参考。具体颜色、配置和适配情况按商品详情确认，喜欢的朋友可以继续了解。'
    ];
    if(part==='all'||part==='title') $('#publishTitle').value=titles[versions.title%titles.length];
    if(part==='all'||part==='intro') {
      let intro=intros[versions.intro%intros.length];
      while(Array.from(intro).length>170){
        const sentences=intro.match(/[^。！？]+[。！？]?/g)||[intro];
        if(sentences.length<4)break;
        sentences.splice(sentences.length-2,1);intro=sentences.join('');
      }
      
      $('#publishIntro').value=intro;updateIntroCount();
    }
    const tags=group?.[2]||['好物分享','实用好物','购物参考','日常好物','猫哥评测'];
    const choices=[tags,[tags[0],tags[2],'选购指南',tags[3],tags[4]],[tags[0],'好物怎么选',tags[1],'购物分享',tags[4]]];
    if(part==='all'||part==='topics')$('#publishTopics').value=[...new Set(choices[versions.topics%choices.length])].map(t=>'#'+t).join(' ');
    $('#publishGenerationStatus').textContent='本地模板已生成，可编辑后复制。';
  }
  function updateIntroCount() { $('#publishIntroCount').textContent = '当前 ' + Array.from($('#publishIntro').value).length + ' 字（含标点，不含话题）'; }
  $('#publishIntro').addEventListener('input', updateIntroCount);
  const oldRender = render;
  render = function () {
    oldRender();
    if (view !== 'products') return;
    document.querySelectorAll('#results [data-product]').forEach(open => {
      const row = open.closest('.card,.productListRow,tr');
      if (!row || row.querySelector('[data-publish-product]')) return;
      const button = document.createElement('button');
      button.type = 'button'; button.className = 'btn';
      button.textContent = '生成发布文案'; button.dataset.publishProduct = open.dataset.product;
      open.before(button);
    });
  };
  document.addEventListener('click', async event => {
    const button = event.target.closest('button');
    if (!button) return;
    if (generating && button.dataset.publishProduct) return;
    if (button.dataset.publishProduct) {
      currentId = button.dataset.publishProduct; variant = 0;
      Object.keys(versions).forEach(key => versions[key] = 0);
      $('#publishProductName').textContent = productMap[currentId].name;
      $('#publishFocus').value = '';
      ['publishTitle','publishIntro','publishTopics'].forEach(id => $('#'+id).value = '');
      updateIntroCount(); $('#publishCopyDialog').showModal(); await generate();
    }
    if (button.dataset.regeneratePublish) {
      const part = button.dataset.regeneratePublish;
      if (Object.hasOwn(versions, part)) { versions[part]++; generate(part); }
    }
    if (button.dataset.copyPublish) {
      const key = button.dataset.copyPublish;
      const value = key === 'all' ? ['publishTitle','publishIntro','publishTopics'].map(id => $('#'+id).value.trim()).filter(Boolean).join('\n\n') : $('#'+key).value;
      try { await navigator.clipboard.writeText(value); toast('发布文案已复制'); }
      catch { window.prompt('请复制发布文案', value); }
    }
  });
  $('#publishCopyForm').onsubmit = event => { event.preventDefault(); Object.keys(versions).forEach(key => versions[key]++); generate(); };
  render();
})();
