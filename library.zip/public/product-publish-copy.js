/* Local, editable publishing drafts. No remote model or publishing API. */
(function () {
  let currentId = '', variant = 0;
  const versions = {title: 0, intro: 0, topics: 0};
  const groups = [
    [/耳机/, '耳机', ['耳机','数码好物','耳机怎么选','好物分享','猫哥评测']],
    [/剃须/, '剃须刀', ['剃须刀','男士日常','剃须刀怎么选','好物分享','猫哥评测']],
    [/电池|充电宝/, '充电宝', ['充电宝','手机配件','充电宝怎么选','数码好物','猫哥评测']],
    [/手表/, '手表', ['手表','手表怎么选','日常搭配','好物分享','猫哥评测']],
    [/手机/, '手机', ['手机','手机怎么选','数码好物','好物分享','猫哥评测']]
  ];
  document.body.insertAdjacentHTML('beforeend', `<dialog id="publishCopyDialog"><div class="dhead"><h2>抖音发布文案</h2><button class="btn close">关闭</button></div><div class="dbody"><p id="publishProductName"></p><p class="subtle">本地模板生成草稿，无需连接大模型。请结合实际视频检查后使用；发布时确认话题识别生效。</p><p id="publishGenerationStatus" role="status" class="subtle"></p><form id="publishCopyForm"><label>视频重点（选填，只填写片中实际出现的内容）<input id="publishFocus" maxlength="100" placeholder="例如：吸附展示、充电演示"></label><div class="buttons" style="margin:14px 0"><button class="btn primary" type="submit">全部重新生成</button></div></form><div class="formgrid"><label class="wide">标题<textarea id="publishTitle" rows="2"></textarea><button type="button" class="btn" data-copy-publish="publishTitle">复制标题</button><button type="button" class="btn" data-regenerate-publish="title">重新生成标题</button></label><label class="wide">简介（约150字）<textarea id="publishIntro" rows="6"></textarea><span class="subtle" id="publishIntroCount" aria-live="polite"></span><button type="button" class="btn" data-copy-publish="publishIntro">复制简介</button><button type="button" class="btn" data-regenerate-publish="intro">重新生成简介</button></label><label class="wide">标签 / 话题（5个）<textarea id="publishTopics" rows="2"></textarea><button type="button" class="btn" data-copy-publish="publishTopics">复制话题</button><button type="button" class="btn" data-regenerate-publish="topics">重新生成话题</button></label></div><div class="buttons" style="margin-top:18px"><button class="btn primary" data-copy-publish="all" type="button">一键复制全部</button></div><p class="subtle">不自动加入价格、续航、原装、认证、优惠等承诺。商品规格与权益以核实结果为准。</p></div></dialog>`);
  let generating = false;
  function generate(part = 'all') {
    const p = productMap[currentId];
    if (!p) return;
    const name = Array.from(p.name || '这款商品').slice(0,28).join('');
    const group = groups.find(g => g[0].test(name + ' ' + p.category));
    const kind = group?.[1] || '实用好物';
    const focus = Array.from($('#publishFocus').value.trim()).slice(0,40).join('');
    const focusText = focus ? '这次关注：' + focus + '。' : '';
    const titles = [name+'怎么选？先看看再决定','正在挑'+kind+'？这款可以了解一下',name+'，你最关心哪一点？'];
    const intros = [
      '今天和大家聊聊'+name+'。'+focusText+'挑'+kind+'，你会先看外观，还是更在意它能不能满足日常需要？同一种商品，不同人的使用习惯和预算可能差很多。先列清楚自己最需要的地方，再对照具体型号、规格和适配条件，选择才更有方向。别只凭一个卖点就急着决定，也欢迎把最想问的问题留在评论区。',
      '正在选'+kind+'的朋友，可以先了解一下'+name+'。'+focusText+'买东西之前，我更建议先问自己：平时准备怎么用，有哪些必须满足的要求？把这些想清楚，再去比较型号、规格和预算，会比只看宣传词更有帮助。适合别人的款式，未必适合自己。你挑这类产品时最纠结什么？评论区聊聊你的需求。',
      name+'，你会把它放进备选清单吗？'+focusText+'选'+kind+'不用急着下结论，可以先从自己的日常场景出发，把在意的细节逐项列出来，再核对商品的型号、规格和适配说明。价格只是其中一个考虑，真正适合自己的使用方式也很关键。你更看重哪一点，又有哪些地方想进一步了解？欢迎留言，说说你的选购思路。'
    ];
    if(part==='all'||part==='title') $('#publishTitle').value=titles[versions.title%titles.length];
    if(part==='all'||part==='intro') {
      let intro=intros[versions.intro%intros.length];
      while(Array.from(intro).length>170){
        const sentences=intro.match(/[^。！？]+[。！？]?/g)||[intro];
        if(sentences.length<4)break;
        sentences.splice(sentences.length-2,1);intro=sentences.join('');
      }
      for(const extra of ['不同版本也记得分别确认，避免选错。','先看清楚，再决定是否适合自己。'])if(Array.from(intro).length<140)intro+=extra;
      $('#publishIntro').value=intro;updateIntroCount();
    }
    const tags=group?.[2]||['好物分享','实用好物','购物参考','日常好物','猫哥评测'];
    const choices=[tags,[tags[0],tags[2],'选购指南',tags[3],tags[4]],[tags[0],'好物怎么选',tags[1],'购物分享',tags[4]]];
    if(part==='all'||part==='topics')$('#publishTopics').value=[...new Set(choices[versions.topics%choices.length])].map(t=>'#'+t).join(' ');
    $('#publishGenerationStatus').textContent='本地模板已生成，可编辑后复制。';
  }
  function updateIntroCount() { $('#publishIntroCount').textContent = '当前 ' + Array.from($('#publishIntro').value).length + ' 字（含标点，不含话题）'; }
  $('#publishIntro').addEventListener('input', updateIntroCount);
  const oldRender = render;
  render = function () {
    oldRender();
    if (view !== 'products') return;
    document.querySelectorAll('#results [data-product]').forEach(open => {
      const row = open.closest('.card,.productListRow,tr');
      if (!row || row.querySelector('[data-publish-product]')) return;
      const button = document.createElement('button');
      button.type = 'button'; button.className = 'btn';
      button.textContent = '生成发布文案'; button.dataset.publishProduct = open.dataset.product;
      open.before(button);
    });
  };
  document.addEventListener('click', async event => {
    const button = event.target.closest('button');
    if (!button) return;
    if (generating && button.dataset.publishProduct) return;
    if (button.dataset.publishProduct) {
      currentId = button.dataset.publishProduct; variant = 0;
      Object.keys(versions).forEach(key => versions[key] = 0);
      $('#publishProductName').textContent = productMap[currentId].name;
      $('#publishFocus').value = '';
      ['publishTitle','publishIntro','publishTopics'].forEach(id => $('#'+id).value = '');
      updateIntroCount(); $('#publishCopyDialog').showModal(); await generate();
    }
    if (button.dataset.regeneratePublish) {
      const part = button.dataset.regeneratePublish;
      if (Object.hasOwn(versions, part)) { versions[part]++; generate(part); }
    }
    if (button.dataset.copyPublish) {
      const key = button.dataset.copyPublish;
      const value = key === 'all' ? ['publishTitle','publishIntro','publishTopics'].map(id => $('#'+id).value.trim()).filter(Boolean).join('\n\n') : $('#'+key).value;
      try { await navigator.clipboard.writeText(value); toast('发布文案已复制'); }
      catch { window.prompt('请复制发布文案', value); }
    }
  });
  $('#publishCopyForm').onsubmit = event => { event.preventDefault(); Object.keys(versions).forEach(key => versions[key]++); generate(); };
  render();
})();
