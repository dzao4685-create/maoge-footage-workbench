from pathlib import Path
import json,re,hashlib,csv,datetime,sys,shutil
BASE=Path(__file__).resolve().parent.parent
ROOT=Path('/Volumes/视频文件/猫哥评测直播回放')
ANALYSIS=Path('/Volumes/视频文件/ai分析直播内容')
DATA=BASE/'数据'
def read(p):
 try:return json.loads(p.read_text(encoding='utf-8-sig'))
 except (OSError,ValueError):return None
def dateof(s):
 m=re.search(r'2026[.\-](\d{1,2})[.\-](\d{1,2})',s)
 if not m:return None
 try:return datetime.date(2026,int(m[1]),int(m[2])).isoformat()
 except ValueError:return None
def ident(s):return hashlib.sha256(s.encode()).hexdigest()[:16]
def norm(s):return re.sub(r'[\s（(].*?[）)]|[\s·_\-]', '',s).lower()
def category(s):
 for kw,cat in [('剃须','剃须刀'),('手表','手表'),('腕表','手表'),('耳机','耳机'),('充电','充电与手机配件'),('数据线','充电与手机配件'),('手机','手机'),('音箱','音箱'),('音响','音箱'),('戒指','智能戒指'),('眼镜','眼镜')]:
  if kw in s:return cat
 return '其他 / 待分类'
def windows(rows):
 out=[]
 for r in rows:
  try:a=float(r['start']);b=float(r['end'])
  except (KeyError,TypeError,ValueError):continue
  if a>=0 and b>a:out.append([round(a,2),round(b,2)])
 out=sorted(set(tuple(w) for w in out)); merged=[]
 for a,b in out:
  if merged and a<=merged[-1][1]+1:merged[-1][1]=max(b,merged[-1][1])
  else:merged.append([a,b])
 return merged

def build():
 if not ROOT.is_dir():raise RuntimeError('素材盘未连接：'+str(ROOT))
 if not ANALYSIS.is_dir():raise RuntimeError('分析资料盘未连接：'+str(ANALYSIS))
 records=[]; names={}; paths={}; skipped=[]
 for p in sorted(ROOT.rglob('*')):
  if not p.is_file():continue
  d=dateof(str(p.relative_to(ROOT)))
  if not d or d<'2026-07-01':continue
  if p.name.lower().endswith('.partial'):skipped.append(str(p));continue
  if p.suffix.lower() not in ['.mp4','.mov','.mkv','.m4v']:continue
  rel=str(p.relative_to(ROOT)); rid='M-'+ident(rel)
  r={'id':rid,'name':p.name,'path':str(p),'relative_path':rel,'date':d,'kind':'原始回放' if p.parent==ROOT or '原版' in p.name else '已有切片','bytes':p.stat().st_size,'analysis':[],'product_ids':[],'status':'待补充产品信息'}
  records.append(r);names.setdefault(p.name,[]).append(r);paths[str(p)]=r
 def byname(n):
  rs=names.get(n,[]);return rs[0] if len(rs)==1 else None
 def detail(r,name,cat,spans,description,proof):
  if not r or not name:return
  item={'name':name,'category':cat or category(name),'windows':spans,'description':description or '', 'evidence':str(proof),'timing_basis':'已有分析回查窗口，剪辑前需核对原音与画面'}
  if not any(x['name']==name and x['windows']==spans for x in r['analysis']):r['analysis'].append(item)
 # Most recent complete local catalog: source is read-only.
 catalogs=[]
 for p in (ANALYSIS/'网站目录').glob('catalog-*/payload.json'):
  v=read(p)
  if isinstance(v,dict) and isinstance(v.get('products'),list):catalogs.append((v.get('snapshot_at',''),p,v))
 if not catalogs:raise RuntimeError('未找到可读取的产品目录')
 _,catalogpath,catalog=max(catalogs,key=lambda x:x[0])
 products=[]
 for p in catalog['products']:
  apps=[]
  for a in p.get('appearances',[]):
   r=byname(a.get('recording_name',''))
   if r:apps.append({'recording_id':r['id'],'basis':'已有产品目录','windows':[]})
  if not apps:continue
  pid=p.get('id') or 'P-'+ident(p['name'])
  q={'id':pid,'name':p['name'],'category':p.get('category') or category(p['name']),'aliases':p.get('aliases',[]),'description':p.get('description',''),'cautions':p.get('cautions',[]),'appearances':apps,'evidence':str(catalogpath)}
  products.append(q)
  for a in apps:
   r=next(r for r in records if r['id']==a['recording_id']);r['product_ids'].append(pid);r['status']='已有产品目录'
 # Detailed reviewed sections retain their own names; never silently merge uncertain SKUs.
 batches=ANALYSIS/'素材与分析/分析结果'
 for p in sorted(batches.glob('*/content-v2/reviewed/*/segments.json')):
  v=read(p)
  if not isinstance(v,dict):continue
  r=byname(Path(v.get('source_video','')).name)
  if not r:continue
  if v.get('duration_seconds'):r['duration']=v['duration_seconds']
  for x in v.get('products',[]):
   spans=windows([s for s in v.get('sections',[]) if s.get('product_id')==x.get('id')])
   detail(r,x.get('name'),None,spans,x.get('summary'),p)
 # September vetted v2 mapping from published delivery ledger.
 archive=ANALYSIS/'分析资料/20261006_统一归档/任务与审核资料'
 p=archive/'2026-09-01_2026-09-30/codex-content-review-v2/产品索引.json'
 v=read(p)
 if isinstance(v,list):
  for x in v:
   part=x.get('source_part_id','');n='2026.9.21.mp4' if '2026-09-21-' in part else '2026.9.20.-1.MP4' if '2026-09-20-' in part else ''
   w=x.get('range',{});detail(byname(n),x.get('name'),None,windows([{'start':w.get('audio_start'),'end':w.get('audio_end')}]),x.get('description'),p)
 # October audio review windows, expressly not clip-ready boundaries.
 octpaths=[ANALYSIS/'持续分析/内容审校/2026-10-06/2026-10-06-original-ff305a04f5cb/产品索引.json',ANALYSIS/'持续分析/内容审校/2026-10-07/2026-10-07-original-7c0c62f57224/Codex-content-analysis-v1/产品索引.json',ANALYSIS/'持续分析/内容审校/2026-10-08/2026-10-08-original-addc50065a09/Codex-content-analysis-v1/产品索引.json']
 for p in octpaths:
  v=read(p)
  if not isinstance(v,dict):continue
  r=byname(v.get('recording_name',''))
  if not r:
   rs=[r for r in records if r['date']==v.get('recording_date') and r['kind']=='原始回放'];r=rs[0] if len(rs)==1 else None
  for x in v.get('products',[]):
   a=x.get('audio_review_start_seconds',x.get('audio_start'));b=x.get('audio_review_end_seconds',x.get('audio_end'))
   detail(r,x.get('name'),x.get('category'),windows([{'start':a,'end':b}]),x.get('observed',x.get('accepted_identity','')),p)
 # Slice descriptions and original windows from CSV; filename-only details are labeled.
 for p in ROOT.glob('*/*.csv'):
  d=dateof(str(p.relative_to(ROOT)))
  if not d or d<'2026-07-01':continue
  try:
   rows=list(csv.DictReader(p.open(encoding='utf-8-sig')))
  except (OSError,UnicodeError):continue
  for x in rows:
   seq=x.get('序号','').strip().zfill(2)
   matches=[r for r in records if Path(r['path']).parent==p.parent and r['name'].startswith(seq+'_')]
   for r in matches:
    title=x.get('主题描述') or Path(r['name']).stem
    r['slice_description']=title;r['original_window']=[x.get('开始时间'),x.get('结束时间')];r['duration']=float(x.get('时长(秒)','0') or 0)
    detail(r,title,category(title),[[0,r['duration']]] if r['duration'] else [],'已有切片方案；产品型号未独立核实',p)
    r['status']='切片方案记录'
 # Attach exact-name analysis windows to canonical appearances; retain others on source detail.
 lookup={r['id']:r for r in records}
 for p in products:
  keys={norm(s) for s in [p['name']]+p['aliases']}
  for a in p['appearances']:
   r=lookup[a['recording_id']]
   a['windows']=windows([{'start':w[0],'end':w[1]} for x in r['analysis'] if norm(x['name']) in keys for w in x['windows']])
 # Each analysis-only product remains queryable with its evidence, without fuzzy SKU merges.
 seen={}
 for r in records:
  for x in r['analysis']:
   existing=[p for p in products if norm(x['name']) in {norm(s) for s in [p['name']]+p['aliases']} and any(a['recording_id']==r['id'] for a in p['appearances'])]
   if existing:continue
   key=x['name']
   if key not in seen:
    q={'id':'A-'+ident(key),'name':key,'category':x['category'],'aliases':[],'description':x['description'],'cautions':['来源为已有分析或切片方案，型号及剪辑边界请核对原素材。'],'appearances':[],'evidence':x['evidence']};seen[key]=q
   seen[key]['appearances'].append({'recording_id':r['id'],'basis':'已有分析 / 切片方案','windows':x['windows']})
   r['product_ids'].append(seen[key]['id'])
  if r['analysis'] and r['status']=='待补充产品信息':r['status']='已有分析记录'
 products+=list(seen.values())
 imagefolder=BASE/'工作台/product-images';imagefolder.mkdir(exist_ok=True)
 for q in products:
  pic=catalogpath.parent/'thumbnails'/(q['id']+'.jpg')
  if pic.is_file():
   dest=imagefolder/pic.name
   if not dest.exists():shutil.copy2(pic,dest)
   q['footage_image']='product-images/'+pic.name;q['image_source']='待添加对应商品链接图'
 for r in records:
  if r['kind']=='已有切片' and not r['analysis']:
   title=Path(r['name']).stem;pid='F-'+ident(r['relative_path'])
   products.append({'id':pid,'name':title,'category':category(title),'aliases':[],'description':'仅据文件名建立查找入口，未核实内容。','cautions':['文件名线索，未核实产品型号。'],'appearances':[{'recording_id':r['id'],'basis':'文件名线索','windows':[]}],'evidence':r['path']});r['product_ids'].append(pid);r['status']='文件名线索'
 raw=[r for r in records if r['kind']=='原始回放']
 result={'schema_version':1,'updated_at':datetime.datetime.now().astimezone().isoformat(),'source_root':str(ROOT),'analysis_root':str(ANALYSIS),'catalog_source':str(catalogpath),'scope':'2026-07-01 起；完整视频，排除未完成下载','recordings':sorted(records,key=lambda r:(r['date'],r['name']),reverse=True),'products':products,'skipped_incomplete':skipped,'stats':{'recordings':len(records),'raw_recordings':len(raw),'slices':len(records)-len(raw),'catalog_products':len(products)-len(seen)-sum(p['id'].startswith('F-') for p in products),'query_entries':len(products),'raw_with_products':sum(bool(r['product_ids']) for r in raw),'raw_pending':[r['name'] for r in raw if not r['product_ids']],'with_time_windows':sum(any(x['windows'] for x in r['analysis']) for r in records)}}
 from 素材外观复核 import apply_visual_reviews
 result=apply_visual_reviews(result)
 DATA.mkdir(parents=True,exist_ok=True)
 target=DATA/'素材索引.json';tmp=target.with_suffix('.tmp');tmp.write_text(json.dumps(result,ensure_ascii=False,indent=2));tmp.replace(target)
 (BASE/'工作台/catalog-data.js').write_text('window.BASE_INDEX='+json.dumps(result,ensure_ascii=False)+';\n')
 return result
if __name__=='__main__':
 try:r=build();print(json.dumps(r['stats'],ensure_ascii=False,indent=2))
 except Exception as e:print(str(e),file=sys.stderr);sys.exit(1)
