from pathlib import Path
import json,re,base64,hashlib,datetime
BASE=Path(__file__).resolve().parent.parent;DATA=BASE/'数据';APP=BASE/'工作台'
def read(p,default):
 try:return json.loads(p.read_text())
 except (OSError,ValueError):return default
def clean(s):return re.sub(r'[^a-z0-9\u4e00-\u9fff]','',s.lower())
def shop():return read(DATA/'商品库只读快照.json',{}).get('products',[])
def related(p,rows):
 names=[p.get('name','')]+p.get('aliases',[]);text=clean(' '.join(names));keys=['莱永','夏新','淘丁堡','玛莎拉蒂','doss','山水','阅星瞳','娱小店','宾利','诺希','金运','得力','海明视','膜小喵','速能量','戴佳','coolpad','酷派','mag','哈曼卡顿','aura','pura','iphone','ipad','mate','metz','斐讯','phicomm'];found=[k for k in keys if k in text];out=[]
 for r in rows:
  n=clean(r['name']);exact=any(clean(a)==n for a in names)
  if p.get('id','!') in r.get('image','') or exact or (len(n)>=5 and n in text) or any(k in n for k in found):out.append(dict(r,match_status='名称一致，仍需核对款式' if exact else '同品牌/名称线索，待核对款式'))
 return out
def decorate(v):
 rows=shop();rs=read(DATA/'商品图片链接补充.json',{})
 for p in v['products']:
  oldimage=p.pop('image',None)
  uploaded=oldimage if p.get('image_source')=='用户上传产品图片' and p.get('product_url') else None
  if oldimage:p['footage_image']=oldimage
  p.update(rs.get(p['id'],{}));p['candidate_links']=related(p,rows)
  bound=[r for r in rows if p['id'] in r.get('image','')]
  if len(bound)==1 and not p.get('product_url'):p.update(product_url=bound[0]['url'],link_name=bound[0]['name'],link_source='原商品库直播图匹配',link_status='沿用原工作台关联；款式与库存待核对')
  selected=next((r for r in rows if r['url']==p.get('product_url')),None)
  if not selected and len(p['candidate_links'])==1:
   candidate=p['candidate_links'][0]
   if '夏新' in p['name'] and candidate['name']=='夏新剃须刀':selected=candidate;p.update(product_url=selected['url'],link_name=selected['name'],link_status='夏新品牌与往复式商品标题对应，具体规格仍需核对')
  uploaded=rs.get(p['id'],{}).get('image',uploaded)
  p.pop('image',None);p['image_source']='待添加对应商品链接图'
  if uploaded and p.get('product_url'):p['image']=uploaded;p['image_source']='用户补充商品链接图'
  if selected and selected.get('image') and '/PF-' not in selected['image']:p['image']=selected['image'];p['image_source']='商品链接原图'
 v['shop_links']=rows;return v
def selection(body):
 result={};data=body.get('image_data')
 if data:
  m=re.fullmatch(r'data:image/(png|jpeg|webp);base64,([A-Za-z0-9+/=\r\n]+)',data)
  if not m:raise ValueError('图片支持PNG、JPG、WebP')
  raw=base64.b64decode(m[2],validate=True)
  if len(raw)>5*1024*1024:raise ValueError('图片不能超过5MB')
  if not (raw.startswith(b'\x89PNG\r\n\x1a\n') or raw.startswith(b'\xff\xd8\xff') or (raw[:4]==b'RIFF' and raw[8:12]==b'WEBP')):raise ValueError('无效图片')
  name='upload-'+hashlib.sha256(raw).hexdigest()[:24]+'.'+{'png':'png','jpeg':'jpg','webp':'webp'}[m[1]];folder=APP/'product-images';folder.mkdir(exist_ok=True);(folder/name).write_bytes(raw);result.update(image='product-images/'+name,image_source='用户上传产品图片')
 url=body.get('shop_url')
 if url:
  r=next((r for r in shop() if r.get('url')==url),None)
  if not r:raise ValueError('请选择从原商品库导入的链接')
  result.update(product_url=url,link_name=r['name'],link_source='https://maoge.ikumao.cn/douyin/?view=products',link_status='用户选择；使用前核对款式与库存')
 return result
def save_resources(pid,body,ids):
 if pid not in ids:raise ValueError('只能为已有素材的商品补充')
 rs=read(DATA/'商品图片链接补充.json',{});rs.setdefault(pid,{}).update(selection(body));(DATA/'商品图片链接补充.json').write_text(json.dumps(rs,ensure_ascii=False,indent=2))
def import_shop(body):
 rows=[]
 for x in body.get('products',[]):
  url=x.get('url','')
  if not isinstance(url,str) or not re.match(r'^https://(haohuo|alliance)\.jinritemai\.com/',url):continue
  img=x.get('image','') or ''
  if img.startswith('/'):img='https://maoge.ikumao.cn'+img
  rows.append({'name':str(x.get('name',''))[:400],'url':url,'image':img,'source_status':'原商品库显示链接待核验'})
 dedup={r['name']+'|'+r['url']:r for r in rows};(DATA/'商品库只读快照.json').write_text(json.dumps({'source':'https://maoge.ikumao.cn/douyin/?view=products','captured_at':datetime.datetime.now().astimezone().isoformat(),'products':list(dedup.values()),'usage':'只为已有素材商品提供链接候选，不新增无素材商品'},ensure_ascii=False,indent=2));return len(dedup)
