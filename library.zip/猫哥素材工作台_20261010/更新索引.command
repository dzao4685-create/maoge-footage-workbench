#!/bin/zsh
/usr/bin/python3 '/Users/szx/Movies/gpt/猫哥素材工作台_20261010/支持文件/建立索引.py'
printf '\n按回车关闭。'
read
