#!/bin/zsh
cd '/Users/szx/Movies/gpt/猫哥素材工作台_20261010/支持文件'
exec /usr/bin/python3 工作台服务.py 8787 --open
