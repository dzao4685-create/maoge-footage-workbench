const json=(v,status=200,headers={})=>new Response(JSON.stringify(v),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',...headers}});
const enc=new TextEncoder();
async function sign(secret,value){const key=await crypto.subtle.importKey('raw',enc.encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);return Array.from(new Uint8Array(await crypto.subtle.sign('HMAC',key,enc.encode(value))),x=>x.toString(16).padStart(2,'0')).join('')}
async function authorized(request,secret){const token=(request.headers.get('Cookie')||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('organizer_session='))?.slice(18);if(!token)return false;const [expires,mac]=token.split('.');if(!/^\d+$/.test(expires)||Number(expires)<Date.now())return false;return mac===await sign(secret,expires)}
function validDates(value){if(!Array.isArray(value)||value.length>500)throw Error('日期数量无效');return [...new Set(value.map(d=>{if(typeof d!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(d)||new Date(d+'T00:00:00Z').toISOString().slice(0,10)!==d)throw Error('日期格式无效');return d}))].sort()}
export async function onRequest({request,env}){
 if(!env.ORGANIZER_DB||!env.ORGANIZER_PASSWORD)return json({error:'云端管理尚未配置，请先连接数据库和管理密码',configured:false},503);
 if(!['GET','POST'].includes(request.method))return json({error:'不支持的方法'},405);
 if(request.method==='POST'&&request.headers.get('Origin')!==new URL(request.url).origin)return json({error:'仅允许本站操作'},403);
 const db=env.ORGANIZER_DB;await db.prepare('CREATE TABLE IF NOT EXISTS product_organizer (product_id TEXT PRIMARY KEY, value TEXT NOT NULL, revision INTEGER NOT NULL DEFAULT 1)').run();
 if(request.method==='GET'){const rows=await db.prepare('SELECT product_id,value,revision FROM product_organizer').all();return json({configured:true,authenticated:await authorized(request,env.ORGANIZER_PASSWORD),products:Object.fromEntries(rows.results.map(r=>[r.product_id,{...JSON.parse(r.value),revision:r.revision}]))})}
 let body;try{if(Number(request.headers.get('content-length')||0)>65536)return json({error:'内容过大'},413);const raw=await request.text();if(raw.length>65536)return json({error:'内容过大'},413);body=JSON.parse(raw)}catch{return json({error:'请求格式无效'},400)}
 if(body.action==='login'){
  if(typeof body.password!=='string'||body.password.length>256||await sign(env.ORGANIZER_PASSWORD,body.password)!==await sign(env.ORGANIZER_PASSWORD,env.ORGANIZER_PASSWORD))return json({error:'管理密码不正确'},401);
  const expires=String(Date.now()+7*86400000),token=expires+'.'+await sign(env.ORGANIZER_PASSWORD,expires);return json({ok:true},200,{'Set-Cookie':'organizer_session='+token+'; HttpOnly; Secure; SameSite=Strict; Path=/api/organizer; Max-Age=604800'})
 }
 if(!await authorized(request,env.ORGANIZER_PASSWORD))return json({error:'请先验证管理密码'},401);
 if(body.action==='logout')return json({ok:true},200,{'Set-Cookie':'organizer_session=; HttpOnly; Secure; SameSite=Strict; Path=/api/organizer; Max-Age=0'});
 if(typeof body.product_id!=='string'||!/^[-\w]{1,100}$/.test(body.product_id)||!Number.isInteger(body.revision)||body.revision<0)return json({error:'商品或版本无效'},400);
 let value;try{if(typeof body.pinned!=='boolean')throw Error();value=JSON.stringify({pinned:body.pinned,added:validDates(body.added),hidden:validDates(body.hidden)})}catch{return json({error:'置顶或日期格式无效'},400)}
 let result;if(body.revision===0)result=await db.prepare('INSERT INTO product_organizer(product_id,value,revision) VALUES(?,?,1) ON CONFLICT(product_id) DO NOTHING').bind(body.product_id,value).run();else result=await db.prepare('UPDATE product_organizer SET value=?,revision=revision+1 WHERE product_id=? AND revision=?').bind(value,body.product_id,body.revision).run();
 if(!result.meta.changes)return json({error:'其他设备刚刚修改了此商品，请刷新后重试'},409);
 return json({ok:true,revision:body.revision+1});
}
